﻿using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using System;
using System.Collections.Generic;
using System.Text;
using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioServiceTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ScenariosService _scenarioService;
        private readonly IScenarioStatusService _scenarioStatusService;
        public ScenarioServiceTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _mySqlDataClient = A.Fake<IMySqlDataClient>();
            _scenarioStatusService = A.Fake<IScenarioStatusService>();
            _scenarioService = new ScenariosService(_mySqlDataClient, _scenarioStatusService, _logHelper,true);
        }
        [Fact]
        public void UpdateScenario_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Returns(true);
            //act 
            var result=_scenarioService.UpdateScenario("", Guid.NewGuid(), new ScenarioDetails());
            //assert
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).MustHaveHappened();
        }
        [Fact]
        public void UpdateScenario_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 
            //assert
            Assert.Throws<Exception>(()=> _scenarioService.UpdateScenario("", Guid.NewGuid(), new ScenarioDetails()));
        }
        [Fact]
        public void UpdateScenario_Empty_scenario_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 
            //assert
            Assert.Throws<ArgumentNullException>(() => _scenarioService.UpdateScenario("", Guid.NewGuid(),null));
        }
        [Fact]
        public void DeleteScenario_Success_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<Guid>._,A<Guid>._)).Returns(true);
            //act 
            var result = _scenarioService.DeleteScenario(Id,Guid.Empty);
            //assert
            Assert.True(result);
        }
        [Fact]
        public void DeleteScenario_Fail_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<Guid>._, A<Guid>._)).Returns(false);
            //act 
            var result = _scenarioService.DeleteScenario(Id, Guid.Empty);
            //assert
            Assert.False(result);
        }
        [Fact]
        public void DeleteScenario_Exception_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<Guid>._, A<Guid>._)).Throws(new Exception());
            //act 

            //assert
            Assert.Throws<Exception>(() => _scenarioService.DeleteScenario(Id, Guid.Empty));
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void InsertScenario_Success_Test(ScenarioDetails scenario)
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Returns(true);
            //act 
            var result = _scenarioService.InsertScenario("", scenario);
            //assert
            Assert.IsType<Guid>(result);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void InsertScenario_Exception_Test(ScenarioDetails scenario)
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 

            //assert
            Assert.Throws<Exception>(() => _scenarioService.InsertScenario("",scenario));
        }
        [Fact]
        public void InsertScenario_ArgumentNull_Exception_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Throws(new ArgumentNullException());
            //act 

            //assert
            Assert.Throws<ArgumentNullException>(() => _scenarioService.InsertScenario("", null));
        }
        [Fact]
        public void GetScenarioByScenarioId_Success_Test()
        {            
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioDetailsByScenarioId(A<Guid>._)).Returns( new System.Data.DataTable());
            //act 
            var result = _scenarioService.GetScenarioByScenarioId("", Guid.Empty);

            //assert
            Assert.IsType<ScenarioDetails>(result);
        }
        [Fact]
        public void GetScenarioByScenarioId_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioDetailsByScenarioId(A<Guid>._)).Throws(new Exception());
            //act 


            //assert
            Assert.Throws<Exception>(() =>_scenarioService.GetScenarioByScenarioId("",Guid.Empty));
        }
        [Fact]
        public void GetAllScenariosByModelId_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenarioDetailsById(A<string>._)).Returns(new System.Data.DataTable());
            //act 
            var result = _scenarioService.GetAllScenariosByModelId("");

            //assert
            Assert.IsType<List<ScenarioDetails>>(result);
        }
        [Fact]
        public void GetAllScenariosByModelId_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenarioDetailsById(A<string>._)).Throws(new Exception());
            //act 


            //assert
            Assert.Throws<Exception>(() => _scenarioService.GetAllScenariosByModelId(""));
        }
    }
}
