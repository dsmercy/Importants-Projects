﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.Predeploy.ExternalDependencies.FeatureFlags
{
    using Honeywell.HCECBP.TestAutomationLaunchDarklyClient;
    using Microsoft.Extensions.Configuration;

    public class FeatureFlagConfiguration : IFlagDataConfiguration
    {
        private const string AcceptanceDockerPath = "/repo/ExternalDependencies/FeatureFlags/flagdata.json";

        public FeatureFlagConfiguration()
        {
            var userDefined = Configuration["LAUNCHDARKLYOFFLINEFLAGJSONFILE"];
            
            FilePath = string.IsNullOrEmpty(userDefined) ? AcceptanceDockerPath : userDefined;
        }

        private static IConfiguration Configuration { get; } = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddEnvironmentVariables().Build();

        public string FilePath { get; }
    }
}

