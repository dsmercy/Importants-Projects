﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.Predeploy.Tests
{
    using System;
    using System.Net;
    using System.Threading.Tasks;
    using Honeywell.HCECBP.TestAutomationLaunchDarklyClient.Interface;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using HCPPrPM.hcpuiwhatifservice.Acceptance.Predeploy.RestService;
    using HCPPrPM.hcpuiwhatifservice.Services.FeatureToggles;
    using HCPPrPM.hcpuiwhatifservice.TodoService;
    using HCPPrPM.hcpuiwhatifservice.Web.Controllers.WebApiModels;
    using Xunit;
    using Xunit.Abstractions;

    public class TodoAcceptanceTests : IDisposable , IClassFixture<Services>
    {
        private static readonly string _enableDeleteFlag = FeatureToggleNames.Development.EnableDeleteFunctionality;

        private readonly IFlagDataFile _flagDataFile;

        private readonly ILogger<TodoAcceptanceTests> _logger;

        public TodoAcceptanceTests(Services services, ITestOutputHelper output)
        {
            _logger = services.GetService<ILogger<TodoAcceptanceTests>>();
            _flagDataFile = services.GetService<IFlagDataFile>();

            _logger.LogInformation("Before Test Setup");
            _flagDataFile.EnableFeature(_enableDeleteFlag);
        }

        private static IToDoClient ToDoClient => RestServiceInitializer.ToDoClient;

        public void Dispose()
        {
            _logger.LogInformation("After Test Cleanup");
            CleanupMock().GetAwaiter().GetResult();
        }

        private static  Task SetupMock()
        {
            // place holder for async setup methods
            return Task.CompletedTask;
        }

        private static  Task CleanupMock()
        {
            // place holder for async cleanup methods
            return Task.CompletedTask;
        }

        [Fact]
        [TestLogger]
        public async Task GivenEnableDeleteFunctionalityFlagIsDisabled_Delete_ReturnsNotImplimented()
        { 
            // Arrange
            _flagDataFile.DisableFeature(_enableDeleteFlag);
            // Act
            var response = await ToDoClient.Delete(Guid.NewGuid());
            // Assert
            Assert.Equal(HttpStatusCode.NotImplemented, response.StatusCode);
        }

        [Fact]
        [TestLogger]
        public async Task GivenItemIdDoesExists_Delete_ReturnsOk()
        {
            // Arrange
            var response = await ToDoClient.Create(new AddRequest {Description = "Bamboo Integration Test 1", Title = "Test Title"});
            var todoItem = JsonConvert.DeserializeObject<TodoItem>(response.Content);
            // Act
            var result = await ToDoClient.Delete(todoItem.Id);
            // Assert
            Assert.Equal(HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        [TestLogger]
        public async Task GivenItemIdDoesNotExist_Delete_ReturnsNotFound()
        {
            // Arrange
            var invalidItemId = Guid.NewGuid();
            // Act
            var result = await ToDoClient.Delete(invalidItemId);
            // Assert
            Assert.Equal(HttpStatusCode.NotFound, result.StatusCode);
        }
    }
}