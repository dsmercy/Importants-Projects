﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.Predeploy.RestService
{
    using Microsoft.Extensions.Configuration;
    using Refit;

    public class RestServiceInitializer
    {
        private static IConfiguration Configuration { get; } = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddEnvironmentVariables().Build();

        private static string Host => Configuration["WebService:Host"];

        private static string Port => Configuration["WebService:Port"];

        public static IToDoClient ToDoClient => RestService.For<IToDoClient>($"http://{Host}{OptionalPort(Port)}");

        private static string OptionalPort(string port) => string.IsNullOrEmpty(port) ? string.Empty : $":{port}";
    }
}