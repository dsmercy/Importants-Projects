﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Config
{
    using Microsoft.Extensions.Configuration;
    public class AcceptanceTestConfig
    {

        private readonly IConfiguration _config;
        public AcceptanceTestConfig(IConfiguration configuration)
        {
            _config = configuration;
        }

        public string Host => _config["WebService:Host"];
        public string Port => _config["WebService:Port"];
        
    }
}
