﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy
{
    using System;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Logging.Console;
    using Microsoft.Extensions.Logging.Debug;

    public class Services
    {
        private readonly IServiceProvider _serviceProvider;
        public Services()
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            _serviceProvider = serviceCollection.BuildServiceProvider();
        }
       
        public static void ConfigureServices(ServiceCollection services)
        {
            services.AddLogging(
                config =>
                {
                    config.AddDebug();
                    config.AddConsole();
                }).Configure<LoggerFilterOptions>(
                options =>
                {
                    options.AddFilter<DebugLoggerProvider>(null, LogLevel.Information /* min level */);
                    options.AddFilter<ConsoleLoggerProvider>(null, LogLevel.Information /* min level */);
                });
             
        }

        public T GetService<T>()
        {
            return _serviceProvider.GetService<T>();
        }
    }
}