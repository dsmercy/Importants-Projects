﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy
{
    using System.Reflection;
    using Microsoft.Extensions.Logging;
    using Xunit.Sdk;

    public class TestLoggerAttribute : BeforeAfterTestAttribute
    {
        private readonly ILogger<TestLoggerAttribute> _logger;
        private readonly Services _services = new Services();

        public TestLoggerAttribute()
        {
            _logger = _services.GetService<ILogger<TestLoggerAttribute>>();
        }

        public override void Before(MethodInfo methodUnderTest) => _logger.LogInformation($"Setup for test '{methodUnderTest.Name}'");

        public override void After(MethodInfo methodUnderTest) => _logger.LogInformation($"TearDown for test '{methodUnderTest.Name}'");
    }
}
