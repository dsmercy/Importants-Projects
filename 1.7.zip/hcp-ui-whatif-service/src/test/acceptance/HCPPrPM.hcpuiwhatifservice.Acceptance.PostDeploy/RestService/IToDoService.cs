﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.Postdeploy.RestService
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Refit;
    using HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Model;

    public interface IToDoClient
    {
        [Delete("/api/todo/{id}")]
        [Headers("Content-Type: application/json")]
        Task<ApiResponse<string>> Delete(Guid id);

        [Post("/api/todo")]
        Task<ApiResponse<string>> Create(AddRequest request);

        [Get("/api/todo/{id}")]
        [Headers("Content-Type: application/json")]
        Task<ApiResponse<string>> GetById(Guid id);

        [Get("/api/todo")]
        [Headers("Content-Type: application/json")]
        Task<IEnumerable<TodoItem>> GetAll();

    }
}