﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.Postdeploy.RestService
{
    using Microsoft.Extensions.Configuration;
    using Refit;
    using HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Config;

    public class RestServiceInitializer
    {
        private readonly AcceptanceTestConfig _config;
        public RestServiceInitializer(AcceptanceTestConfig configuration)
        {
            _config = configuration;
        }

        private string UrlBuilder(string host, string port) => $"{host}{(string.IsNullOrWhiteSpace(port) ? "" : $":{port}")}";

        public IToDoClient ToDoClient => RestService.For<IToDoClient>(UrlBuilder(_config.Host, _config.Port));


        
    }
}