<#
.SYNOPSIS
This script executes post deploy acceptance test suite locally. It builds application and acceptance containers and execute the tests against them.  

.DESCRIPTION
This script performs the following tasks
    a. Build and spin up the application and acceptance test containers and executes the acceptance test suite via docker-compose
    b. Cleans up the containers irrespective of the outcome. The corresponding docker images are not deleted

.EXAMPLE
./acceptance-postdeploy-local.ps1
#>

# Check for application and acceptance docker images
New-Item -ItemType Directory -Force -Path results
Invoke-Expression "docker-compose -f docker-compose.yml down --remove-orphans; docker-compose -f docker-compose.yml up --abort-on-container-exit; docker-compose rm -f"