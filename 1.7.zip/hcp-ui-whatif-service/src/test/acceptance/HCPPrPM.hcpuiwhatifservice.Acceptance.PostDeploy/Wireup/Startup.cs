﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Wireup
{
    using BoDi;
    using Microsoft.Extensions.Configuration;
    using TechTalk.SpecFlow;

    [Binding]
    class Startup
    {
        private readonly IObjectContainer _objectContainer;

        private static IConfiguration Configuration { get; } =
            new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();
        public Startup(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [BeforeScenario]
        public void InitializeInterfaces()
        {
            _objectContainer.RegisterInstanceAs<IConfiguration>(Configuration);

        }

    }
}
