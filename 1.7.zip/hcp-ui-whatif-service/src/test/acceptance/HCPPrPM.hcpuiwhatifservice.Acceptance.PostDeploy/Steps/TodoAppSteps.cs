﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using System.Collections.Generic;
using System.Net;
using TechTalk.SpecFlow;
using HCPPrPM.hcpuiwhatifservice.Acceptance.Postdeploy.RestService;
using HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Model;
using Xunit;
using Refit;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace HCPPrPM.hcpuiwhatifservice.Acceptance.PostDeploy.Steps
{
    [Binding]
    public class TodoAppSteps: IDisposable , IClassFixture<Services>
    {
        private readonly IToDoClient _toDoClient;
        private readonly ILogger<TodoAppSteps> _logger;
        private readonly ScenarioContext _scenarioContext;

        public TodoAppSteps(Services services, RestServiceInitializer restService, ScenarioContext scenarioContext)
        {
            _logger = services.GetService<ILogger<TodoAppSteps>>();
            _logger.LogInformation("Before Test Setup");
            _toDoClient = restService.ToDoClient;
            _scenarioContext = scenarioContext;

        }

        [Given(@"I have a new todo item - ""(.*)"",""(.*)""")]
        public async System.Threading.Tasks.Task GivenIHaveANewTodoItem_(string title, string description)
        {
            var toDoItem = new AddRequest {Title = title, Description = description};
            var response = await _toDoClient.Create(toDoItem);
            _scenarioContext["PostActualResponse"] = response;
        }

        [Then(@"I should get Success status Code")]
        public void ThenIShouldGetSuccessStatusCode()
        {
            var actualResponse = (ApiResponse<string>)_scenarioContext["PostActualResponse"];
            Assert.Equal(HttpStatusCode.OK, actualResponse.StatusCode);
        }

        [Given(@"I add a new todo item - ""(.*)"",""(.*)""")]
        public async System.Threading.Tasks.Task GivenIAddANewTodoItem_(string title, string description)
        {
            var toDoItem = new AddRequest {Title = title, Description = description};
            var expectedTodoItem = new TodoItem {Title = title, Description = description};
            _scenarioContext["ExpectedTodoItem"] = expectedTodoItem;
            await _toDoClient.Create(toDoItem);
        }

        [Given(@"I make a fetch call")]
        public async System.Threading.Tasks.Task GivenIMakeAFetchCall()
        {
            var response = await _toDoClient.GetAll();
            _scenarioContext["ActualTodoItemList"] = response;
        }
        
        [Then(@"I should get the new list")]
        public void ThenIShouldGetTheNewList()
        {
            var expectedTodoItem = (TodoItem)_scenarioContext["ExpectedTodoItem"];
            var actualResult = (IEnumerable<TodoItem>)_scenarioContext["ActualTodoItemList"];
            Assert.Contains(actualResult.ToList(), x => x.Title == expectedTodoItem.Title);
        }

        public void Dispose()
        {
            _logger.LogInformation("After Test Cleanup");
        }
    }
}
