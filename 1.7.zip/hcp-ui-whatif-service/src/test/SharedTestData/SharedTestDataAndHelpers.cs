// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.SharedTestData
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Test data and helpers that can be used across all test projects.
    /// </summary>
    public class Scenario
    {
        public class ScenarioData : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new ScenarioDetails
                    {
                        ScenarioId=Guid.Parse("6aa4e717-30ca-498c-acea-5ec47c19c5ad"),
                        ScenarioName="Test",
                        FlowSheet = new FlowSheet()
                        {
                            Flowsheet_Name ="Dummy",
                            FlowSheet_CreatedDateTime = null
                        }
                    }
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }

        public class ScenarioDataNew : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new ScenarioDetails
                    {
                        ScenarioId=Guid.Parse("6aa4e717-30ca-498c-acea-5ec47c19c5ad"),
                        ScenarioName="Test",
                        IsOPEnabled = true, 
                        FlowSheet = new FlowSheet()
                        {
                            Flowsheet_Name ="Dummy",
                            FlowSheet_CreatedDateTime = null
                        },
                        Instances = new List<ScenarioInstance> { new ScenarioInstance() { StatusCode ="active"  } }
                    }
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }

        public class ScenarioResultData : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new List<ScenarioResultModel>{
                    new ScenarioResultModel
                    {
                        TagName="Test TagName",
                        Value=100.00,
                        TimeStamp=DateTime.Now,
                    }}
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }
        public class ScenarioDataWithoutScenarioName : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new ScenarioDetails
                    {
                        ScenarioId=Guid.NewGuid(),
                    }
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }

        public class ScenarioCommentData : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new ScenarioCommentModel
                    {
                        ScenarioId="test Id",
                        Comment = "test comment",
                        Username = "test username",
                        CreatedDateTime = DateTime.Now
                    }
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }

        public class ScenarioNoteData : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[]
                {
                    new ScenarioNoteModel
                    {
                        ScenarioId="test Id",
                        Notes = "test comment",
                        Username = "test username",
                        CreatedDateTime = DateTime.Now
                    }
                };
            }

            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
            IEnumerator<object[]> IEnumerable<object[]>.GetEnumerator() => GetEnumerator();

        }
    }
    
}