﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioServiceTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ScenariosService _scenarioService;
        private readonly IScenarioStatusService _scenarioStatusService;
        private readonly IConfiguration _configuration;
        public ScenarioServiceTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _mySqlDataClient = A.Fake<IMySqlDataClient>();
            _scenarioStatusService = A.Fake<IScenarioStatusService>();
            _configuration = A.Fake<IConfiguration>();
            _scenarioService = new ScenariosService(_mySqlDataClient, _scenarioStatusService, _logHelper, _configuration);
        }
        [Fact]
        public void UpdateScenario_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Returns(true);
            //act 
            var result = _scenarioService.UpdateScenario("", Guid.NewGuid(), new ScenarioDetails());
            //assert
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).MustHaveHappened();
        }
        [Fact]
        public void UpdateScenario_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 
            //assert
            Assert.Throws<Exception>(() => _scenarioService.UpdateScenario("", Guid.NewGuid(), new ScenarioDetails()));
        }


        [Fact]
        public void UpdateScenarioNameDesc_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).Returns(true);
            //act 
            var result = _scenarioService.UpdateScenarioNameDesc("", Guid.NewGuid(), new ScenarioDetails());
            //assert
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).MustHaveHappened();
        }

        [Fact]
        public void UpdateScenarioNameDesc_IsOPEnabled_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).Returns(true);
            //act 
            var result = _scenarioService.UpdateScenarioNameDesc("", Guid.NewGuid(), new ScenarioDetails { IsOPEnabled = true,CreatedBy = "test" });
            //assert
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).MustNotHaveHappened();
        }

        [Fact]
        public void UpdateScenarioNameDesc_Null_Param_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).Returns(true);
            //act 
            
            //assert
            Assert.Throws<ArgumentNullException>(() => _scenarioService.UpdateScenarioNameDesc("", Guid.NewGuid(), null));
        }

        [Fact]
        public void UpdateScenarioNameDesc_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioNameDesc(A<ScenarioDetails>._)).Throws(new Exception());
            //act 
            //assert
            Assert.Throws<Exception>(() => _scenarioService.UpdateScenarioNameDesc("", Guid.NewGuid(), new ScenarioDetails()));
        }


        [Fact]
        public void UpdateScenario_Empty_scenario_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 
            //assert
            Assert.Throws<ArgumentNullException>(() => _scenarioService.UpdateScenario("", Guid.NewGuid(), null));
        }
        [Fact]
        public void DeleteScenario_Success_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);
            //act 
            var result = _scenarioService.DeleteScenario(Id, Guid.Empty, Guid.Empty);
            //assert
            Assert.True(result);
        }
        [Fact]
        public void DeleteScenario_Fail_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(false);
            //act 
            var result = _scenarioService.DeleteScenario(Id, Guid.Empty, Guid.Empty);
            //assert
            Assert.False(result);
        }
        [Fact]
        public void DeleteScenario_Exception_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);
            //act 
            var result = _scenarioService.DeleteScenario(Id, Guid.Empty, Guid.Empty);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void InsertScenario_Success_Test(ScenarioDetails scenario)
        {
            string Id = Guid.Empty.ToString();
            ScenarioStatus scenarioStatus = new ScenarioStatus() { Code = "NOT_RUN", Id = 1, Description = "" };
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Returns(true);
            A.CallTo(() => _scenarioStatusService.GetStatusById("NOT_RUN")).Returns(scenarioStatus);
            A.CallTo(() => _mySqlDataClient.UpdateScenarioInstanceStatus(A<string>._, A<string>._, A<string>._));
            //act 

            var result = _scenarioService.InsertScenario("", scenario);
            //assert
            Assert.IsType<Guid>(result);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioDataNew))]
        public void InsertScenario_Success_WithInstance_Test(ScenarioDetails scenario)
        {
            string Id = Guid.Empty.ToString();
            ScenarioStatus scenarioStatus = new ScenarioStatus() { Code = "NOT_RUN", Id = 1, Description = "" };
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Returns(true);
            A.CallTo(() => _scenarioStatusService.GetStatusById("NOT_RUN")).Returns(scenarioStatus);
            A.CallTo(() => _mySqlDataClient.UpdateScenarioInstanceStatus(A<string>._, A<string>._, A<string>._));
            //act 

            var result = _scenarioService.InsertScenario("", scenario);
            //assert
            Assert.IsType<Guid>(result);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void InsertScenario_Exception_Test(ScenarioDetails scenario)
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Throws(new Exception());
            //act 

            //assert
            Assert.Throws<Exception>(() => _scenarioService.InsertScenario("", scenario));
        }
        [Fact]
        public void InsertScenario_ArgumentNull_Exception_Test()
        {
            string Id = Guid.Empty.ToString();
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenario(A<ScenarioDetails>._)).Throws(new ArgumentNullException());
            //act 

            //assert
            Assert.Throws<ArgumentNullException>(() => _scenarioService.InsertScenario("", null));
        }
        [Fact]
        public void GetScenarioByScenarioId_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioDetailsByScenarioId(A<Guid>._)).Returns(new System.Data.DataTable());
            //act 
            var result = _scenarioService.GetScenarioByScenarioId("", Guid.Empty);

            //assert
            Assert.IsType<ScenarioDetails>(result);
        }
        [Fact]
        public void GetScenarioByScenarioId_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioDetailsByScenarioId(A<Guid>._)).Throws(new Exception());
            //act 


            //assert
            Assert.Throws<Exception>(() => _scenarioService.GetScenarioByScenarioId("", Guid.Empty));
        }
        [Fact]
        public void GetAllScenariosByModelId_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenarioDetailsById(A<string>._, A<string>._)).Returns(new System.Data.DataTable());
            //act 
            var result = _scenarioService.GetAllScenariosByModelId("","");

            //assert
            Assert.IsType<List<ScenarioDetails>>(result);
        }
        [Fact]
        public void GetAllScenariosByModelId_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenarioDetailsById(A<string>._, A<string>._)).Throws(new Exception());
            //act 


            //assert
            Assert.Throws<Exception>(() => _scenarioService.GetAllScenariosByModelId("",""));
        }
        [Fact]
        public void CheckDuplicateNames_Duplicate_Exists_Test()
        {
            List<ScenarioNames> scenarioNames = new List<ScenarioNames>();
            scenarioNames.Add(new ScenarioNames { ScenarioId = Guid.Empty, ScenarioName = "Test" });
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenariosByModelId(A<string>._)).Returns(scenarioNames);

            //Act
            var result = _scenarioService.CheckDuplicateNames("", "Test", Guid.Empty);

            Assert.True(result);
        }
        [Fact]
        public void CheckDuplicateNames_Duplicate_NotExists_Test()
        {
            List<ScenarioNames> scenarioNames = new List<ScenarioNames>();
            scenarioNames.Add(new ScenarioNames { ScenarioId = Guid.Empty, ScenarioName = "Test1" });
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenariosByModelId(A<string>._)).Returns(scenarioNames);

            //Act
            var result = _scenarioService.CheckDuplicateNames("", "Test", Guid.Empty);

            Assert.False(result);
        }
        [Fact]
        public void CheckDuplicateNames_Exception_Test()
        {
            List<ScenarioNames> scenarioNames = new List<ScenarioNames>();
            scenarioNames.Add(new ScenarioNames { ScenarioId = Guid.Empty, ScenarioName = "Test1" });
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllScenariosByModelId(A<string>._)).Throws(new Exception());

            //Act
            //Assert
            Assert.Throws<Exception>(() => _scenarioService.CheckDuplicateNames("", "Test", Guid.Empty));
        }
        [Fact]
        public void UpdateScenarioStatus_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, A<string>._, A<string>._)).Returns(true);
            //act 
            var result = _scenarioService.UpdateScenarioStatus(Guid.NewGuid(), Guid.NewGuid());
            //assert
            Assert.IsType<Guid>(result);
        }
        [Fact]
        public void UpdateScenarioStatus_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, A<string>._, A<string>._)).Throws(new Exception());
            
            //assert
            Assert.Throws<Exception>(() => _scenarioService.UpdateScenarioStatus(Guid.NewGuid(), Guid.NewGuid()));
        }

        [Fact]
        public void IsScenarioAllowedToRun_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.IsScenarioAllowedToRun(A<int>._, A<string>._)).Returns(new System.Data.DataTable());
            //act 
            var result = _scenarioService.IsScenarioAllowedToRun("test", "test");

            //assert
            Assert.IsType<int>(result);
        }
        [Fact]
        public void IsScenarioAllowedToRun_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.IsScenarioAllowedToRun(A<int>._, A<string>._)).Throws(new Exception());
            //act 

            //assert
            Assert.Throws<Exception>(() => _scenarioService.IsScenarioAllowedToRun("test", "test"));
        }
        [Fact]
        public void DeleteScenarios_Success_Test()
        {
            string Id = "test";
            string[] guids = new string[1];
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenarios(A<string>._, A<string[]>._)).Returns(true);
            //act 
            var result = _scenarioService.DeleteScenarios(Id, guids);
            //assert
            Assert.True(result);
        }
        [Fact]
        public void DeleteScenarios_Fail_Test()
        {
            string Id = "";
            string[] guids = new string[0];
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenarios(A<string>._, A<string[]>._)).Returns(false);
            //act 
            var result = _scenarioService.DeleteScenarios(Id, guids);
            //assert
            Assert.False(result);
        }

        [Fact]
        public void DeleteScenarios_Exception_Test()
        {
            string Id = "test";
            string[] guids = new string[1];
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeleteScenarios(A<string>._, A<string[]>._)).Throws(new Exception());
             
            //act 
            
            //assert
            Assert.Throws<Exception>(() => _scenarioService.DeleteScenarios(Id, guids));
        }
    }
}
