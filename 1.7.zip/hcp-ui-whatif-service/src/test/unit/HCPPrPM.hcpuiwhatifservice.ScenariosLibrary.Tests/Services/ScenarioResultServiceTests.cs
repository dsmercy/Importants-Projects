﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioResultServiceTests
    {
        private readonly ICustomLogger _logHelper;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly IScenarioResultService _scenarioResultService;
        public ScenarioResultServiceTests()
        {
            _logHelper = A.Fake<ICustomLogger>();
            _mySqlDataClient = A.Fake<IMySqlDataClient>();
            _scenarioResultService = new ScenarioResultService(_mySqlDataClient, _logHelper);
        }

        [Fact]
        public async void GetScenarioResultByInstanceId_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioResultByInstanceId(A<string>._, A<Guid>._, A<Guid>._)).Returns(new System.Data.DataTable());
            //act 
            var result = await _scenarioResultService.GetScenarioResultByInstanceId("test ModelId", Guid.NewGuid(), Guid.NewGuid());

            //assert
            Assert.IsType<ScenarioResult>(result);
        }

        [Fact]
        public void GetScenarioResultByInstanceId_Exception_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioResultByInstanceId(A<string>._, A<Guid>._, A<Guid>._)).Throws(new Exception());
            //act 


            //assert
            Assert.ThrowsAsync<Exception>(() => _scenarioResultService.GetScenarioResultByInstanceId("test ModelId", Guid.NewGuid(), Guid.NewGuid()));
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void InsertScenarioResult_Success_Test(List<ScenarioResultModel> scenarioResultModel)
        {
            ScenarioResultModel scenarioResult = scenarioResultModel.Find(x => x.TagName == "Test TagName");
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioResultByInstanceId(A<string>._, A<Guid>._, A<Guid>._)).Returns(new System.Data.DataTable());
            A.CallTo(() => _mySqlDataClient.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Returns(true);
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, "test Status","")).Returns(true);

            //act 
            var result = _scenarioResultService.InsertScenarioResult("test ModelID", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel);

            //assert
            Assert.IsType<bool>(result);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void InsertScenarioResult_Exception_Test(List<ScenarioResultModel> scenarioResultModel)
        {
            ScenarioResultModel scenarioResult = scenarioResultModel.Find(x => x.TagName == "Test TagName");
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetScenarioResultByInstanceId(A<string>._, A<Guid>._, A<Guid>._)).Throws(new Exception());
            A.CallTo(() => _mySqlDataClient.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Throws(new Exception());
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, "test Status","")).Throws(new Exception());

            //act 
            
            //assert
            Assert.Throws<Exception>(() => _scenarioResultService.InsertScenarioResult("test ModelID", Guid.NewGuid(), Guid.NewGuid(), null));
        }

        [Fact]
        public void UpdateScenarioResultStatus_Success_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, A<string>._, A<string>._)).Returns(true);

            //act 
            var result = _scenarioResultService.UpdateScenarioResultStatus("test ModelID", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel);

            //assert
            Assert.IsType<bool>(result);
        }

        [Fact]
        public void UpdateScenarioResultStatus_Exception_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.UpdateScenarioStatus(A<Guid>._, A<Guid>._, A<string>._, A<string>._)).Throws(new Exception());

            //act 

            //assert
            Assert.Throws<Exception>(() => _scenarioResultService.UpdateScenarioResultStatus("test ModelID", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel));
        }
    }
}
