﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RichardSzalay.MockHttp;
using System;
using System.Net;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    //[TestClass]
    public class ScenarioRunServiceTests
    {
        private  Mock<ILogHelper> _logHelper= new Mock<ILogHelper>();
        private  Mock<IMySqlDataClient> _mySqlDataClient=new Mock<IMySqlDataClient>();
        private Mock<IOptions<BaseUrls>> _baseUrls = new Mock<IOptions<BaseUrls>>();

        BaseUrls baseUrls = new BaseUrls
        {
            WhatifCalcProcessorApi = "http://localhost/hcpWhatIfCalcprocessor/api/v1/",
            SeeqAPI = "https://quopseeq.honeywell.com/api"
        };

        private void MockConfig()
        {
            _baseUrls.Setup(ap => ap.Value).Returns(baseUrls);
        }

        [Fact]
        public void ScenarioRunRequestToCalcProcessor_Success_Test()
        {
            _mySqlDataClient.Setup(x => x.GetInstanceDetailsByScenarioId("testScenarioId")).Returns(new System.Data.DataTable());
            
            MockConfig();
            var mockHttp = new MockHttpMessageHandler();
            var request = mockHttp.When("http://localhost/hcpWhatIfCalcprocessor/api/v1/testModelId/testScenarioId/testInstanceId*")
                    .Respond("application/json", "[]");

            var httpClient = mockHttp.ToHttpClient();

            ScenarioRunService client = new ScenarioRunService(_baseUrls.Object, httpClient,_mySqlDataClient.Object);
            var data = client.ScenarioRunRequestToCalcProcessor("testModelId", "testScenarioId", "test Access token");
            //assert
            Xunit.Assert.IsType<string>(data);
        }
        [Fact]
        public void ScenarioRunRequestToCalcProcessor_Exception_Test()
        {
            _mySqlDataClient.Setup(x => x.GetInstanceDetailsByScenarioId("testScenarioId")).Returns(new System.Data.DataTable());

            MockConfig();
            var mockHttp = new MockHttpMessageHandler();
            var request = mockHttp.When("http://localhost/hcpWhatIfCalcprocessor/api/v1/testModelId/testScenarioId/testInstanceId*")
                    .Throw(new Exception()); 

            var httpClient = mockHttp.ToHttpClient();

            ScenarioRunService client = new ScenarioRunService(_baseUrls.Object, httpClient, _mySqlDataClient.Object);
            client.ScenarioRunRequestToCalcProcessor("testModelId", "testScenarioId", "test Access token");            
        }

        [Fact]
        public void ScenarioRunRequestToCalcProcessor_NotFound_Test()
        {
            _mySqlDataClient.Setup(x => x.GetInstanceDetailsByScenarioId("testScenarioId")).Returns(new System.Data.DataTable());

            MockConfig();
            var mockHttp = new MockHttpMessageHandler();
            var request = mockHttp.When("http://localhost/hcpWhatIfCalcprocessor/api/v1/testModelId/testScenarioId/testInstanceId*")
                    .Respond(HttpStatusCode.NotFound);

            var httpClient = mockHttp.ToHttpClient();

            ScenarioRunService client = new ScenarioRunService(_baseUrls.Object, httpClient, _mySqlDataClient.Object);
            client.ScenarioRunRequestToCalcProcessor("testModelId", "testScenarioId", "test Access token");
        }

    }
}
