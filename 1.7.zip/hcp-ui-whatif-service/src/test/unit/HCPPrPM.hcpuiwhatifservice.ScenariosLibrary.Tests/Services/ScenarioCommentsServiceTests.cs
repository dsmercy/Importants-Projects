﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioCommentsServiceTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ScenarioCommentsService _scenarioCommentsService;
        private readonly IScenariosService _scenariosService;
        public ScenarioCommentsServiceTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _mySqlDataClient = A.Fake<IMySqlDataClient>();
            _scenariosService = A.Fake<IScenariosService>();
            _scenarioCommentsService = new ScenarioCommentsService(_mySqlDataClient, _logHelper,_scenariosService);
        }

        
        [Fact]
        public void InsertScenarioComment_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenarioComment(A<ScenarioComment>._)).Returns(true);
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<string>._, A<Guid>._)).Returns(new ScenarioDetails());
            ScenarioCommentModel scenarioCommentModel = new ScenarioCommentModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Comment = "test comment",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };
            //Act
            var result = _scenarioCommentsService.InsertScenarioComment(scenarioCommentModel);
            //Assert
            Assert.False(result);
        }

        [Fact]
        public void PostComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<string>._, A<Guid>._)).Throws(new Exception());
            A.CallTo(() => _mySqlDataClient.InsertScenarioComment(A<ScenarioComment>._)).Throws(new Exception());
            ScenarioCommentModel scenarioCommentModel = new ScenarioCommentModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Comment = "test comment",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };

            Assert.Throws<Exception>(() => _scenarioCommentsService.InsertScenarioComment(scenarioCommentModel));
        }


        [Fact]
        public void UpdateComment_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetComment(A<string>._, A<string>._)).Returns(new ScenarioComment());
            A.CallTo(() => _mySqlDataClient.UpdateScenarioComment(A<ScenarioComment>._)).Returns(true);
            ScenarioCommentModel scenarioCommentModel = new ScenarioCommentModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Comment = "test comment",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };

            //Act
            var result = _scenarioCommentsService.UpdateScenarioComment("testId", "testId", scenarioCommentModel);
            //Assert
            Assert.True(true);
        }


        [Fact]
        public void UpdateComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetComment(A<string>._, A<string>._)).Throws(new Exception());
            A.CallTo(() => _mySqlDataClient.UpdateScenarioComment(A<ScenarioComment>._)).Throws(new Exception());
            ScenarioCommentModel scenarioCommentModel = new ScenarioCommentModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Comment = "test comment",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };
            //Act
            Assert.Throws<Exception>(() => _scenarioCommentsService.UpdateScenarioComment("testId", "testId", scenarioCommentModel));
        }

        [Fact]
        public void GetAllComments_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllComments(A<string>._)).Returns(new List<ScenarioComment>());

            //Act
            var result = _scenarioCommentsService.GetAllComments("test ScenarioId");
            //Assert
            A.CallTo(() => _mySqlDataClient.GetAllComments(A<string>._)).MustHaveHappened();

        }

        [Fact]
        public void GetAllComments_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllComments(A<string>._)).Throws(new Exception());

            //Act

            //Assert
            Assert.Throws<Exception>(() => _scenarioCommentsService.GetAllComments("test Id"));
        }

        [Fact]
        public void GetComment_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetComment(A<string>._, A<string>._)).Returns(new ScenarioComment());

            //Act
            var result = _scenarioCommentsService.GetComment("test ScenarioId", "test commentId");
            //Assert
            A.CallTo(() => _mySqlDataClient.GetComment(A<string>._, A<string>._)).MustHaveHappened();

        }

        [Fact]
        public void GetComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetComment(A<string>._, A<string>._)).Throws(new Exception());

            //Act
            Assert.Throws<Exception>(() => _scenarioCommentsService.GetComment("test Id","test Id"));

        }

        [Fact]
        public void DeleteComment_Success_Test()
        {
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeletScenarioComment(A<string>._, A<string>._)).Returns(true);

            //Act
            var result = _scenarioCommentsService.DeletScenarioComment("test ScenarioId", "test commentId");
            //Assert
            A.CallTo(() => _mySqlDataClient.DeletScenarioComment(A<string>._, A<string>._)).MustHaveHappened();
        }

        [Fact]
        public void DeleteComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.DeletScenarioComment(A<string>._, A<string>._)).Throws(new Exception());

            //Act
            Assert.Throws<Exception>(() => _scenarioCommentsService.DeletScenarioComment("test Id", "test Id"));
        }
    }
}
