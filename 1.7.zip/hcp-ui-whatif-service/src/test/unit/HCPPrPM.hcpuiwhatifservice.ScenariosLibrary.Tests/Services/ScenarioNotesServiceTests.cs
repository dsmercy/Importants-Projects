﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioNotesServiceTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ScenarioNotesService _scenarioNotesService;
        private readonly IScenariosService _scenariosService;
        public ScenarioNotesServiceTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _mySqlDataClient = A.Fake<IMySqlDataClient>();
            _scenariosService = A.Fake<IScenariosService>();
            _scenarioNotesService = new ScenarioNotesService(_mySqlDataClient, _logHelper,_scenariosService);
        }

        
        [Fact]
        public void InsertScenarioNote_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.InsertScenarioNote(A<ScenarioNote>._)).Returns(true);
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<string>._, A<Guid>._)).Returns(new ScenarioDetails());
            ScenarioNoteModel scenarioNoteModel = new ScenarioNoteModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Notes = "test note",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };
            //Act
            var result = _scenarioNotesService.InsertScenarioNote(scenarioNoteModel);
            //Assert
            Assert.Equal(2,result);
        }

        [Fact]
        public void PostNote_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<string>._, A<Guid>._)).Throws(new Exception());
            A.CallTo(() => _mySqlDataClient.InsertScenarioNote(A<ScenarioNote>._)).Throws(new Exception());
            ScenarioNoteModel scenarioNoteModel = new ScenarioNoteModel
            {
                ScenarioId = Convert.ToString(Guid.NewGuid()),
                Notes = "test note",
                Username = "test username",
                CreatedDateTime = DateTime.Now
            };

            Assert.Throws<Exception>(() => _scenarioNotesService.InsertScenarioNote(scenarioNoteModel));
        }

        [Fact]
        public void GetAllNotes_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllNotes(A<string>._)).Returns(new List<ScenarioNote>());

            //Act
            var result = _scenarioNotesService.GetAllNotes("test ScenarioId");
            //Assert
            A.CallTo(() => _mySqlDataClient.GetAllNotes(A<string>._)).MustHaveHappened();

        }

        [Fact]
        public void GetAllNotes_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetAllNotes(A<string>._)).Throws(new Exception());

            //Act

            //Assert
            Assert.Throws<Exception>(() => _scenarioNotesService.GetAllNotes("test Id"));
        }

        [Fact]
        public void GetNote_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetLatestNote(A<string>._)).Returns(new ScenarioNote());

            //Act
            var result = _scenarioNotesService.GetLatestNote("test ScenarioId");
            //Assert
            A.CallTo(() => _mySqlDataClient.GetLatestNote(A<string>._)).MustHaveHappened();

        }

        [Fact]
        public void GetNote_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _mySqlDataClient.GetLatestNote(A<string>._)).Throws(new Exception());

            //Act
            Assert.Throws<Exception>(() => _scenarioNotesService.GetLatestNote("test Id"));

        }

    }
}
