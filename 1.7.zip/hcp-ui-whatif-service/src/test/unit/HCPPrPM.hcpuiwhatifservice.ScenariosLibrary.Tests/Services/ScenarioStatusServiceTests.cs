﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Tests.Services
{
    public class ScenarioStatusServiceTests
    {
        private readonly ILogHelper _logHelper;
        private readonly ScenarioStatusService _scenarioStatusService;
        public ScenarioStatusServiceTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenarioStatusService = new ScenarioStatusService();
        }

        [Fact]
        public void GetStatusById_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            //act 
            var result = _scenarioStatusService.GetStatusById("testId");

            //assert
            Assert.IsType<ScenarioStatus>(result);
        }
        [Fact]
        public void GetStatusForUI_Success_Test()
        {
            //arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            //act 
            var result = _scenarioStatusService.GetStatusForUI("CASELOAD_SUCCESS");

            //assert
            Assert.IsType<ScenarioStatus>(result);
        }

    }
}
