﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.SharedTestData;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenariosControllerTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenariosService _scenariosService;
        private readonly ScenariosController _scenariosController;
        private readonly IConfiguration _configuration;
        public ScenariosControllerTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenariosService = A.Fake<IScenariosService>();
            _configuration = A.Fake<IConfiguration>();
            _scenariosController = new ScenariosController(_scenariosService, _logHelper, _configuration);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_Success_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result=_scenariosController.PostScenario(Guid.NewGuid().ToString(), "Test", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_DuplicateName_Fail_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(true);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "Test", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_Empty_TenantId_Fail_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario("", "Test", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_Empty_SolutionId_Fail_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }
        [Fact]
        public void PostScenario_Empty_Scenario_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "",  new ScenarioDetails()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioDataWithoutScenarioName))]
        public void PostScenario_Empty_ScenarioName_Fail_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "Test", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_Duplicate_ScenarioName_Fail_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(true);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioData))]
        public void PostScenario_Exception_Test(ScenarioDetails scenarioDetails)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.InsertScenario(A<string>._, A<ScenarioDetails>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.PostScenario(Guid.NewGuid().ToString(), "Test", scenarioDetails) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
        [Fact]
        public void DeleteScenario_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);

            //Act
            var result = _scenariosController.DeleteScenario("Test","Test",Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }
        [Fact]
        public void DeleteScenario_Null_TenantCode_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);

            //Act
            var result = _scenariosController.DeleteScenario("", "Test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void DeleteScenario_Null_SolutionId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);

            //Act
            var result = _scenariosController.DeleteScenario("Test", "", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void DeleteScenario_Empty_ScenarioId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(true);

            //Act
            var result = _scenariosController.DeleteScenario("Test", "Test", Guid.Empty, Guid.Empty) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void DeleteScenario_ScenarioId_NotExist_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Returns(false);

            //Act
            var result = _scenariosController.DeleteScenario("Test", "Test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }
        [Fact]
        public void DeleteScenario_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenario(A<string>._, A<Guid>._, A<Guid>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.DeleteScenario("Test", "Test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
        [Fact]
        public void GetAllScenarios_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetAllScenariosByModelId(A<string>._, A<string>._)).Returns(new List<ScenarioDetails>());

            //Act
            var result = _scenariosController.GetAllScenarios("test","test") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }
        [Fact]
        public void GetAllScenarios_Null_TenantCode_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetAllScenariosByModelId(A<string>._, A<string>._)).Returns(new List<ScenarioDetails>());

            //Act
            var result = _scenariosController.GetAllScenarios("", "test") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void GetAllScenarios_Null_SolutionId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetAllScenariosByModelId(A<string>._, A<string>._)).Returns(new List<ScenarioDetails>());

            //Act
            var result = _scenariosController.GetAllScenarios("test", "") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void GetAllScenarios_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetAllScenariosByModelId(A<string>._, A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.GetAllScenarios("test", "test") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
        [Fact]
        public void GetScenario_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<String>._,A<Guid>._)).Returns(new ScenarioDetails());

            //Act
            var result = _scenariosController.GetScenario("test","test",Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }
        [Fact]
        public void GetScenario_Empty_Inputs_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<String>._, A<Guid>._)).Returns(new ScenarioDetails());

            //Act
            var result = _scenariosController.GetScenario("", "", Guid.Empty) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void GetScenario_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.GetScenarioByScenarioId(A<String>._, A<Guid>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.GetScenario("Test", "Test", Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
        [Fact]
        public void UpdateScenario_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.UpdateScenario(A<string>._,A<Guid>._,A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.UpdateScenario("6aa4e717-30ca-498c-acea-5ec47c19c5ad", "test", Guid.NewGuid(), new ScenarioDetails { ScenarioName = "test", ScenarioId = Guid.NewGuid() },false) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void UpdateScenario_NameDesc_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.UpdateScenarioNameDesc(A<string>._, A<Guid>._, A<ScenarioDetails>._)).Returns((false, Guid.NewGuid()));

            //Act
            var result = _scenariosController.UpdateScenario("6aa4e717-30ca-498c-acea-5ec47c19c5ad", "test", Guid.NewGuid(), new ScenarioDetails { ScenarioName = "test", ScenarioId = Guid.NewGuid() }, true) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(401, resultStatus);
        }
        [Fact]
        public void UpdateScenario_DuplicateName_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.UpdateScenario(A<string>._, A<Guid>._, A<ScenarioDetails>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.UpdateScenario("6aa4e717-30ca-498c-acea-5ec47c19c5ad", "test", Guid.NewGuid(), new ScenarioDetails { ScenarioName="test",ScenarioId=Guid.NewGuid()},false) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
        [Fact]
        public void UpdateScenario_Empty_Scenario_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.UpdateScenario(A<string>._, A<Guid>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.UpdateScenario("test", "test", Guid.NewGuid(), new ScenarioDetails(),false) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void UpdateScenario_Empty_TenantCode_SolutionId_ScenarioId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.CheckDuplicateNames(A<string>._, A<string>._, A<Guid>._)).Returns(false);
            A.CallTo(() => _scenariosService.UpdateScenario(A<string>._, A<Guid>._, A<ScenarioDetails>._)).Returns(Guid.NewGuid());

            //Act
            var result = _scenariosController.UpdateScenario("", "", Guid.Empty, new ScenarioDetails(),false) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public void IsScenarioAllowedToRun_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.IsScenarioAllowedToRun(A<String>._, A<string>._)).Returns(0);

            //Act
            var result = _scenariosController.IsScenarioAllowedToRun("test", "test",0) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void IsScenarioAllowedToRun_Success_AllowedToRun_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.IsScenarioAllowedToRun(A<String>._, A<string>._)).Returns(1);

            //Act
            var result = _scenariosController.IsScenarioAllowedToRun("test", "test",2) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void IsScenarioAllowedToRun_Empty_Inputs_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.IsScenarioAllowedToRun(A<String>._, A<string>._)).Returns(0);

            //Act
            var result = _scenariosController.IsScenarioAllowedToRun("", "",0) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public void IsScenarioAllowedToRun_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.IsScenarioAllowedToRun(A<String>._, A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.IsScenarioAllowedToRun("test", "test", 0) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }

        [Fact]
        public void DeleteScenarios_Success_Test()
        {
            //Act
            var result = _scenariosController.DeleteScenarios("Test", "") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }
        [Fact]
        public void DeleteScenarios_Null_TenantCode_Fail_Test()
        {
            //Act
            var result = _scenariosController.DeleteScenarios("", null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public void DeleteScenarios_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenariosService.DeleteScenarios(A<String>._, A<string[]>._)).Throws(new Exception());

            //Act
            var result = _scenariosController.DeleteScenarios("test", "test") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
    }
}
