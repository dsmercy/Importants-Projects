﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.SharedTestData;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenariosCommentsControllerTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioCommentsService _scenarioCommentsService;
        private readonly ScenariosCommentController _scenariosCommentController;
        private readonly IConfiguration _configuration;
        public ScenariosCommentsControllerTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenarioCommentsService = A.Fake<IScenarioCommentsService>();
            _configuration = A.Fake<IConfiguration>();
            _scenariosCommentController = new ScenariosCommentController(_scenarioCommentsService, _logHelper, _configuration);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioCommentData))]
        public void PostComment_Success_Test(ScenarioCommentModel comment)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.InsertScenarioComment(A<ScenarioCommentModel>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.PostComment(comment) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void PostComment_Empty_Comment_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.InsertScenarioComment(A<ScenarioCommentModel>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.PostComment(null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioCommentData))]
        public void PostComment_Exception_Test(ScenarioCommentModel comment)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.InsertScenarioComment(A<ScenarioCommentModel>._)).Throws(new Exception());

            //Act
            var result = _scenariosCommentController.PostComment(comment) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioCommentData))]
        public void UpdateComment_Success_Test(ScenarioCommentModel comment)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.UpdateScenarioComment(A<string>._, A<string>._, A<ScenarioCommentModel>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.UpdateComment("test ScenarioID", "test CommentId", comment) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void UpdateComment_Empty_Comment_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.UpdateScenarioComment(A<string>._, A<string>._, A<ScenarioCommentModel>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.UpdateComment("test ScenarioID", "test CommentId", null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioCommentData))]
        public void UpdateComment_Exception_Test(ScenarioCommentModel comment)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.UpdateScenarioComment(A<string>._, A<string>._, A<ScenarioCommentModel>._)).Throws(new Exception());

            //Act
            var result = _scenariosCommentController.UpdateComment("test ScenarioID", "test CommentId", comment) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }

        [Fact]
        public void GetAllComments_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetAllComments(A<string>._)).Returns(new List<ScenarioComment>());

            //Act
            var result = _scenariosCommentController.GetAllComments("test ScenarioId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void GetAllComments_Empty_Input_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetAllComments(A<string>._)).Returns(new List<ScenarioComment>());

            //Act
            var result = _scenariosCommentController.GetAllComments("") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Fact]
        public void GetAllComments_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetAllComments(A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosCommentController.GetAllComments("test ScenarioId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }

        [Fact]
        public void GetComment_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetComment(A<string>._, A<string>._)).Returns(new ScenarioComment());

            //Act
            var result = _scenariosCommentController.GetComment("test ScenarioId", "test commentId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void GetComment_Empty_Input_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetComment(A<string>._, A<string>._)).Returns(new ScenarioComment());

            //Act
            var result = _scenariosCommentController.GetComment("test ScenarioId", "") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Fact]
        public void GetComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.GetComment(A<string>._, A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosCommentController.GetComment("test ScenarioId", "test commentId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }

        [Fact]
        public void DeleteComment_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.DeletScenarioComment(A<string>._, A<string>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.DeleteComment("test ScenarioId", "test commentId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void DeleteComment_Empty_Input_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.DeletScenarioComment(A<string>._, A<string>._)).Returns(true);

            //Act
            var result = _scenariosCommentController.DeleteComment("test ScenarioId", "") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Fact]
        public void DeleteComment_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioCommentsService.DeletScenarioComment(A<string>._, A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosCommentController.DeleteComment("test ScenarioId", "test commentId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }
    }
}
