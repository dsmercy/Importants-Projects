﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenariosResultControllerTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioResultService _scenarioResultService;
        private readonly ScenariosResultController _scenariosController;
        public ScenariosResultControllerTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenarioResultService = A.Fake<IScenarioResultService>();
            _scenariosController = new ScenariosResultController(_scenarioResultService);
        }
        [Fact]
        public async void GetResultByInstanceId_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, Guid.NewGuid(), Guid.NewGuid())).Returns(new ScenarioResult());

            //Act
            var result =await _scenariosController.GetResultByInstanceId("test","test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public async void GetResultByInstanceId_Empty_scenarioId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, Guid.NewGuid(), Guid.NewGuid())).Returns(new ScenarioResult());

            //Act
            var result = await _scenariosController.GetResultByInstanceId("test", "test", Guid.Empty, Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public async void GetResultByInstanceId_Empty_TenentCode_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, Guid.NewGuid(), Guid.NewGuid())).Returns(new ScenarioResult());

            //Act
            var result = await _scenariosController.GetResultByInstanceId("", "test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public async void GetResultByInstanceId_Empty_SolutionId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, Guid.NewGuid(), Guid.NewGuid())).Returns(new ScenarioResult());

            //Act
            var result = await _scenariosController.GetResultByInstanceId("test", "", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public async void GetResultByInstanceId_Empty_InstanceId_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, Guid.NewGuid(), Guid.NewGuid())).Returns(new ScenarioResult());

            //Act
            var result = await _scenariosController.GetResultByInstanceId("test", "test", Guid.NewGuid(), Guid.Empty) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public async void GetResultByInstanceId_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.GetScenarioResultByInstanceId(A<string>._, A<Guid>._, A<Guid>._)).Throws(new Exception());

            //Act
            var result =await _scenariosController.GetResultByInstanceId("test", "test", Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
    }
}
