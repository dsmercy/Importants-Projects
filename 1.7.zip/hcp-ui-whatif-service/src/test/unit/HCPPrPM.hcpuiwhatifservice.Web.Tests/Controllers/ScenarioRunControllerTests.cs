﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenarioRunControllerTests
    {
        private readonly Mock<ILogHelper> _logHelper=new Mock<ILogHelper>();
        private readonly Mock<IScenarioRunService> _scenarioRunService= new Mock<IScenarioRunService>();
        private readonly Mock<IScenariosService> _scenariosService= new Mock<IScenariosService>();
        //private readonly ScenarioRunController _scenariosController;
        //public ScenarioRunControllerTests()
        //{
        //    _logHelper = A.Fake<ILogHelper>();
        //    _scenariosService = A.Fake<IScenariosService>();
        //    _scenarioRunService = A.Fake<IScenarioRunService>();
        //    _scenariosController = new ScenarioRunController(_scenarioRunService, _logHelper, _scenariosService);
        //}

        

        [Fact]
        public async void TriggerRunScenario_Success_Test()
        {
            string accessToken = "Bearer testToken";

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Authorization"] = accessToken;
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenarioRunService.Setup(x => x.ScenarioRunRequestToCalcProcessor(It.IsAny<string>(), It.IsAny<string>(), accessToken)).Returns("");

            //Act
            var result =await controller.TriggerRunScenario("Test", "Test") as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(202, resultStatus);
        }
        [Fact]
        public async void TriggerRunScenario_Empty_scenarioId_Fail_Test()
        {
            string accessToken = "Bearer testToken";

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Authorization"] = accessToken;
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenarioRunService.Setup(x => x.ScenarioRunRequestToCalcProcessor(It.IsAny<string>(), It.IsAny<string>(), accessToken)).Returns("");

            //Act
            var result = await controller.TriggerRunScenario("Test", "") as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public async void TriggerRunScenario_Empty_tenentCode_Fail_Test()
        {
            string accessToken = "Bearer testToken";

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Authorization"] = accessToken;
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenarioRunService.Setup(x => x.ScenarioRunRequestToCalcProcessor(It.IsAny<string>(), It.IsAny<string>(), accessToken)).Returns("");

            //Act
            var result = await controller.TriggerRunScenario("", "Test") as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public async void TriggerRunScenario_Empty_token_Fail_Test()
        {
            string accessToken = "Bearer testToken";

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Authorization"] = "";
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenarioRunService.Setup(x => x.ScenarioRunRequestToCalcProcessor(It.IsAny<string>(), It.IsAny<string>(), accessToken)).Returns("");

            //Act
            var result = await controller.TriggerRunScenario("test", "Test") as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public async void TriggerRunScenario_Exception_Test()
        {
            string accessToken = "Bearer testToken";

            var httpContext = new DefaultHttpContext();
            httpContext.Request.Headers["Authorization"] = accessToken;
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenarioRunService.Setup(x => x.ScenarioRunRequestToCalcProcessor(It.IsAny<string>(), It.IsAny<string>(), accessToken)).Throws<Exception>();

            //Act
            var result = await controller.TriggerRunScenario("Test", "Test") as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(500, resultStatus);
        }

        [Fact]
        public void UpdateScenarioStatus_Success_Test()
        {
            var httpContext = new DefaultHttpContext();
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenariosService.Setup(x => x.UpdateScenarioStatus(It.IsAny<Guid>(), It.IsAny<Guid>())).Returns(Guid.NewGuid());

            //Act
            var result = controller.UpdateScenarioStatus(Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void UpdateScenarioStatus_Empty_scenarioId_Fail_Test()
        {
            var httpContext = new DefaultHttpContext();
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenariosService.Setup(x => x.UpdateScenarioStatus(It.IsAny<Guid>(), It.IsAny<Guid>())).Returns(Guid.NewGuid());

            //Act
            var result = controller.UpdateScenarioStatus(Guid.Empty, Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void UpdateScenarioStatus_Empty_instanceId_Fail_Test()
        {
            var httpContext = new DefaultHttpContext();
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenariosService.Setup(x => x.UpdateScenarioStatus(It.IsAny<Guid>(), It.IsAny<Guid>())).Returns(Guid.NewGuid());

            //Act
            var result = controller.UpdateScenarioStatus(Guid.NewGuid(), Guid.Empty) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public void UpdateScenarioStatus_Exception_Test()
        {
            var httpContext = new DefaultHttpContext();
            var controller = new ScenarioRunController(_scenarioRunService.Object, _logHelper.Object, _scenariosService.Object)
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = httpContext
                }
            };

            _scenariosService.Setup(x => x.UpdateScenarioStatus(It.IsAny<Guid>(), It.IsAny<Guid>())).Throws<Exception>();

            //Act
            var result = controller.UpdateScenarioStatus(Guid.NewGuid(), Guid.NewGuid()) as ObjectResult;
            var resultStatus = result.StatusCode;

            //Assert
            Assert.Equal(500, resultStatus);
        }
    }

}
