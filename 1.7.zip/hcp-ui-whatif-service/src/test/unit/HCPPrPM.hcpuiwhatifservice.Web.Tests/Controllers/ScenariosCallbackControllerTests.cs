﻿using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenariosCallbackControllerTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioResultService _scenarioResultService;
        private readonly ScenariosCallbackController _scenariosController;
        public ScenariosCallbackControllerTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenarioResultService = A.Fake<IScenarioResultService>();
            _scenariosController = new ScenariosCallbackController(_scenarioResultService);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Success_Test(List<ScenarioResultModel> scenarioResult)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._,scenarioResult)).Returns(false);
            
            //Act
            var result = _scenariosController.InsertScenarioResult("Test", Guid.NewGuid(), Guid.NewGuid(), scenarioResult) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Empty_SolutionId_Fail_Test(List<ScenarioResultModel> scenarioResult)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Returns(false);

            //Act
            var result = _scenariosController.InsertScenarioResult("Test", Guid.NewGuid(), Guid.NewGuid(), null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Empty_ModelId_Fail_Test(List<ScenarioResultModel> scenarioResult)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Returns(false);

            //Act
            var result = _scenariosController.InsertScenarioResult("", Guid.NewGuid(), Guid.NewGuid(), scenarioResult) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Empty_ScenarioId_Fail_Test(List<ScenarioResultModel> scenarioResult)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Returns(false);

            //Act
            var result = _scenariosController.InsertScenarioResult("Test", Guid.Empty, Guid.NewGuid(), scenarioResult) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Empty_InstanceId_Fail_Test(List<ScenarioResultModel> scenarioResult)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Returns(false);

            //Act
            var result = _scenariosController.InsertScenarioResult("Test", Guid.NewGuid(), Guid.Empty, scenarioResult) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioResultData))]
        public void PostScenario_Exception_Test(List<ScenarioResultModel> scenarioResult)
        {
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.InsertScenarioResult(A<string>._, A<Guid>._, A<Guid>._, scenarioResult)).Throws(new Exception());

            //Act
            //Act
            var result = _scenariosController.InsertScenarioResult("Test", Guid.NewGuid(), Guid.NewGuid(), scenarioResult) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }

        [Fact]
        public void UpdateScenarioResultStatus_Success_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(false);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("Test", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void UpdateScenarioResultStatus_Success_true_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(true);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("Test", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Fact]
        public void UpdateScenarioResultStatus_Empty_ModelId_Fail_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(false);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void UpdateScenarioResultStatus_Empty_ScenarioId_Fail_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(false);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("test", Guid.Empty, Guid.NewGuid(), scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void UpdateScenarioResultStatus_Empty_InstanceId_Fail_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(false);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("test", Guid.NewGuid(), Guid.Empty, scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }
        [Fact]
        public void UpdateScenarioResultStatus_Empty_scenarioResultStatus_Fail_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Returns(false);

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("test", Guid.NewGuid(), Guid.NewGuid(), null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);
        }

        [Fact]
        public void UpdateScenarioResultStatus_Exception_Test()
        {
            ScenarioResultStatus scenarioResultModel = new ScenarioResultStatus { Message = "test", Status = "SUCCS" };
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioResultService.UpdateScenarioResultStatus(A<string>._, A<Guid>._, A<Guid>._, scenarioResultModel)).Throws(new Exception());

            //Act
            var result = _scenariosController.UpdateScenarioResultStatus("test", Guid.NewGuid(), Guid.NewGuid(), scenarioResultModel) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);
        }
    }
}
