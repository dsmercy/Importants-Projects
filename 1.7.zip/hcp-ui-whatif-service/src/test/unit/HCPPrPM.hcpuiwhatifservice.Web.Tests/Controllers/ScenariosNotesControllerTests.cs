﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using FakeItEasy;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using HCPPrPM.hcpuiwhatifservice.Web.Controllers;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.SharedTestData;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HCPPrPM.hcpuiwhatifservice.Web.Tests.Controllers
{
    public class ScenariosNotesControllerTests
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioNotesService _scenarioNotesService;
        private readonly ScenariosNoteController _scenariosNoteController;
        private readonly IConfiguration _configuration;
        public ScenariosNotesControllerTests()
        {
            _logHelper = A.Fake<ILogHelper>();
            _scenarioNotesService = A.Fake<IScenarioNotesService>();
            _configuration = A.Fake<IConfiguration>();
            _scenariosNoteController = new ScenariosNoteController(_scenarioNotesService, _logHelper, _configuration);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioNoteData))]
        public void PostNote_Success_Test(ScenarioNoteModel note)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.InsertScenarioNote(A<ScenarioNoteModel>._)).Returns(1);

            //Act
            var result = _scenariosNoteController.PostNote(note) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioNoteData))]
        public void PostNote_Success_Result2_Test(ScenarioNoteModel note)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.InsertScenarioNote(A<ScenarioNoteModel>._)).Returns(2);

            //Act
            var result = _scenariosNoteController.PostNote(note) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(409, resultStatus);
        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioNoteData))]
        public void PostNote_Success_Result3_Test(ScenarioNoteModel note)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.InsertScenarioNote(A<ScenarioNoteModel>._)).Returns(3);

            //Act
            var result = _scenariosNoteController.PostNote(note) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(401, resultStatus);
        }

        [Fact]
        public void PostNote_Empty_Note_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.InsertScenarioNote(A<ScenarioNoteModel>._)).Returns(1);

            //Act
            var result = _scenariosNoteController.PostNote(null) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Theory]
        [ClassData(typeof(SharedTestData.Scenario.ScenarioNoteData))]
        public void PostNote_Exception_Test(ScenarioNoteModel note)
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.InsertScenarioNote(A<ScenarioNoteModel>._)).Throws(new Exception());

            //Act
            var result = _scenariosNoteController.PostNote(note) as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }

        [Fact]
        public void GetNote_Success_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.GetLatestNote(A<string>._)).Returns(new ScenarioNote());

            //Act
            var result = _scenariosNoteController.GetNote("test ScenarioId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(200, resultStatus);

        }

        [Fact]
        public void GetNote_Empty_Input_Fail_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.GetLatestNote(A<string>._)).Returns(new ScenarioNote());

            //Act
            var result = _scenariosNoteController.GetNote("") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(400, resultStatus);

        }

        [Fact]
        public void GetNote_Exception_Test()
        {
            //Arrange 
            A.CallTo(() => _logHelper.LogMessage(A<string>._, A<string>._, A<string>._));
            A.CallTo(() => _scenarioNotesService.GetLatestNote( A<string>._)).Throws(new Exception());

            //Act
            var result = _scenariosNoteController.GetNote("test ScenarioId") as ObjectResult;
            var resultStatus = result.StatusCode;
            //Assert
            Assert.Equal(500, resultStatus);

        }

    }
}
