﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

namespace HCPPrPM.hcpuiwhatifservice.TodoService
{
    public class UpdateResult
    {
        public bool IsNotFoundError { get; set; }

        public bool IsSuccess { get; set; }

        public TodoItem UpdatedItem { get; set; }
    }
}