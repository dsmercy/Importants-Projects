﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using System.Threading.Tasks;
using HCPPrPM.hcpuiwhatifservice.TodoService.DependentInterfaces;

namespace HCPPrPM.hcpuiwhatifservice.TodoService.Impl
{
    using Microsoft.Extensions.Logging;

    public class TodoService : ITodoService
    {
        private readonly ITodoRepository _todoRepository;

        private readonly ILogger<TodoService> _logger;

        public TodoService(ITodoRepository todoRepository, ILogger<TodoService> logger)
        {
            _todoRepository = todoRepository;
            _logger = logger;
        }

        public async Task<AddResult> Add(string title, string description)
        {
            //TODO: Add security input validation for title and description strings
            try
            {
                var item = new TodoItem
                {
                    CreatedTimeStamp = DateTime.UtcNow,
                    Description = description,
                    IsCompleted = false,
                    Title = title,
                    Id = Guid.NewGuid()
                };

                var success = await _todoRepository.AddItem(item);
                return new AddResult {IsSuccess = success, NewItem = success ? item : null};
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Unable to add new item with title: {TodoTitle} description: {TodoDescription}", title, description);
                return new AddResult {IsSuccess = false};
            }
        }

        public async Task<UpdateResult> Update(Guid id, string title, string description, bool? isFlagged)
        {
            try
            {
               if (id == Guid.Empty)
                   return new UpdateResult { UpdatedItem = null, IsSuccess = false, IsNotFoundError = true };

               if (await _todoRepository.RemoveItem(id, out var item))
               {
                   if (title != null)
                       item.Title = title;
                   if (description != null)
                       item.Description = description;
                   if (isFlagged.HasValue)
                       item.IsCompleted = isFlagged.Value;

                   await _todoRepository.AddItem(item);
                   return new UpdateResult {UpdatedItem = item, IsSuccess = true, IsNotFoundError = false};
               }
               else
               {
                   return new UpdateResult {UpdatedItem = null, IsSuccess = false, IsNotFoundError = true};
               }
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Exception: unable to add update item with id = '{TodoId}' title = '{TodoTitle}' description = '{TodoDescription}' isFlagged = '{TodoIsFlagged}'", id, title, description, isFlagged);
                return new UpdateResult {UpdatedItem = null, IsSuccess = false, IsNotFoundError = false};
            }
        }

        public async Task<GetResults> GetAll()
        {
            var failedResult = new GetResults {IsSuccess = false, Items = new TodoItem[0]};
            try
            {
                var items = await _todoRepository.GetAllItems();
                return items == null ? failedResult : new GetResults {IsSuccess = true, Items = items};
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Unable to get all items");
                return failedResult;
            }
        }

        public async Task<GetResult> GetById(Guid id)
        {
            var failResult = new GetResult {IsSuccess = false};
            if (id == Guid.Empty)
                return failResult;

            try
            {
                var item = await _todoRepository.GetItem(id);
                return new GetResult {IsSuccess = item != null, Item = item};
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Unable to get item with id = {TodoId}", id);
                return failResult;
            }
        }

        public async Task<DeleteResult> Delete(Guid id)
        {
            try
            {
                if (id == Guid.Empty)
                    throw new ArgumentException();

                return await _todoRepository.RemoveItem(id)
                    ? new DeleteResult {IsSuccess = true, IsNotFoundError = false}
                    : new DeleteResult {IsSuccess = false, IsNotFoundError = true};
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Unable to delete item with id: {TodoId}", id);
                return new DeleteResult {IsSuccess = false, IsNotFoundError = false};
            }
        }
    }
}