﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.TodoService
{
    

    public interface ITodoService
    {
        Task<GetResults> GetAll();

        Task<AddResult> Add(string title, string description);

        Task<UpdateResult> Update(Guid id, string title, string description, bool? isFlagged);

        Task<DeleteResult> Delete(Guid id);

        Task<GetResult> GetById(Guid id);
    }
}