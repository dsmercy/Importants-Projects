// ************************************************************************
// *****      COPYRIGHT 2014 - 2018 HONEYWELL INTERNATIONAL SARL      *****
// ************************************************************************

namespace HCPPrPM.hcpuiwhatifservice.Web.ExternalServices
{
    using System.Threading.Tasks;
    using Refit;

    //Built using Refit in startup
    //see refit https://github.com/reactiveui/refit
    //To use this service in your controller or other services, include a parameter in your constructor of type IDependencyService and it will be injected
    public interface IDependencyService
    {
        //Note: This is an illustrative example of how to call a rest method on another endpoint, modify to fit your service
        [Get("/api/users")]
        Task<string> GetUsers();

        //Note: This is an illustrative example of how to call a rest method on another endpoint, modify to fit your service
        [Get("/api/organizations")]
        Task<string> GetOrganizations();

        //Note: This is assuming that your downstream service implements a standard liveness check,
        //and this method will be used by DependencyLivenessCheck to validate that the downstream service
        //is responding on liveness
        [Get("/health/liveness")]
        Task<string> GetLiveness();
    }
}