﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{

    /// <summary>
    /// ScenariosRunController
    /// </summary>
    [Route("api/v1/{tenantCode}/runscenario")]
    [Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenarioRunController : ControllerBase
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioRunService _scenarioRunService;
        private readonly IScenariosService scenariosService;
        public ScenarioRunController(IScenarioRunService scenarioRunService, ILogHelper logHelper, IScenariosService scenariosService)
        {
            _logHelper = logHelper;
            _scenarioRunService = scenarioRunService;
            this.scenariosService = scenariosService;
        }
        /// <summary>
        /// TriggerRunScenario
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        [HttpPost("{scenarioId}")]
        public async Task<IActionResult> TriggerRunScenario([FromRoute] string tenantCode, [FromRoute] string scenarioId)
        {
            try
            {
                string accessToken = "";
                if (!String.IsNullOrEmpty(Request.Headers["Authorization"]))
                {
                    accessToken = Request.Headers["Authorization"];
                }
                else
                {
                    const string errorMessage = "No Authorization token available";
                    _logHelper.LogMessage("Error", "ScenarioRunController | SendRunScenariotoCalcProcessor", errorMessage);
                    return SendResponseWithJobId(400, null, errorMessage);
                }
                _logHelper.LogMessage("INFO", "ScenarioRunController | Trigger RunScenario", "run scenario start " + scenarioId);

                if (String.IsNullOrEmpty(scenarioId)|| String.IsNullOrEmpty(tenantCode))
                {
                    const string errorMessage = "ScenarioId or tenantCode is missing";
                    _logHelper.LogMessage("Error", "ScenarioRunController | RunScenario", errorMessage);
                    return SendResponseWithJobId(400, null, errorMessage);
                }
                string status = _scenarioRunService.ScenarioRunRequestToCalcProcessor(tenantCode, scenarioId, accessToken);
                _logHelper.LogMessage("Info", "ScenarioRunController | Trigger RunScenario", $"Run Scenario is successful for Scenario Id: {scenarioId }.");
                return SendResponseWithJobId(202, status, null);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("Error", "ScenarioRunController | Trigger RunScenario", $"Run Scenario failed for Scenario Id: {scenarioId } .");
                return SendResponseWithJobId(500, null, ex.Message);
            }
        }

        /// Update a Scenario Status
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        [HttpPut("Scenarios/{scenarioId}/{instanceId}")]
        public IActionResult UpdateScenarioStatus([FromRoute] Guid scenarioId, [FromRoute] Guid instanceId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario started with scenarioId {scenarioId}");
                if (instanceId == Guid.Empty || scenarioId == Guid.Empty)
                {
                    const string errorMessage = "instanceId or senarioId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", errorMessage);
                    return SendResponse(400, errorMessage);
                }

                Guid scenarioIdUpdated = this.scenariosService.UpdateScenarioStatus(scenarioId, instanceId);
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario success, scenarioId {scenarioId}");
                return SendResponse(200, scenarioIdUpdated);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", $"Update scenario failed with id: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }
        [ExcludeFromCodeCoverage]
        private IActionResult SendResponseWithJobId(int statusCode, string jobId, string errorMessage)
        {
            JObject res = new JObject();
            res["JobId"] = jobId;
            res["ErrorMessage"] = errorMessage;
            return SendResponse(statusCode, res);
        }
        [ExcludeFromCodeCoverage]
        private IActionResult SendResponse(int statusCode, object value)
        {
            var res = new JsonResult(value).Value;
            if (statusCode == 200)
            {
                return Ok(res);
            }
            else
            {
                return StatusCode(statusCode, res);
            }
        }

    }

}
