﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    /// <summary>
    /// ScenariosResultController
    /// </summary>
    [Route("api/v1/{tenantCode}/{solutionId}/scenarioresult")]
    [Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenariosResultController : ControllerBase
    {

        private readonly IScenarioResultService scenarioResultService;

        readonly static Logger logger = new Logger();

        /// <summary>
        /// Scenarios Controller Constructor
        /// </summary>
        /// <param name="_scenarioResultService"></param>
        public ScenariosResultController(IScenarioResultService _scenarioResultService)
        {
            scenarioResultService = _scenarioResultService;
        }

        /// <summary>
        /// Get Scenario Result for given instance id
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        [HttpGet("{scenarioId}/{instanceId}")]
        public async Task<IActionResult> GetResultByInstanceId([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromRoute] Guid scenarioId, [FromRoute] Guid instanceId)
        {
            try
            {
                logger.LogMessage("INFO", "ScenarioResultController | GetResultByInstanceId", "started to fetch Scenario Result data");
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId) || scenarioId == Guid.Empty || instanceId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or Solution Id or senarioId or instanceId is missing";
                    logger.LogMessage("ERROR", "ScenarioResultController | GetResultByInstanceId", errorMessage);
                    return BadRequest(errorMessage);
                }
                var scenarioResultData = await this.scenarioResultService.GetScenarioResultByInstanceId(tenantCode, scenarioId, instanceId);
                logger.LogMessage("INFO", "ScenarioResultController | GetResultByInstanceId", "Scenario Result data fetch success");
                return Ok(scenarioResultData);
            }
            catch (Exception ex)
            {
                logger.LogMessage("ERROR", "ScenarioResultController | GetResultByInstanceId", $"Scenario result fetch failed with scenarioId: {scenarioId}, " + $"instanceId: {instanceId} and error message: {ex.Message}");
                return StatusCode(500, ex.Message);
            }
        }

    }    
}
