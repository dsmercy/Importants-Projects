﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Authorization;
using Honeywell.PMT.HCP.CPS.Api.Auth;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    /// <summary>
    /// Scenario Notes Controller
    /// </summary>
    [Route("api/v1/notes")]
    [Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenariosNoteController : Controller
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioNotesService _scenarioNotesService;
        private readonly IConfiguration _configuration;
        public ScenariosNoteController(IScenarioNotesService scenarioNotesService, ILogHelper logHelper, IConfiguration configuration)
        {
            _logHelper = logHelper;
            _scenarioNotesService = scenarioNotesService;
            _configuration = configuration;
        }

        /// <summary>
        /// Get latest note
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <returns></returns>
        [HttpGet("{scenarioId}")]
        public IActionResult GetNote([FromRoute] string scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosNoteController | GetNote", "GetNote start with scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(scenarioId))
                {
                    const string errorMessage = "scenarioId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosNoteController | GetNote", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                ScenarioNote note = _scenarioNotesService.GetLatestNote(scenarioId);

                _logHelper.LogMessage("DEBUG", "ScenariosNoteController | GetNote", "GetNote success with scenarioId: " + scenarioId);
                _logHelper.LogMessage("INFO", "ScenariosNoteController | GetNote", "GetNote success with scenarioId: " + scenarioId);
                _logHelper.LogMessage("WARN", "ScenariosNoteController | GetNote", "GetNote success with scenarioId: " + scenarioId);
                return SendResponse(200, note);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosNoteController | GetNote", $"GetNote failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        /// <summary>
        /// Post note
        /// </summary>
        /// <param name="note"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostNote([FromBody] ScenarioNoteModel note)
        {
            if (note == null)
            {
                const string errorMessage = "note can not be null";
                _logHelper.LogMessage("ERROR", "ScenariosNoteController | PostNote", errorMessage);
                return SendResponse(400, errorMessage);
            }
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosNoteController | PostNote", "PostNote start");

                int noteResult = _scenarioNotesService.InsertScenarioNote(note);

                if (noteResult == Convert.ToInt32(NumberConstants.One))
                {
                    _logHelper.LogMessage("INFO", "ScenariosNoteController | PostNote", "PostNote success with scenarioId: " + note.ScenarioId);
                    return SendResponse(200, "note Inserted");
                }
                else if (noteResult == Convert.ToInt32(NumberConstants.two))
                {
                    return Conflict("Provided scenarioId does not exists");
                }
                else
                {
                    return Unauthorized("User is not authorised to add notes");
                }
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosNoteController | PostNote", $"PostNote failed scenarioId: {note.ScenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }
        [ExcludeFromCodeCoverage]
        private IActionResult SendResponse(int statusCode, object value)
        {
            var res = new JsonResult(value).Value;
            if (statusCode == 200)
            {
                return Ok(res);
            }
            else
            {
                return StatusCode(statusCode, res);
            }
        }

    }
}
