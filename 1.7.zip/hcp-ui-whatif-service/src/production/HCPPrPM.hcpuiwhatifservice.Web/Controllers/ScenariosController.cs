﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    /// <summary>
    /// Scenarios Controller
    /// </summary>
    [Route("api/v1/{tenantCode}/{solutionId}/scenarios")]
    //[Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenariosController : ControllerBase
    {
        private readonly ILogHelper _logHelper; 
        private readonly IScenariosService _scenariosService;
        private readonly IConfiguration _configuration;
        public ScenariosController(IScenariosService scenariosService, ILogHelper logHelper, IConfiguration configuration)
        {
            _logHelper = logHelper;
            _scenariosService = scenariosService;
            _configuration = configuration;
        }
        /// <summary>
        /// Get all scenarios By Model Id
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAllScenarios([FromRoute] string tenantCode, [FromRoute] string solutionId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | GetAllScenarios", "get all scenarios start modelId: " + tenantCode);
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId))
                {
                    const string errorMessage = "ModelId or Solution Id is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | GetAllScenarios", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                List<ScenarioDetails> scenarios = _scenariosService.GetAllScenariosByModelId(tenantCode, solutionId);
                scenarios = scenarios.OrderByDescending(s => s.CreatedDateTime).ToList<ScenarioDetails>();

                _logHelper.LogMessage("INFO", "ScenariosController | GetAllScenarios", "get all scenarios success modelId: " + tenantCode);
                return SendResponse(200, scenarios);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | GetAllScenarios", $"get all scenarios failed modelId: {tenantCode} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }
        /// <summary>
        /// Get Scenario By Scenario Id
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <param name="scenarioId"></param>
        /// <returns></returns>
        [HttpGet("{scenarioId}")]
        public IActionResult GetScenario([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromRoute] Guid scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | GetScenario", "get scenario started, scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId) || scenarioId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or Solution Id or scenario id is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | GetScenario", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                ScenarioDetails scenario = _scenariosService.GetScenarioByScenarioId(tenantCode, scenarioId);
                _logHelper.LogMessage("INFO", "ScenariosController | GetScenario", "get scenario success scenarioid: " + scenarioId);
                return SendResponse(200, scenario);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | GetScenario", $"get scenario failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }
        /// <summary>
        /// Insert a Scenario
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <param name="scenario"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostScenario([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromBody] ScenarioDetails scenario)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | PostScenario", "insert scenario started ");
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId))
                {
                    const string errorMessage = "ModelId or Solution Id is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | PostScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                if (scenario == null || String.IsNullOrEmpty(scenario.ScenarioName))
                {
                    const string errorMessage = "ScenarioName is required";
                    _logHelper.LogMessage("ERROR", "ScenariosController | PostScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                scenario.ScenarioId = Guid.NewGuid();
                bool isDuplicatedName = _scenariosService.CheckDuplicateNames(tenantCode, scenario.ScenarioName, scenario.ScenarioId);
                if (isDuplicatedName)
                {
                    const string errorMessage = "Scenario Name already exists";
                    _logHelper.LogMessage("ERROR", "ScenariosController | PostScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                scenario.SolutionId = solutionId;
                Guid scenarioId =  _scenariosService.InsertScenario(tenantCode, scenario);
                _logHelper.LogMessage("INFO", "ScenariosController | PostScenario", $"insert scenario success, scenarioId {scenario.ScenarioId} ");
                return SendResponseWithScenarioId(200, scenarioId, null);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | PostScenario", $"Post scenario failed with message: {ex.Message}");
                return SendResponseWithScenarioId(500, null, ex.Message);
            }
        }
        /// <summary>
        /// Delete a Scenario
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        [HttpDelete("{scenarioId}/{instanceId}")]
        public IActionResult DeleteScenario([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromRoute] Guid scenarioId, [FromRoute]Guid instanceId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | DeleteScenario", $"delete scenario started with scenario id {scenarioId} and instanceId {instanceId}");
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId) || scenarioId == Guid.Empty || instanceId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or Solution Id or senarioId or Instance Id is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | DeleteScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                bool deleteScenarioResult = _scenariosService.DeleteScenario(tenantCode, scenarioId, instanceId);
                if(deleteScenarioResult)
                {
                    _logHelper.LogMessage("INFO", "ScenariosController | DeleteScenario", $"delete scenario success, scenarioId {scenarioId} and Instance Id {instanceId}");
                    return SendResponseWithScenarioId(200, scenarioId, null);
                }
                else
                {
                    _logHelper.LogMessage("ERROR", "ScenariosController | DeleteScenario", $"delete scenario Failed, scenarioId {scenarioId} and Instance Id {instanceId}");
                    return SendResponseWithScenarioId(200, scenarioId, $"Scenario with this ScenarioId {scenarioId} not found ");
                }
                
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | DeleteScenario", $"Delete scenario failed with id: {scenarioId} and message: {ex.Message}");
                return SendResponseWithScenarioId(500, null, ex.Message);
            }
        }
        /// Update a Scenario
        /// </summary>
        /// <param name="tenantCode"></param>
        /// <param name="solutionId"></param>
        /// <param name="scenarioId"></param>
        /// <param name="scenario"></param>
        /// <returns></returns>
        [HttpPut("{scenarioId}")]
        public IActionResult UpdateScenario([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromRoute] Guid scenarioId,
            [FromBody] ScenarioDetails scenario, [FromQuery] bool IsNameDescUpdate)
        {
            try
            {
                Guid scenarioIdUpdated;
                bool IsScenarioUpdated = false;
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario started with scenarioId {scenarioId}");
                if (String.IsNullOrEmpty(tenantCode) || String.IsNullOrEmpty(solutionId) || scenarioId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or Solution Id or senarioId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                if (scenario == null || scenario.ScenarioName == ""|| scenario.ScenarioName == null)
                {
                    const string errorMessage = "Scenario Along with Scenario Name is required";
                    _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", errorMessage);
                    return SendResponseWithScenarioId(400, null, errorMessage);
                }
                if (!IsNameDescUpdate)
                {
                    scenarioIdUpdated = _scenariosService.UpdateScenario(tenantCode, scenarioId, scenario);
                }
                else {
                      (IsScenarioUpdated, scenarioIdUpdated)  = _scenariosService.UpdateScenarioNameDesc(tenantCode, scenarioId, scenario);

                    if (!IsScenarioUpdated)
                    { return SendResponseWithScenarioId(401, null, $"User: {scenario.CreatedBy} not authorized to update this scenario"); }
                }
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario success, scenarioId {scenarioId}");
                return SendResponseWithScenarioId(200, scenarioIdUpdated, null);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", $"Update scenario failed with id: {scenarioId} and message: {ex.Message}");
                return SendResponseWithScenarioId(500, null, ex.Message);
            }
        }
        //[ExcludeFromCodeCoverage]
        private IActionResult SendResponseWithScenarioId(int statusCode, Guid? scenarioId, string errorMessage)
        {
            JObject res = new JObject();
            res["ScenarioId"] = scenarioId;
            res["ErrorMessage"] = errorMessage;
            return SendResponse(statusCode, res);
        }
        //[ExcludeFromCodeCoverage]
        private IActionResult SendResponse(int statusCode, object value)
        {
            var res = new JsonResult(value).Value;
            if (statusCode == 200)
            {
                return Ok(res);
            }
            else
            {
                return StatusCode(statusCode, res);
            }
        }

        [HttpGet]
        [Route("IsScenarioAllowedToRun/{noOfAllowedRuns}")]
        public IActionResult IsScenarioAllowedToRun([FromRoute] string tenantCode, [FromRoute] string solutionId, [FromRoute] int noOfAllowedRuns)
        {
            try
            {
                var runScenarioCheck = new RunScenarioCheck();
                _logHelper.LogMessage("INFO", "ScenariosController | IsScenarioAllowedToRun", "IsScenarioAllowedToRun started");
                if (!String.IsNullOrEmpty(tenantCode) || !String.IsNullOrEmpty(solutionId))
                {
                    int scenarioRunsFrequency = 0;
                    int.TryParse(_configuration["ScenarioRunsFrequency"], out scenarioRunsFrequency);

                    int noOfSuccessfulScenarios = _scenariosService.IsScenarioAllowedToRun(tenantCode, solutionId);

                    if (noOfAllowedRuns != 0)
                    {
                        runScenarioCheck.AllowToRun = noOfSuccessfulScenarios < noOfAllowedRuns;
                    }
                    else
                    {
                        int.TryParse(_configuration["ScenarioRunsAllowed"], out noOfAllowedRuns);
                        runScenarioCheck.AllowToRun = noOfSuccessfulScenarios < noOfAllowedRuns;
                    }
                    runScenarioCheck.NoOfAllowedRuns = noOfAllowedRuns;
                    runScenarioCheck.NoOfSuccessfulScenarios = noOfSuccessfulScenarios;
                    runScenarioCheck.ScenarioRunsFrequency = scenarioRunsFrequency;

                }
                else
                {
                    const string errorMessage = "ModelId or SolutionId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | IsScenarioAllowedToRun", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                _logHelper.LogMessage("INFO", "ScenariosController | IsScenarioAllowedToRun", "IsScenarioAllowedToRun success");
                return SendResponse(200, runScenarioCheck);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | IsScenarioAllowedToRun", $"IsScenarioAllowedToRun failed | and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        
        [HttpDelete("DeleteScenarios")]
        public IActionResult DeleteScenarios([FromRoute] string tenantCode, [FromQuery] string scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario started");
                if (String.IsNullOrEmpty(tenantCode))
                {
                    const string errorMessage = "tenantCode is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosController | DeleteScenarios", errorMessage);
                    return SendResponse(400, errorMessage);
                }

                bool isDeleted = _scenariosService.DeleteScenarios(tenantCode, scenarioId.Split(','));
                _logHelper.LogMessage("INFO", "ScenariosController | UpdateScenario", $"update scenario success");
                return SendResponse(200, isDeleted);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosController | UpdateScenario", $"Update scenario failed with message: {ex.Message}");
                return SendResponseWithScenarioId(500, null, ex.Message);
            }
        }


    }
}
