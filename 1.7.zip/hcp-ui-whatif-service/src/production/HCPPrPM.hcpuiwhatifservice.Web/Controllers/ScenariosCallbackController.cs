﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    /// <summary>
    /// ScenariosResultController
    /// </summary>
    [Route("api/v1/{modelId}/Scenarios")]
    //[Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenariosCallbackController : ControllerBase
    {

        private readonly IScenarioResultService scenarioResultService;

        readonly static Logger logger = new Logger();

        /// <summary>
        /// Scenarios Controller Constructor
        /// </summary>
        /// <param name="_scenarioResultService"></param>
        public ScenariosCallbackController(IScenarioResultService _scenarioResultService)
        {
            scenarioResultService = _scenarioResultService;
        }

        /// <summary>
        /// Insert Scenario Result for given instance id
        /// </summary>
        /// <param name="modelId"></param>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        [HttpPost("{scenarioId}/{instanceId}")]
        public IActionResult InsertScenarioResult([FromRoute] string modelId, [FromRoute] Guid scenarioId
            , [FromRoute] Guid instanceId, [FromBody] List<ScenarioResultModel> scenarioResult)
        {
            try
            {
                logger.LogMessage("INFO", "ScenariosCallbackController | InsertScenarioResult", "started to InsertScenarioResult");
                if (String.IsNullOrEmpty(modelId) || scenarioId == Guid.Empty || instanceId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or senarioId or instanceId is missing";
                    logger.LogMessage("ERROR", "ScenarioResultController | InsertScenarioResult", errorMessage);
                    return BadRequest(errorMessage);
                }
                if (scenarioResult == null)
                {
                    const string errorMessage = "scenarioResult is missing";
                    logger.LogMessage("ERROR", "ScenarioResultController | InsertScenarioResult", errorMessage);
                    return BadRequest(errorMessage);
                }
                var scenarioResultData = this.scenarioResultService.InsertScenarioResult(modelId, scenarioId, instanceId, scenarioResult);

                logger.LogMessage("INFO", "ScenarioResultController | InsertScenarioResult", "Scenario Result data Insert success");
                return SendResponse(200, instanceId);
            }
            catch (Exception ex)
            {
                logger.LogMessage("ERROR", "ScenarioResultController | InsertScenarioResult", $"InsertScenarioResult failed with scenarioId: {scenarioId}, " + $"instanceId: {instanceId} and error message: {ex.Message}");
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        /// Update Scenario Result Status for given instance id
        /// </summary>
        /// <param name="modelId"></param>
        /// <param name="scenarioId"></param>
        /// <param name="instanceId"></param>
        /// <param name="scenarioResult"></param>
        /// <returns></returns>
        [HttpPost("{scenarioId}/{instanceId}/status")]
        public IActionResult UpdateScenarioResultStatus([FromRoute] string modelId, [FromRoute] Guid scenarioId
            , [FromRoute] Guid instanceId, [FromBody] ScenarioResultStatus scenarioResultStatus)
        {
            try
            {
                logger.LogMessage("INFO", "ScenariosCallbackController | UpdateScenarioResultStatus", "started to UpdateScenarioResultStatus");
                if (String.IsNullOrEmpty(modelId) || scenarioId == Guid.Empty || instanceId == Guid.Empty)
                {
                    const string errorMessage = "ModelId or senarioId or instanceId is missing";
                    logger.LogMessage("ERROR", "ScenarioResultController | UpdateScenarioResultStatus", errorMessage);
                    return BadRequest(errorMessage);
                }
                if (scenarioResultStatus == null)
                {
                    const string errorMessage = "scenarioResultStatus is missing";
                    logger.LogMessage("ERROR", "ScenarioResultController | UpdateScenarioResultStatus", errorMessage);
                    return BadRequest(errorMessage);
                }
                bool scenarioResultData = this.scenarioResultService.UpdateScenarioResultStatus(modelId, scenarioId, instanceId, scenarioResultStatus);

                if (scenarioResultData)
                {
                    logger.LogMessage("INFO", "ScenarioResultController | UpdateScenarioResultStatus", "UpdateScenarioResultStatus success");
                    return SendResponse(200, "Scenario result status updated successfully");
                }
                else
                {
                    return SendResponse(200, "Please provide correct status!");
                }


            }
            catch (Exception ex)
            {
                logger.LogMessage("ERROR", "ScenarioResultController | UpdateScenarioResultStatus", $"UpdateScenarioResultStatus failed with scenarioId: {scenarioId}, " + $"instanceId: {instanceId} and error message: {ex.Message}");
                return StatusCode(500, ex.Message);
            }
        }
        [ExcludeFromCodeCoverage]
        private IActionResult SendResponse(int statusCode, object value)
        {
            var res = new JsonResult(value).Value;
            if (statusCode == 200)
            {
                return Ok(res);
            }
            else
            {
                return StatusCode(statusCode, res);
            }
        }

    }
}