﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Authorization;
using Honeywell.PMT.HCP.CPS.Api.Auth;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    /// <summary>
    /// Scenario Comments Controller
    /// </summary>
    [Route("api/v1/comments")]
    [Authorize(AuthenticationSchemes = DefaultSchemes.TokenValidationScheme)]
    [ApiController]
    public class ScenariosCommentController : Controller
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioCommentsService _scenarioCommentsService;
        private readonly IConfiguration _configuration;
        public ScenariosCommentController(IScenarioCommentsService scenarioCommentsService, ILogHelper logHelper, IConfiguration configuration)
        {
            _logHelper = logHelper;
            _scenarioCommentsService = scenarioCommentsService;
            _configuration = configuration;
        }

        /// <summary>
        /// Get all scenario comments By scenario id
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <returns></returns>
        [HttpGet("{scenarioId}")]
        public IActionResult GetAllComments([FromRoute] string scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosCommentController | GetAllComments", "GetAllComments start with scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(scenarioId))
                {
                    const string errorMessage = "scenarioId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosCommentController | GetAllComments", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                List<ScenarioComment> comments = _scenarioCommentsService.GetAllComments(scenarioId);

                _logHelper.LogMessage("INFO", "ScenariosCommentController | GetAllComments", "GetAllComments success with scenarioId: " + scenarioId);
                return SendResponse(200, comments);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | GetAllComments", $"GetAllComments failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        /// <summary>
        /// Get comment
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <param name="commentId"></param>
        /// <returns></returns>
        [HttpGet("{scenarioId}/{commentId}")]
        public IActionResult GetComment([FromRoute] string scenarioId, [FromRoute] string commentId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosCommentController | GetComment", "GetComment start with scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(scenarioId)|| String.IsNullOrEmpty(commentId))
                {
                    const string errorMessage = "scenarioId is missing or commentId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosCommentController | GetComment", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                ScenarioComment comment = _scenarioCommentsService.GetComment(scenarioId,commentId);

                _logHelper.LogMessage("INFO", "ScenariosCommentController | GetComment", "GetComment success with scenarioId: " + scenarioId);
                return SendResponse(200, comment);
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | GetComment", $"GetComment failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        /// <summary>
        /// Post comment
        /// </summary>
        /// <param name="comment"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostComment([FromBody] ScenarioCommentModel comment)
        {
            if (comment == null)
            {
                const string errorMessage = "comment can not be null";
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | PostComment", errorMessage);
                return SendResponse(400, errorMessage);
            }
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosCommentController | PostComment", "PostComment start");

                bool commentResult = _scenarioCommentsService.InsertScenarioComment(comment);

                if (commentResult)
                {
                    _logHelper.LogMessage("INFO", "ScenariosCommentController | PostComment", "PostComment success with scenarioId: " + comment.ScenarioId);
                    return SendResponse(200, "comment Inserted");
                }
                else
                {
                    return SendResponse(204, "Provided scenarioId does not exists");
                }
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | PostComment", $"PostComment failed scenarioId: {comment.ScenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        /// <summary>
        /// Update comment
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <param name="commentId"></param>
        /// <param name="comment"></param>
        /// <returns></returns>
        [HttpPut("{scenarioId}/{commentId}")]
        public IActionResult UpdateComment([FromRoute] string scenarioId, [FromRoute] string commentId, [FromBody] ScenarioCommentModel comment)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosCommentController | UpdateComment", "UpdateComment start with scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(scenarioId) || String.IsNullOrEmpty(commentId) || comment==null)
                {
                    const string errorMessage = "scenarioId is missing or commentId is missing or comment is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosCommentController | GetComment", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                bool commentResult = _scenarioCommentsService.UpdateScenarioComment(scenarioId,commentId, comment);
                if (commentResult)
                {
                    _logHelper.LogMessage("INFO", "ScenariosCommentController | UpdateComment", "UpdateComment success with scenarioId: " + scenarioId);
                    return SendResponse(200, "Comment Updated");
                }
                else {
                    return SendResponse(204, commentResult);
                }
                
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | UpdateComment", $"UpdateComment failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        /// <summary>
        /// Delete Comment
        /// </summary>
        /// <param name="scenarioId"></param>
        /// <param name="commentId"></param>
        /// <returns></returns>
        [HttpDelete("{scenarioId}/{commentId}")]
        public IActionResult DeleteComment([FromRoute] string scenarioId, [FromRoute] string commentId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosCommentController | DeleteComment", "DeleteComment start with scenarioId: " + scenarioId);
                if (String.IsNullOrEmpty(scenarioId) || String.IsNullOrEmpty(commentId))
                {
                    const string errorMessage = "scenarioId is missing or commentId is missing";
                    _logHelper.LogMessage("ERROR", "ScenariosCommentController | DeleteComment", errorMessage);
                    return SendResponse(400, errorMessage);
                }
                bool commentResult = _scenarioCommentsService.DeletScenarioComment(scenarioId, commentId);
                if (commentResult)
                {
                    _logHelper.LogMessage("INFO", "ScenariosCommentController | DeleteComment", "DeleteComment success with scenarioId: " + scenarioId);
                    return SendResponse(200, "Comment Deleted");
                }
                else
                {
                    return SendResponse(204, commentResult);
                }
                
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosCommentController | DeleteComment", $"DeleteComment failed scenarioId: {scenarioId} and message: {ex.Message}");
                return SendResponse(500, ex.Message);
            }
        }

        [ExcludeFromCodeCoverage]
        private IActionResult SendResponseWithScenarioId(int statusCode, Guid? scenarioId, string errorMessage)
        {
            JObject res = new JObject();
            res["ScenarioId"] = scenarioId;
            res["ErrorMessage"] = errorMessage;
            return SendResponse(statusCode, res);
        }
        [ExcludeFromCodeCoverage]
        private IActionResult SendResponse(int statusCode, object value)
        {
            var res = new JsonResult(value).Value;
            if (statusCode == 200)
            {
                return Ok(res);
            }
            else
            {
                return StatusCode(statusCode, res);
            }
        }

    }
}
