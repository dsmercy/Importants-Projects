﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using Microsoft.AspNetCore.Hosting;
using Prometheus;


namespace HCPPrPM.hcpuiwhatifservice.Web
{
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using System.Reflection;
    using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
    using log4net;
    using log4net.Config;
    using Microsoft.AspNetCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Serilog;

    [ExcludeFromCodeCoverage]
    public class Program
    {
        public static int Main(string[] args)
        {

            try
            {
                var metricsServer = new KestrelMetricServer(7005);
                metricsServer.Start();
                Log.Information("Starting web host");
                var host = BuildHost(args);
                ConfigureLogLevel.SetLogLevel();
                host.Run();
                
                return 0;
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Host terminated unexpectedly");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        private static IHost BuildHost(string[] args) => CreateHostBuilder(args)
            .ConfigureLogging((hostingContext, logging) =>
            {
                // Disable the built-in Microsoft logger.
                logging.ClearProviders();
                logging.AddLog4Net("log4net.config", true);
                logging.AddApplicationInsights();
            }).Build();

        private static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args).ConfigureWebHostDefaults(
                webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                    webBuilder.UseIISIntegration();
                    //webBuilder.UseKestrel(options => options.AddServerHeader = false);
                    webBuilder.ConfigureAppConfiguration((builderContext, config) =>
                    {
                        IWebHostEnvironment env = builderContext.HostingEnvironment;
                        config.SetBasePath(env.ContentRootPath)
                        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                        .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                        .AddEnvironmentVariables();
                    });
                });

    }
}
