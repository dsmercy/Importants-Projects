﻿// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using honeywell.cedevops.featuretoggleclient;
using honeywell.cedevops.featuretoggleclient.Impl;
using CeDevOps.WebApiHealthCheckHelpers;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Configuration;
using Polly;
using Prometheus;
using Refit;
using HCPPrPM.hcpuiwhatifservice.Web.ExternalServices;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Hosting;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config;
using Honeywell.HCPPrPM.cpsuibackendlibrary.EntitiesV2.Common;
using System.Net;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Auth;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using System.Reflection;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Api.Contracts;

namespace HCPPrPM.hcpuiwhatifservice.Web
{


    [ExcludeFromCodeCoverage]
    public class Startup
    {
        private readonly IConfiguration _configuration;
        ICustomLogger _logger;
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddSingleton<IConfiguration>(_configuration);
            services.Configure<BaseUrls>(_configuration.GetSection("BaseUrls"));
            services.Configure<SeeqConstants>(_configuration.GetSection("SeeqConstants"));
            services.Configure<BaseUrls>(_configuration.GetSection("WhatIfTables")); 
            services.AddSingleton<ILogHelper, LogHelper>();
            services.AddTransient<IMySqlDataClient, MySqlDataClient>();
            services.AddTransient<IScenarioRunService, ScenarioRunService>();
            services.AddTransient<IScenariosService, ScenariosService>();
            services.AddTransient<IScenarioStatusService, ScenarioStatusService>(); 
            services.AddTransient<IScenarioResultService, ScenarioResultService>();
            services.AddTransient<IScenarioCommentsService, ScenarioCommentsService>();
            services.AddTransient<IScenarioNotesService, ScenarioNotesService>();
            services.AddScoped<ICustomLogger, Logger>();
            // services.AddTransient<IScenarioRunService, ScenarioRunService>();
            services.AddSingleton(provider => FeatureToggleClientSingleton.Initialize(GetFeatureToggleClientConfig())); 
            _configuration["Whatif_CalcProcessor_API_URL"] = _configuration["BaseUrls:WhatifCalcProcessorApi"];
            AddHealthChecks(services);
            services.AddMvc().AddNewtonsoftJson();
            services.Configure<IISServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });
            var loghelper = services.BuildServiceProvider().GetService<ICustomLogger>();
            services.AddSwaggerDocument(config =>
            {
                config.PostProcess = document =>
                {
                    document.Info.Version = "v1";
                    document.Info.Title = "What-If 1.7 API";
                    document.Info.Description = "What-If 1.7 API";

                };
            });
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string authEndpoint;
            if ((_configuration[AppSettingConstants.TOKEN_VALIDATOR]) == AppSettingConstants.FORGE_VALIDATOR)
            {
                authEndpoint = _configuration[AppSettingConstants.FORGE_SSO_URL];
                services.AddScoped<ITokenValidator, ForgeValidator>();
                loghelper.LogMessage(LoggerConstants.info, MethodBase.GetCurrentMethod().DeclaringType.FullName, " Forge Validator auth enabled ");
            }
            else
            {
                loghelper.LogMessage(LoggerConstants.error, MethodBase.GetCurrentMethod().DeclaringType.FullName, "Missing Auth Endpoint");
                throw new ArgumentException("Missing Auth Endpoint");
            }

            services.AddScoped<IHCPAuthenticationHandler, HCPTenantAuthenticationHandler>();

            services.AddAuthentication(options => { options.DefaultScheme = DefaultSchemes.TenantValidationScheme; })
             .AddHoneywellAuthentication(DefaultSchemes.TenantValidationScheme, "Honeywell Auth", o =>
             {
                 o.IsTenantValidation = true;
                 o.Endpoint = authEndpoint;
                 o.Encoded = _configuration[AppSettingConstants.CWA_ENCODED_KEY];
             });

            services.AddAuthentication(options => { options.DefaultScheme = DefaultSchemes.TokenValidationScheme; })
              .AddHoneywellAuthentication(DefaultSchemes.TokenValidationScheme, "Honeywell Auth", o =>
              {
                  o.IsTenantValidation = false;
                  o.Endpoint = authEndpoint;
                  o.Encoded = _configuration[AppSettingConstants.CWA_ENCODED_KEY];
              });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.AddSecurityHeaders();
            app.UseOpenApi();
            app.UseSwaggerUi3();
            app.UseRouting();
            app.UseAuthorization();
            app.UseHttpMetrics();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapMetrics();
                endpoints.MapHealthChecks("/health/startup", new HealthCheckOptions { Predicate = registration => registration.Tags.Contains("startup") });
                endpoints.MapHealthChecks("/health/liveness", new HealthCheckOptions { Predicate = _ => false });
                endpoints.MapHealthChecks("/health/readiness", new HealthCheckOptions { Predicate = registration => registration.Tags.Contains("ready") });
                endpoints.MapControllers();
            });
        }

        private IFeatureToggleClientConfig GetFeatureToggleClientConfig()
        {
            var config = new FeatureToggleClientConfig()
            {
                SdkKey = RetrieveEnvironmentVariableValue("LAUNCHDARKLYSDKKEY"),
                EnvironmentName = RetrieveEnvironmentVariableValue("LAUNCHDARKLYENVIRONMENTNAME"),
                OfflineFlagJsonFile = RetrieveEnvironmentVariableValue("LAUNCHDARKLYOFFLINEFLAGJSONFILE")
            };
            return config;
        }

        private string RetrieveEnvironmentVariableValue(string environmentVariable)
        {
            var environmentVariableValue = "SetByDeployment";
            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable(environmentVariable)) != true)
            {
                environmentVariableValue = Environment.GetEnvironmentVariable(environmentVariable);
            }
            else
            {
                //Note, cannot inject logger in ConfigureServices until DotNetCore 5.
                Console.WriteLine($"There is no value found for the environment variable: {environmentVariable}");
            }
            return environmentVariableValue;
        }
        private void AddHealthChecks(IServiceCollection services)
        {
            var healthChecksBuilder = services.AddHealthChecks();
            healthChecksBuilder.ForwardToPrometheus();

            var dependencyServiceBaseUrl = _configuration.GetSection("DependencyBaseUrls").GetSection("Service1").Value;
            if (string.IsNullOrWhiteSpace(dependencyServiceBaseUrl) == false)
            {
                // create a Refit (auto-generated) dependency Http client using IHttpClientFactory and Circuit Breaker pattern.
                services.AddRefitClient<IDependencyService>().ConfigureHttpClient(c => c.BaseAddress = new Uri(dependencyServiceBaseUrl)).UseHttpClientMetrics()
                    .SetHandlerLifetime(TimeSpan.FromHours(1))
                    .AddTransientHttpErrorPolicy(
                        builder => builder.WaitAndRetryAsync(
                            new[] { TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(10) },
                            (result, span) => { Console.WriteLine("Retrying"); })).AddTransientHttpErrorPolicy(
                        builder => builder.CircuitBreakerAsync(
                            3,
                            TimeSpan.FromSeconds(30),
                            (result, span) => { Console.WriteLine("Circuit Broken"); },
                            () => { Console.WriteLine("Circuit Reset"); }));

                services.TryAddTransient<DependencyLivenessCheck<IDependencyService>>();

                healthChecksBuilder.AddCheck<DependencyLivenessCheck<IDependencyService>>("Dependency Liveness", tags: new[] { "startup" });
                // Note: Use the following one instead if another team misuses startup probe endpoint to provide a health check instead of liveness.
                // healthChecksBuilder.AddCheck<CachedHealthCheck<DependencyLivenessCheck<IDependencyService>>>("Dependency Liveness", tags: new[] {"startup"});
            }

            // Note: Here are some additional examples of dependency health checks that could be incorporated
            // healthChecksBuilder.AddSqlServer(connectionString: Configuration["Data:ConnectionStrings:Sample"])
            // healthChecksBuilder.AddUrlGroup(
            //     options =>
            //     {
            //         options.AddUri(new Uri("http://www.msftncsi.com/ncsi.txt")).UseGet().UseTimeout(TimeSpan.FromSeconds(10)).ExpectHttpCode(200);
            //     },
            //     "Startup Downstream dependencies",
            //     tags: new[] {"startup"})
        }

    }
}