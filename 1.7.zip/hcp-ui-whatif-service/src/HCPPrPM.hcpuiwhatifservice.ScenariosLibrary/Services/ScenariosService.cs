﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenariosService : IScenariosService
    {
        private readonly ILogHelper _logHelper;
        private readonly IScenarioStatusService _scenarioStatusService;
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly bool isUnitTest;
        private readonly IConfiguration _configuration;
        public ScenariosService(IMySqlDataClient mySqlDataClient, IScenarioStatusService scenarioStatusService, ILogHelper logHelper, IConfiguration configuration)
        {
            _logHelper = logHelper;
            _scenarioStatusService = scenarioStatusService;
            _mySqlDataClient = mySqlDataClient;
            _configuration = configuration;

        }
        public ScenariosService(IMySqlDataClient mySqlDataClient, IScenarioStatusService scenarioStatusService, ILogHelper logHelper, bool IsUnitTest)
        {
            _logHelper = logHelper;
            _scenarioStatusService = scenarioStatusService;
            _mySqlDataClient = mySqlDataClient;
            isUnitTest = IsUnitTest;
        }
        public List<ScenarioDetails> GetAllScenariosByModelId(string modelId,string solutionId)
        {
            List<ScenarioDetails> scenariosByModelId = new List<ScenarioDetails>();
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | GetAllScenariosByModelId", $"Get All scenarios started with modelId: {modelId}");
                List<ScenarioDetails> allScenarios = GetScenariosByModelId(modelId, solutionId);
                foreach (ScenarioDetails scenario in allScenarios)
                {
                    if (scenario.Instances != null)
                    {
                        scenario.Instances.ForEach(instance =>
                        {
                            ScenarioStatus status = _scenarioStatusService.GetStatusForUI(instance.ScenarioStatus);
                            instance.ScenarioStatus = status.Id.ToString();
                            instance.StatusCode = status.Code;
                            instance.StatusDescription = status.Description;
                        });
                    }
                    scenariosByModelId.Add(scenario);
                }
                _logHelper.LogMessage("INFO", "ScenariosService | GetAllScenariosByModelId", $"Get All scenarios complete with modelId: {modelId}");
                return scenariosByModelId;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | GetAllScenariosByModelId", $"Get All scenarios failed with modelId: {modelId} and message: {ex.Message}");
                throw;
            }
        }
        public List<ScenarioDetails> GetScenariosByModelId(string modelId,string solutionId)
        {
            List<ScenarioDetails> scenarios = new List<ScenarioDetails>();

            try
            {
                DataTable scenariosDataTable = _mySqlDataClient.GetAllScenarioDetailsById(modelId, solutionId);
                foreach (DataRow dataRow in scenariosDataTable.Rows)
                {
                    scenarios.Add(ParseDataRowToScenario(dataRow));
                }
                return scenarios;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public ScenarioDetails GetScenarioByScenarioId(string modelId, Guid scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | GetScenarioByScenarioId", $"Get Scenario started with scenarioId: {scenarioId}");
                DataTable dataTable = _mySqlDataClient.GetScenarioDetailsByScenarioId(scenarioId);
                ScenarioDetails scenario = new ScenarioDetails();
                if (isUnitTest)
                {
                    return new ScenarioDetails();
                }

                if (dataTable.Rows.Count > 0)
                {
                    scenario = ParseDataRowToScenario(dataTable.Rows[0]);
                }

                if (scenario.Instances != null)
                {
                    scenario.Instances.ForEach(instance =>
                    {
                        ScenarioStatus status = _scenarioStatusService.GetStatusForUI(instance.ScenarioStatus);
                        instance.ScenarioStatus = status.Id.ToString();
                        instance.StatusCode = status.Code;
                        instance.StatusDescription = status.Description;
                    });
                }

                _logHelper.LogMessage("INFO", "ScenariosService | GetScenarioByScenarioId", $"Get Scenario Complete with scenarioId: {scenarioId}");
                return scenario;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | GetScenarioByScenarioId", $"Get scenario failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }

        public bool CheckDuplicateNames(string modelId, string scenarioName, Guid scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | CheckDuplicateNamesForInsert", $"Checking duplicate names for insert started with scenarioId: {scenarioId}");
                List<ScenarioNames> allScenarios = _mySqlDataClient.GetAllScenariosByModelId(modelId);
                bool res = allScenarios.FindAll(scenario => scenario.ScenarioName == scenarioName).Count > 0;
                _logHelper.LogMessage("INFO", "ScenariosService | CheckDuplicateNamesForInsert", $"Checking duplicate names for insert success with scenarioId: {scenarioId}");
                return res;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | CheckDuplicateNamesForInsert", 
                    $"Checking duplicate names for insert failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }

        public Guid InsertScenario(string modelId, ScenarioDetails scenario)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | InsertScenario", "Insert Scenario started");
                if (scenario == null)
                {
                    string errorMessage = $"{Arguments.SCENARIO} is null for insertion";
                    _logHelper.LogMessage("ERROR", "ScenariosService | InsertScenario", errorMessage);
                    throw new ArgumentNullException(Arguments.SCENARIO, errorMessage);
                }
                scenario.ModelId = modelId;
                scenario.CreatedBy = scenario.CreatedBy ?? "";
                scenario.ModifiedBy = scenario.CreatedBy ?? "";
                scenario.CreatedDateTime = DateTime.UtcNow;
                scenario.ModifiedDateTime = DateTime.UtcNow;
                scenario.OptimizationTime = DateTime.UtcNow;
                scenario.FlowSheet = scenario.FlowSheet == null ? new FlowSheet() : scenario.FlowSheet;
                if (scenario.Instances != null && scenario.Instances.Count > 0)
                {
                    ScenarioStatus status = _scenarioStatusService.GetStatusById(scenario.Instances[0].ScenarioStatus);
                    if (status != null)
                    {
                        scenario.Instances[0].StatusCode = status.Code;
                        scenario.Instances[0].StatusDescription = status.Description;
                    }
                    scenario.Instances[0].InstanceId = Guid.NewGuid();
                    scenario.Instances = new List<ScenarioInstance> { scenario.Instances[0] };
                }
                else
                {
                    ScenarioStatus status = _scenarioStatusService.GetStatusById(ScenarioStatusCodes.NOT_RUN);
                    scenario.Instances = new List<ScenarioInstance>{
                            new ScenarioInstance{
                            InstanceId = Guid.NewGuid(),
                            ScenarioStatus = status.Code,
                            StatusCode = status.Code,
                            StatusDescription = status.Description
                            }
                        };
                }

                if (scenario.IsOPEnabled)
                {
                    scenario.UE_RunMode = "Optimization";
                }
                else
                {
                    scenario.UE_RunMode = "Calculation";
                }
                bool result = _mySqlDataClient.InsertScenario(scenario);

                if (result)
                {
                    _logHelper.LogMessage("INFO", "ScenariosService | InsertScenario", "GetStatusById started");
                    ScenarioStatus status = _scenarioStatusService.GetStatusById(ScenarioStatusCodes.NOT_RUN);

                    _logHelper.LogMessage("INFO", "ScenariosService | InsertScenario", "UpdateScenarioInstanceStatus started");
                    _mySqlDataClient.UpdateScenarioInstanceStatus(scenario.ScenarioId.ToString(), scenario.FlowSheet.Flowsheet_Name, status.Code);
                }
                _logHelper.LogMessage("INFO", "ScenariosService | InsertScenario", "Insert Scenario success");
                return scenario.ScenarioId;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | InsertScenario", $"Insert scenario failed with message: {ex.Message}");
                throw;
            }
        }
        public bool DeleteScenario(string modelId, Guid scenarioId, Guid instanceId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | DeleteScenario", $"Delete Scenario started with scenarioId: {scenarioId}");
                return _mySqlDataClient.DeleteScenario(modelId, scenarioId, instanceId);

            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | DeleteScenario", $"Delete Scenario failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }
        public Guid UpdateScenario(string modelId, Guid scenarioId, ScenarioDetails scenario)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenario", $"Update Scenario started with scenarioId: {scenarioId}");
                if (scenario == null)
                {
                    string errorMessage = $"{Arguments.SCENARIO} is null for updation";
                    _logHelper.LogMessage("ERROR", "ScenariosService | UpdateScenario", errorMessage);
                    throw new ArgumentNullException(Arguments.SCENARIO, errorMessage);
                }
                if (scenario.IsOPEnabled)
                {
                    scenario.UE_RunMode = "Optimization";
                }
                else
                {
                    scenario.UE_RunMode = "Calculation";
                }
                scenario.ModifiedBy = scenario.ModifiedBy ?? "";
                scenario.ModifiedDateTime = DateTime.UtcNow;
                _mySqlDataClient.UpdateScenario(scenario);
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenario", $"Update Scenario success with scenarioId: {scenarioId}");
                return scenarioId;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | UpdateScenario", $"Update scenario failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }
        public (bool, Guid) UpdateScenarioNameDesc(string modelId, Guid scenarioId, ScenarioDetails scenario)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenarioNameDesc", $"UpdateScenarioNameDesc started with scenarioId: {scenarioId}");
                if (scenario == null)
                {
                    string errorMessage = $"{Arguments.SCENARIO} is null for updation";
                    _logHelper.LogMessage("ERROR", "ScenariosService | UpdateScenarioNameDesc", errorMessage);
                    throw new ArgumentNullException(Arguments.SCENARIO, errorMessage);
                }

                ScenarioDetails scenarioDetails = GetScenarioByScenarioId(modelId,scenarioId);
                if (scenarioDetails.CreatedBy != scenario.CreatedBy)
                { return (false, Guid.Empty); }

                if (scenario.IsOPEnabled)
                {
                    scenario.UE_RunMode = "Optimization";
                }
                else
                {
                    scenario.UE_RunMode = "Calculation";
                }
                scenario.ModifiedBy = scenario.ModifiedBy ?? "";
                scenario.ModifiedDateTime = DateTime.UtcNow;
                _mySqlDataClient.UpdateScenarioNameDesc(scenario);
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenarioNameDesc", $"UpdateScenarioNameDesc success with scenarioId: {scenarioId}");
                return (true, scenarioId); ;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | UpdateScenarioNameDesc", $"UpdateScenarioNameDesc failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }

        [ExcludeFromCodeCoverage]
        private ScenarioDetails ParseDataRowToScenario(DataRow dataRow)
        {
            try
            {
                List<ScenarioInstance> scenarioInstances = new List<ScenarioInstance>();
                if (!string.IsNullOrWhiteSpace(dataRow["instance_id"].ToString()))
                {
                    scenarioInstances.Add(new ScenarioInstance
                    {
                        InstanceId = Guid.Parse(dataRow["instance_id"].ToString()),
                        RunBy = dataRow["run_by"] == DBNull.Value ? null : dataRow["run_by"].ToString(),
                        StartDateTime = dataRow["start_datetime"] == DBNull.Value ? null : (DateTime?)dataRow["start_datetime"],
                        ScenarioStatus = dataRow["scenario_status"] == DBNull.Value ? null : dataRow["scenario_status"].ToString(),
                        CompletedDateTime = dataRow["completed_datetime"] == DBNull.Value ? null : (DateTime?)dataRow["completed_datetime"],
                        ErrorDetail = dataRow["error_detail"] == DBNull.Value ? null : dataRow["error_detail"].ToString() ?? "",
                        UnisimModelName = dataRow["flowsheet_name"] == DBNull.Value ? null : dataRow["flowsheet_name"].ToString()
                    });
                }
                ScenarioDetails scenario = new ScenarioDetails
                {
                    ScenarioId = Guid.Parse(dataRow["scenario_id"].ToString()),
                    ModelId = dataRow["model_id"].ToString(),
                    ScenarioName = dataRow["scenario_name"].ToString(),
                    ScenarioDescription = dataRow["scenario_description"].ToString(),
                    ParametersDetails = JsonConvert.DeserializeObject<List<ParameterDetails>>(dataRow["parameter_details"].ToString()),
                    IsValid = (Convert.ToInt16(dataRow["is_valid"]) == 1),
                    OptimizationTime = dataRow["optimization_time"] == DBNull.Value ? null : (DateTime?)dataRow["optimization_time"],
                    CreatedDateTime = dataRow["created_date_time"] == DBNull.Value ? null : (DateTime?)dataRow["created_date_time"],
                    CreatedBy = dataRow["created_by"] == DBNull.Value ? "" : dataRow["created_by"].ToString(),
                    ModifiedDateTime = dataRow["modified_date_time"] == DBNull.Value ? null : (DateTime?)dataRow["modified_date_time"],
                    ModifiedBy = dataRow["modified_by"] == DBNull.Value ? "" : dataRow["modified_by"].ToString(),
                    UE_RunMode = dataRow["ue_run_mode"] == DBNull.Value ? "" : dataRow["ue_run_mode"].ToString(),
                    IsOPEnabled = (Convert.ToInt16(dataRow["is_op_enabled"]) == 1),
                    IsPublished = (Convert.ToInt16(dataRow["is_published"].Equals(DBNull.Value) ? 0 : dataRow["is_published"]) == 1),
                    Instances = scenarioInstances,
                    FlowSheet = new FlowSheet
                    {
                        Flowsheet_Name = dataRow["flowsheet_name"] == DBNull.Value ? "" : dataRow["flowsheet_name"].ToString(),
                        FlowSheet_CreatedDateTime = dataRow["flowsheet_created_datetime"] == DBNull.Value ? null : (DateTime?)dataRow["flowsheet_created_datetime"]
                    }
                };
                return scenario;
            }
            catch (NullReferenceException ex)
            {
                throw;
            }
            catch (InvalidCastException ex)
            {
                throw;
            }
            catch (ArgumentException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public Guid UpdateScenarioStatus(Guid scenarioId, Guid instanceId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenarioStatus", $"Update Scenario started with scenarioId: {scenarioId}");
                _mySqlDataClient.UpdateScenarioStatus(scenarioId, instanceId, ScenarioStatusCodes.SCENARIO_RUN_PROCSNG);
                _logHelper.LogMessage("INFO", "ScenariosService | UpdateScenario", $"Update Scenario success with scenarioId: {scenarioId}");
                return scenarioId;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | UpdateScenario", $"Update scenario failed with scenarioId: {scenarioId} and message: {ex.Message}");
                throw;
            }
        }

        public int IsScenarioAllowedToRun(string tenantCode, string solutionId)
        {
            try
            {
                double noOfSuccessfulScenarios = 0;
                try
                {
                    int scenarioAllowedFrequency = _configuration["ScenarioRunsFrequency"] != "" ? Convert.ToInt32(_configuration["ScenarioRunsFrequency"]) : 2;
                    DataTable result = _mySqlDataClient.IsScenarioAllowedToRun(scenarioAllowedFrequency, tenantCode);
                    noOfSuccessfulScenarios = result.Rows.Count != 0 ? Convert.ToDouble(result.Rows[0]["NoOfSuccessfulScenarios"]) : 0;
                }
                catch (Exception)
                {
                    throw;
                }
                return (int)noOfSuccessfulScenarios;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | IsScenarioAllowedToRun", $" failed and message: {ex.Message}");
                throw;
            }
        }

        public bool DeleteScenarios(string tenantCode, string[] scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "ScenariosService | DeleteScenarios", $"Delete Scenario started");

                bool result  = _mySqlDataClient.DeleteScenarios(tenantCode, scenarioId);
                _logHelper.LogMessage("INFO", "ScenariosService | DeleteScenarios", $"Delete Scenario success");
                return result;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenariosService | DeleteScenarios", $"Delete scenario failed with message: {ex.Message}");
                throw;
            }
        }


    }
}
