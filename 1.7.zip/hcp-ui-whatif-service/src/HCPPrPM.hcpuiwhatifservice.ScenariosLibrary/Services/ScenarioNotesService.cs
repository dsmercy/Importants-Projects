﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenarioNotesService : IScenarioNotesService
    {

        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ILogHelper _logHelper;
        private readonly IScenariosService _scenariosService;

        public ScenarioNotesService(IMySqlDataClient mySqlDataClient, ILogHelper logHelper, IScenariosService scenariosService)
        {
            _mySqlDataClient = mySqlDataClient;
            _logHelper = logHelper;
            _scenariosService = scenariosService;
        }

        public List<ScenarioNote> GetAllNotes(string scenarioId)
        {
            List<ScenarioNote> scenarioNotes = new List<ScenarioNote>();
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioNotesService | GetAllNotes", $"GetAllNotes started");
                scenarioNotes = _mySqlDataClient.GetAllNotes(scenarioId);

                _logHelper.LogMessage("INFO", "ScenarioNotesService | GetAllNotes", $"GetAllNotes success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioNotesService | GetAllNotes", $"GetAllNotes failed with message: {ex.Message}");
                throw;
            }
            return scenarioNotes.OrderByDescending(o => o.CreatedDateTime).ToList();
        }

        public ScenarioNote GetLatestNote(string scenarioId)
        {
            ScenarioNote scenarioNotes = null;
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioNotesService | GetLatestNote", $"GetLatestNote started");
                scenarioNotes = _mySqlDataClient.GetLatestNote(scenarioId);

                _logHelper.LogMessage("INFO", "ScenarioNotesService | GetLatestNote", $"GetLatestNote success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioNotesService | GetLatestNote", $"GetLatestNote failed with message: {ex.Message}");
                throw;
            }
            return scenarioNotes;
        }

        public int InsertScenarioNote(ScenarioNoteModel note)
        {
            ScenarioNote scenarioNote = new ScenarioNote();
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioNotesService | InsertScenarioNote", $"InsertScenarioNote started");

                var scenario = _scenariosService.GetScenarioByScenarioId("", new Guid(note.ScenarioId));

                if (scenario.ScenarioName != null)
                {
                    if (scenario.CreatedBy != note.Username)
                        return Convert.ToInt32(NumberConstants.three);

                    note.CreatedDateTime = note.CreatedDateTime != null ? note.CreatedDateTime : DateTime.Now;

                    scenarioNote = JsonConvert.DeserializeObject<ScenarioNote>(JsonConvert.SerializeObject(note));

                    scenarioNote.NotesId = Guid.NewGuid().ToString();
                    scenarioNote.CreatedBy = note.Username;

                    bool result = _mySqlDataClient.InsertScenarioNote(scenarioNote);

                    _logHelper.LogMessage("INFO", "ScenarioNotesService | InsertScenarioNote", $"InsertScenarioNote success");
                    return Convert.ToInt32(NumberConstants.One);
                }
                else
                {
                    return Convert.ToInt32(NumberConstants.two);
                }
                
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioNotesService | InsertScenarioNote", $"InsertScenarioNote failed with message: {ex.Message}");
                throw;
            }
        }
    }
}
