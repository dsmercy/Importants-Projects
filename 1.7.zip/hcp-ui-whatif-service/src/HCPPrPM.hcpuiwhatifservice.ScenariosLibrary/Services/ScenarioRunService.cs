﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Honeywell.HCPPrPM.cpsuibackendlibrary.AccessTokenManager.Impl;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenarioRunService : IScenarioRunService
    {
        private static Func<HttpClient> clientFactory = () => new HttpClient();
        readonly static Logger logger = new Logger();
        private readonly string whatifCalcProcessorUrl;
        private readonly IMySqlDataClient _mySqlDataClient;

        public ScenarioRunService(IOptions<BaseUrls> baseUrls, IMySqlDataClient mySqlDataClient)
        {
            _mySqlDataClient = mySqlDataClient;
            if (baseUrls != null && baseUrls.Value != null)
            {
                whatifCalcProcessorUrl = baseUrls.Value.WhatifCalcProcessorApi;
            }
            else
            {
                string errorMessage = $"{Arguments.BASE_URLS} is null for WhatifCalcProcessor";
                logger.LogMessage("ERROR", "WhatifCalcProcessor | Constructor", errorMessage);
                throw new ArgumentNullException(Arguments.BASE_URLS, errorMessage);
            }
        }
        public ScenarioRunService(IOptions<BaseUrls> baseUrls, HttpClient _client, IMySqlDataClient mySqlDataClient)
        {
            _mySqlDataClient = mySqlDataClient;
            if (baseUrls != null && baseUrls.Value != null)
            {
                whatifCalcProcessorUrl = baseUrls.Value.WhatifCalcProcessorApi;
                clientFactory = () => _client;
            }
            else
            {
                string errorMessage = $"{Arguments.BASE_URLS} is null for WhatifCalcProcessor";
                logger.LogMessage("ERROR", "WhatifCalcProcessor | Constructor", errorMessage);
                throw new ArgumentNullException(Arguments.BASE_URLS, errorMessage);
            }
        }
        public string ScenarioRunRequestToCalcProcessor(string modelId, string scenarioId, string accessToken)
        {
            try
            {
                string instanceId="";
                DataTable  instanceDT = _mySqlDataClient.GetInstanceDetailsByScenarioId(scenarioId);
                if (instanceDT.Rows.Count > 0) {
                    instanceId = instanceDT.Rows[0][0].ToString();
                }                
                // fetch instance Id 
                var fullUrl = whatifCalcProcessorUrl + modelId + $"/" + scenarioId + $"/" + instanceId;
                UriBuilder builder = new UriBuilder(fullUrl);
                logger.LogMessage("INFO", "UnisimJobApiClient | CallUnisimFlowsheet", "Trigger UnisimJob Started");
                using (var client = clientFactory())
                {
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                    var response = client.PostAsync(builder.Uri, null).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadAsStringAsync().Result;
                        logger.LogMessage("INFO", "UnisimJobApiClient | CallUnisimFlowsheet", $"Trigger UnisimJob Success");
                        return result;
                    }
                    else
                    {
                        string errorMessage = $"Trigger UnisimJob Failed and StatusCode is {response.StatusCode} and Reason is {response.ReasonPhrase} and Url {builder.Uri}";
                        logger.LogMessage("ERROR", "WhatifCalcProcessor | Trigger Job", errorMessage);
                        return errorMessage;
                    }
                }
            }
            catch (Exception ex)
            {
                string errorMessage = $"Trigger UnisimJob Failed, Error message is {ex.Message}";
                logger.LogMessage("ERROR", "WhatifCalcProcessor | Trigger Job", errorMessage);
                throw ex ;
            }
        }
    }
}
