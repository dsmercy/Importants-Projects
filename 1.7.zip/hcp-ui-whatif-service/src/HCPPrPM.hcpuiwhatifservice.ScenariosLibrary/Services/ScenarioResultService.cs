﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Honeywell.HCPPrPM.cpsuibackendlibrary.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenarioResultService : IScenarioResultService
    {
        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ICustomLogger _logHelper;

        public ScenarioResultService(IMySqlDataClient mySqlDataClient, ICustomLogger logHelper)
        {
            _mySqlDataClient = mySqlDataClient;
            _logHelper = logHelper;
        }
        public async Task<ScenarioResult> GetScenarioResultByInstanceId(string modelId, Guid scenarioId, Guid instanceId)
        {
            try
            {
                ScenarioResult scenarioResult = new ScenarioResult();
                _logHelper.LogMessage("INFO", "ScenarioResultService | GetScenarioResultByInstanceId", $"Get scenario results by id started with scenario id {scenarioId}, instanceId: {instanceId}");
                DataTable scenariosDataTable = _mySqlDataClient.GetScenarioResultByInstanceId(modelId, scenarioId, instanceId);

                if (scenariosDataTable.Rows.Count > 0)
                {
                    _logHelper.LogMessage("INFO", "ScenarioResultService | GetScenarioResultByInstanceId", $"Parsing Data table");
                    scenarioResult = ParseDataRowToScenarioResult(scenariosDataTable);
                    scenarioResult.ModelId = modelId;
                    scenarioResult.InstanceId = instanceId;
                    scenarioResult.ScenarioId = scenarioId;
                    return scenarioResult;
                }
                else
                {
                    return new ScenarioResult();
                }

            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioResultService | GetScenarioResultByInstanceId", $"Get scenario results by id complete with" +
                                           $"scenario id {scenarioId}, instanceId: {instanceId} and error message: {ex.Message}");
                throw ex;
            }
        }

        public bool InsertScenarioResult(string modelId, Guid scenarioId, Guid instanceId, List<ScenarioResultModel> scenarioResultModel)
        {
            try
            {
                bool result = false;
                ScenarioResult scenarioResult = new ScenarioResult();
                _logHelper.LogMessage("INFO", "ScenarioResultService | InsertScenarioResult", $"Insert scenario result started");

                DataTable scenariosDataTable = _mySqlDataClient.GetScenarioResultByInstanceId(modelId, scenarioId, instanceId);

                if (scenariosDataTable.Rows.Count > 0)
                {
                    bool deleted = _mySqlDataClient.DeleteScenarioResult(modelId, scenarioId, instanceId);
                    foreach (var item in scenarioResultModel)
                    {
                        result = _mySqlDataClient.InsertScenarioResult(modelId, scenarioId, instanceId, item);
                        if (result)
                        {
                            bool isUpdatedScenarioInstance = _mySqlDataClient.UpdateScenarioStatus(scenarioId, instanceId, ScenarioStatusCodes.SUCCS);
                        }
                    }
                }
                else
                {
                    foreach (var item in scenarioResultModel)
                    {
                        result = _mySqlDataClient.InsertScenarioResult(modelId, scenarioId, instanceId, item);
                        if (result)
                        {
                            bool isUpdatedScenarioInstance = _mySqlDataClient.UpdateScenarioStatus(scenarioId, instanceId, ScenarioStatusCodes.SUCCS);
                        }
                    }
                }
                if (result)
                {
                    _logHelper.LogMessage("INFO", "ScenarioResultService | InsertScenarioResult", $"Insert scenario result completed");
                    return result;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioResultService | InsertScenarioResult", $"Insert scenario results by id complete with" +
                                           $"scenario id {scenarioId}, instanceId: {instanceId} and error message: {ex.Message}");
                throw ex;
            }
        }

        public bool UpdateScenarioResultStatus(string modelId, Guid scenarioId, Guid instanceId, ScenarioResultStatus scenarioStatus)
        {
            try
            {
                _logHelper.LogMessage("DEBUG", "ScenarioResultService | UpdateScenarioResultStatus", $"UpdateScenarioResultStatus started");

                var field = typeof(ScenarioStatusCodes).GetField(scenarioStatus.Status);

                if (field != null && field.Name == scenarioStatus.Status)
                {
                    bool result = _mySqlDataClient.UpdateScenarioStatus(scenarioId, instanceId, scenarioStatus.Status, scenarioStatus.Message);
                    _logHelper.LogMessage("DEBUG", "ScenarioResultService | UpdateScenarioResultStatus", $"UpdateScenarioResultStatus completed");
                    return result;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioResultService | UpdateScenarioResultStatus", $"UpdateScenarioResultStatus by id failed with" +
                                           $"scenario id {scenarioId}, instanceId: {instanceId} and error message: {ex.Message}");
                throw ex;
            }
        }
        private ScenarioResult ParseDataRowToScenarioResult(DataTable resultDataTable)
        {
            try
            {
                ScenarioResult scenarioResult = new ScenarioResult();
                _logHelper.LogMessage("INFO", "ScenarioResultService | GetScenarioResultByInstanceId", $"Parsing Data table per row");
                ///UOM Conversion to be done at a later point of time when customers have a model
                foreach (DataRow dataRow in resultDataTable.Rows)
                {
                    //Populate Input Tag Information
                    _logHelper.LogMessage("INFO", "ScenarioResultService | GetScenarioResultByInstanceId", $"Populating Input tag information");
                    long timestamp = GetUnixTimeStamp(DateTime.Parse(dataRow["insert_time_stamp"].ToString()));
                    if (dataRow["tag_type"].ToString().ToLower() == Constants.InputTag.ToLower())
                    {
                        scenarioResult.InputTagDetails.Add(new InputTagDataItem()
                        {
                            TagName = dataRow["tag_name"].ToString(),
                            UnisimMapTagName = dataRow["unisim_map_tag_name"].ToString().ToLower(),
                            BaseValueUopUom = (double)dataRow["base_value_uop_uom"],
                            ValueUopUom = (double)dataRow["val_in_uop_uom"],
                            TimeStamp = timestamp,
                            TagType = dataRow["tag_type"].ToString().ToLower(),
                        });
                    }
                    _logHelper.LogMessage("INFO", "ScenarioResultService | GetScenarioResultByInstanceId", $"Populating Output tag information");
                    //Populate Output tag information
                    if (dataRow["tag_type"].ToString().ToLower() == Constants.OutputTag.ToLower())
                    {

                        if (dataRow["ue_run_mode"].ToString().ToLower() == Constants.Calculation_RunMode.ToLower())
                        {
                            scenarioResult.OutputTagDetails.Add(new OutputTagDataItem()
                            {
                                TagName = dataRow["tag_name"].ToString(),
                                UnisimMapTagName = dataRow["unisim_map_tag_name"].ToString().ToLower(),
                                ValueUopUom = (double)dataRow["val_in_uop_uom"],
                                TimeStamp = timestamp,
                                TagType = dataRow["tag_type"].ToString().ToLower(),
                            });
                        }
                        if (dataRow["ue_run_mode"].ToString().ToLower() == Constants.Optimization_RunMode.ToLower())
                        {
                            scenarioResult.Op_OutputTagDetails.Add(new OP_OutputTagDataItem()
                            {
                                TagName = dataRow["tag_name"].ToString(),
                                UnisimMapTagName = dataRow["unisim_map_tag_name"].ToString().ToLower(),
                                ValueUopUom = (double)dataRow["val_in_uop_uom"],
                                TimeStamp = timestamp,
                                TagType = dataRow["tag_type"].ToString().ToLower(),
                            });
                        }
                    }

                }
                return scenarioResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private long GetUnixTimeStamp(DateTime dateTime)
        {
            long epochTicks = new DateTime(1970, 1, 1).Ticks;
            long unixTime = ((dateTime.Ticks - epochTicks) / TimeSpan.TicksPerSecond) * 1000;
            return unixTime;
        }

    }
}
