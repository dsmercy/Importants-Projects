﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenarioCommentsService : IScenarioCommentsService
    {

        private readonly IMySqlDataClient _mySqlDataClient;
        private readonly ILogHelper _logHelper;
        private readonly IScenariosService _scenariosService;

        public ScenarioCommentsService(IMySqlDataClient mySqlDataClient, ILogHelper logHelper, IScenariosService scenariosService)
        {
            _mySqlDataClient = mySqlDataClient;
            _logHelper = logHelper;
            _scenariosService = scenariosService;
        }

        public List<ScenarioComment> GetAllComments(string scenarioId)
        {
            List<ScenarioComment> scenarioComments = new List<ScenarioComment>();
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioCommentsService | GetAllComments", $"GetAllComments started");
                scenarioComments = _mySqlDataClient.GetAllComments(scenarioId);

                _logHelper.LogMessage("INFO", "ScenarioCommentsService | GetAllComments", $"GetAllComments success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioCommentsService | GetAllComments", $"GetAllComments failed with message: {ex.Message}");
                throw;
            }
            return scenarioComments.OrderByDescending(o => o.CreatedDateTime).ToList();
        }

        public ScenarioComment GetComment(string scenarioId, string commentId)
        {
            ScenarioComment scenarioComments = null;
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioCommentsService | GetCommentById", $"GetCommentById started");
                scenarioComments = _mySqlDataClient.GetComment(scenarioId, commentId);

                _logHelper.LogMessage("INFO", "ScenarioCommentsService | GetCommentById", $"GetCommentById success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioCommentsService | GetCommentById", $"GetCommentById failed with message: {ex.Message}");
                throw;
            }
            return scenarioComments;
        }

        public bool InsertScenarioComment(ScenarioCommentModel comment)
        {
            bool result = false;
            ScenarioComment scenarioComment = new ScenarioComment();
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment started");

                var scenario = _scenariosService.GetScenarioByScenarioId("", new Guid(comment.ScenarioId));

                if (scenario.ScenarioName != null)
                {
                    comment.CreatedDateTime = comment.CreatedDateTime != null ? comment.CreatedDateTime : DateTime.Now;

                    scenarioComment = JsonConvert.DeserializeObject<ScenarioComment>(JsonConvert.SerializeObject(comment));


                    scenarioComment.CommentId = Guid.NewGuid().ToString();
                    scenarioComment.CreatedBy = comment.Username;

                    result = _mySqlDataClient.InsertScenarioComment(scenarioComment);
                }

                _logHelper.LogMessage("INFO", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment failed with message: {ex.Message}");
                throw;
            }
            return result;
        }

        public bool UpdateScenarioComment(string scenarioId, string commentId, ScenarioCommentModel comment)
        {
            bool result = false;
            ScenarioComment scenarioComment = new ScenarioComment();
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment started");

                var comments = _mySqlDataClient.GetComment(scenarioId, commentId);

                if (comments != null)
                {
                    scenarioComment = JsonConvert.DeserializeObject<ScenarioComment>(JsonConvert.SerializeObject(comment));

                    scenarioComment.UpdatedDateTime = comment.CreatedDateTime != null ? (Convert.ToString(comment.CreatedDateTime)) : DateTime.Now.ToString();
                    scenarioComment.UpdatedBy = comment.Username;
                    scenarioComment.ScenarioId = scenarioId;
                    scenarioComment.CommentId = commentId;

                    result = _mySqlDataClient.UpdateScenarioComment(scenarioComment);
                }

                _logHelper.LogMessage("INFO", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment success");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioCommentsService | InsertScenarioComment", $"InsertScenarioComment failed with message: {ex.Message}");
                throw;
            }
            return result;
        }
        public bool DeletScenarioComment(string scenarioId, string commentId)
        {
            bool result = false;
            try
            {
                _logHelper.LogMessage("INFO", "ScenarioCommentsService | DeletScenarioComment", $"DeletScenarioComment started");

                var comments = _mySqlDataClient.GetComment(scenarioId, commentId);

                if (comments != null)
                {
                    result = _mySqlDataClient.DeletScenarioComment(scenarioId, commentId);

                    _logHelper.LogMessage("INFO", "ScenarioCommentsService | DeletScenarioComment", $"DeletScenarioComment success");
                }
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "ScenarioCommentsService | DeletScenarioComment", $"DeletScenarioComment failed with message: {ex.Message}");
                throw;
            }
            return result;
        }
    }
}
