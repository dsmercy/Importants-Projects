﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    [ExcludeFromCodeCoverage]
    public class ScenarioStatusService: IScenarioStatusService
    {
        private List<ScenarioStatus> AllStatus { get; set; }

        private List<ScenarioStatus> AllInternalSuccessStatus { get; set; }

        private List<ScenarioStatus> AllInternalErrorStatus { get; set; }

        public ScenarioStatusService()
        {
            this.AllStatus = new List<ScenarioStatus>
            {
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_IN_PROGRESS, Code = "UNISIM_JOB_EXEC_IN_PROGRESS", Description = "UniSim Job execution in progress" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.NOT_RUN, Code = "NOT_RUN", Description = "Input Saved" },
                //new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_SUCCS, Code = "UNISIM_JOB_EXEC_SUCCS", Description = "UniSim job execution success" },
                 new ScenarioStatus { Id = (int)ScenarioStatusTypes.SUCCS, Code = "SUCCS", Description = "Success" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SCENARIO_RUN_PROCSNG, Code = "SCENARIO_RUN_PROCSNG", Description = "Running" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_IN_QUE, Code = "UNISIM_JOB_EXEC_IN_QUE", Description = "UNISIM_JOB_EXEC_IN_QUE" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SCENARIO_RUN_SUCCS, Code = "SCENARIO_RUN_SUCCS", Description = "SCENARIO_RUN_SUCCS" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SCENARIO_RUN_ERR, Code = "SCENARIO_RUN_ERR", Description = "Failed" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_ERR, Code = "UNISIM_JOB_EXEC_ERR", Description = "Error in UniSim Job Execution" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_OP_EXEC_ERR, Code = "UNISIM_JOB_OP_EXEC_ERR", Description = "Error in UniSim Job Execution for EO Run" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_OP_EXEC_SUCCS, Code = "UNISIM_JOB_OP_EXEC_SUCCS", Description = "UniSim job execution success " },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_OP_EXEC_TIMEOUT, Code = "UNISIM_JOB_OP_EXEC_TIMEOUT", Description = "UniSim job execution for OP timedout " },
        };

            this.AllInternalSuccessStatus = new List<ScenarioStatus>
            {
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.RETRIEVE_FILES_FROM_CLOUD, Code = "RETRIEVE_FILES_FROM_CLOUD", Description = "Flowsheet Retrieved from Cloud" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_PREFERENCE_FILE_LOAD_SUCCESS, Code = "UNISIM_PREFERENCE_FILE_LOAD_SUCCESS", Description = "UniSim Preference file load success" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.CASELOAD_SUCCESS, Code = "CASELOAD_SUCCESS", Description = "Case Load Success" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.CASELOAD_SUCCESS, Code = "CASELOAD_SUCCESS", Description = "Case Load Success" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.INPUT_DATA_TRANSFER_TO_PDT_COMPLETED, Code = "INPUT_DATA_TRANSFER_TO_PDT_COMPLETED", Description = "Input Data Transfer to PDT completed" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.CASE_LOAD_TIMEOUT, Code = "CASE_LOAD_TIMEOUT", Description = "Case Load Timeout" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SAVED_JOB_TO_DB, Code = "SAVED_JOB_TO_DB", Description = "Job Data Saved to Scenario store" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_CLOSED, Code = "UNISIM_CLOSED", Description = "UniSim CLosed" },

                new ScenarioStatus { Id = (int)ScenarioStatusTypes.GET_SCENARIODETAILS_SCCS, Code = "GET_SCENARIODETAILS_SCCS", Description = "GET_SCENARIODETAILS_SCCS" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.GET_SCENARIOINSTANCE_SCCS, Code = "GET_SCENARIOINSTANCE_SCCS", Description = "GET_SCENARIOINSTANCE_SCCS" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_CONFIG_SCCS, Code = "UNISIM_CONFIG_SCCS", Description = "UNISIM_CONFIG_SCCS" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_PAYLD_SCCS, Code = "UNISIM_JOB_PAYLD_SCCS", Description = "UNISIM_JOB_PAYLD_SCCS" }
        };

            this.AllInternalErrorStatus = new List<ScenarioStatus>
            {
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_TIMEOUT, Code = "UNISIM_JOB_EXEC_TIMEOUT", Description = "UniSim Job execution timeout" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_EXEC_ERR, Code = "UNISIM_JOB_EXEC_ERR", Description = "Error in UniSim Job Execution" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SOLVER_ERROR, Code = "SOLVER_ERROR", Description = "Solver Error" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SOLVER_TIMEOUT_FAIL, Code = "SOLVER_TIMEOUT_FAIL", Description = "Solver Timeout" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.POPULATE_OUTPUT_ERROR, Code = "POPULATE_OUTPUT_ERROR", Description = "Populate Output Error" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.SAVE_JOB_TO_DB_ERROR, Code = "SAVE_JOB_TO_DB_ERROR", Description = "Error while saving Job to Scenario store" },

                new ScenarioStatus { Id = (int)ScenarioStatusTypes.GET_SCENARIODETAILS_ERR, Code = "GET_SCENARIODETAILS_ERR", Description = "GET_SCENARIODETAILS_ERR" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.GET_SCENARIOINSTANCE_ERR, Code = "GET_SCENARIOINSTANCE_ERR", Description = "GET_SCENARIOINSTANCE_ERR" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_CONFIG_ERR, Code = "UNISIM_CONFIG_ERR", Description = "UNISIM_CONFIG_ERR" },
                new ScenarioStatus { Id = (int)ScenarioStatusTypes.UNISIM_JOB_PAYLD_ERR, Code = "UNISIM_JOB_PAYLD_ERR", Description = "UNISIM_JOB_PAYLD_ERR" }

        };
        }

        public ScenarioStatus GetStatusById(string  statusCode)
        {
            ScenarioStatus status = this.AllStatus.Concat(this.AllInternalSuccessStatus).Concat(this.AllInternalErrorStatus).ToList<ScenarioStatus>().Find(s => s.Code == statusCode);
            if (status == null)
            {
                status = this.AllStatus[0];
            }
            return status;
        }

        public ScenarioStatus GetStatusForUI(string statusCode)
        {
            bool isInternalSuccess = this.AllInternalSuccessStatus.Exists(st => st.Code == statusCode);
            if (isInternalSuccess)
            {
                return this.AllStatus.Find(st => st.Code == ScenarioStatusCodes.UNISIM_JOB_EXEC_IN_PROGRESS);
            }
            bool isInternalError = this.AllInternalErrorStatus.Exists(st => st.Code == statusCode);
            if (isInternalError)
            {
                return this.AllStatus.Find(st => st.Code == ScenarioStatusCodes.UNISIM_JOB_EXEC_ERR);
            }
            return this.AllStatus.Find(st => st.Code == statusCode);
        }
    }
}
