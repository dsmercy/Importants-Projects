﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioResultService
    {
        Task<ScenarioResult> GetScenarioResultByInstanceId(string modelId, Guid scenarioId, Guid instanceId);
        public bool InsertScenarioResult(string modelId, Guid scenarioId, Guid instanceId, List<ScenarioResultModel> scenario);
        public bool UpdateScenarioResultStatus(string modelId, Guid scenarioId, Guid instanceId, ScenarioResultStatus scenarioStatus);
    }
}
