﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioNotesService
    {
        List<ScenarioNote> GetAllNotes(string scenarioId);
        ScenarioNote GetLatestNote(string scenarioId);
        int InsertScenarioNote(ScenarioNoteModel note);
    }
}
