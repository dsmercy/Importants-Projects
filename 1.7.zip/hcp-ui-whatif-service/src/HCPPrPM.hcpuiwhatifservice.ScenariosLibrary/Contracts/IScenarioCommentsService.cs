﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioCommentsService
    {
        List<ScenarioComment> GetAllComments(string scenarioId);
        ScenarioComment GetComment(string scenarioId, string commentId);
        bool InsertScenarioComment(ScenarioCommentModel comment);
        bool UpdateScenarioComment(string scenarioId, string commentId, ScenarioCommentModel comment);
        bool DeletScenarioComment(string scenarioId, string commentId);
    }
}
