﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenariosService
    {
        Guid InsertScenario(string modelId, ScenarioDetails scenario);
        bool CheckDuplicateNames(string modelId, string scenarioName, Guid scenarioId);
        bool DeleteScenario(string modelId, Guid scenarioId, Guid instanceId);
        List<ScenarioDetails> GetAllScenariosByModelId(string modelId,string solutionId);
        ScenarioDetails GetScenarioByScenarioId(string modelId, Guid scenarioId);
        Guid UpdateScenario(string modelId, Guid scenarioId, ScenarioDetails scenario);
        Guid UpdateScenarioStatus(Guid scenarioId, Guid instanceId);
        (bool,Guid) UpdateScenarioNameDesc(string modelId, Guid scenarioId, ScenarioDetails scenario);
        int IsScenarioAllowedToRun(string tenantCode, string solutionId);

        bool DeleteScenarios(string tenantCode, string[] scenarioId);
    }
}
