﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioStatusService
    {
        ScenarioStatus GetStatusById(string  code);
        ScenarioStatus GetStatusForUI(string code);
    }
}
