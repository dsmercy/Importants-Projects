﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioRunService
    {
        public string ScenarioRunRequestToCalcProcessor(string modelId, string scenarioId, string accessToken);
    }
}
