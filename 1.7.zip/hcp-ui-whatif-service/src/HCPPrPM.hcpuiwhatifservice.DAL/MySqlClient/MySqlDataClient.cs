﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants;
using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Xml.Linq;

namespace HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient
{
    [ExcludeFromCodeCoverage]
    public class MySqlDataClient : IMySqlDataClient
    {
        private readonly ILogHelper _logHelper;
        private readonly string connectionString;
        private string scenarioDetail;
        private string scenarioResult;
        private string scenarioRunInstance;
        private string scenarioComments;
        private string scenarioNotes;
        public MySqlDataClient(IConfiguration configuration, ILogHelper logHelper, IOptions<WhatIfTables> whatIfTables)
        {
            _logHelper = logHelper;
            if (whatIfTables != null && whatIfTables.Value != null)
            {
                scenarioDetail = whatIfTables.Value.ScenarioDetails;
                scenarioResult = whatIfTables.Value.ScenarioResult;
                scenarioRunInstance = whatIfTables.Value.ScenarioRunInstance;
                scenarioComments = whatIfTables.Value.ScenarioComments;
                scenarioNotes = whatIfTables.Value.ScenarioNotes;
            }
            if (configuration != null)
            {
                connectionString = configuration["MySqlConnectionString"];
                scenarioDetail = configuration["WhatIfTables:ScenarioDetails"];
                scenarioResult = configuration["WhatIfTables:ScenarioResult"];
                scenarioRunInstance = configuration["WhatIfTables:ScenarioRunInstance"];
                scenarioComments = configuration["WhatIfTables:ScenarioComments"];
                scenarioNotes = configuration["WhatIfTables:ScenarioNotes"];
            }

        }
        public bool InsertScenario(ScenarioDetails scenario)
        {
            bool result = false;

            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenario", "InsertScenario Started");
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("Insert into {0} (scenario_id,model_id,scenario_name,scenario_description,parameter_details,is_valid," +
                        "optimization_time,created_date_time,created_by,ue_run_mode,is_op_enabled,flowsheet_name,flowsheet_created_datetime,is_published,solution_id) " +
                        "values(@scenario_id,@model_id,@scenario_name,@scenario_description," + "@parameter_details,@is_valid,@optimization_time,@created_date_time," +
                        "@created_by,@ue_run_mode,@is_op_enabled,@flowsheet_name,@flowsheet_created_datetime,@is_published,@solution_id)", scenarioDetail);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenario_id", scenario.ScenarioId);
                    cmd.Parameters.AddWithValue("@model_id", scenario.ModelId);
                    cmd.Parameters.AddWithValue("@solution_id", scenario.SolutionId);
                    cmd.Parameters.AddWithValue("@scenario_name", scenario.ScenarioName);
                    cmd.Parameters.AddWithValue("@scenario_description", scenario.ScenarioDescription);
                    cmd.Parameters.AddWithValue("@parameter_details", scenario.ParametersDetails != null ? JsonConvert.SerializeObject(scenario.ParametersDetails) : "");
                    cmd.Parameters.AddWithValue("@is_valid", true);
                    cmd.Parameters.AddWithValue("@optimization_time", scenario.OptimizationTime);
                    cmd.Parameters.AddWithValue("@created_date_time", scenario.CreatedDateTime);
                    cmd.Parameters.AddWithValue("@created_by", scenario.CreatedBy);
                    cmd.Parameters.AddWithValue("@ue_run_mode", scenario.UE_RunMode);
                    cmd.Parameters.AddWithValue("@is_op_enabled", scenario.IsOPEnabled);
                    cmd.Parameters.AddWithValue("@is_published", scenario.IsPublished);
                    cmd.Parameters.AddWithValue("@flowsheet_name", scenario.FlowSheet.Flowsheet_Name);
                    cmd.Parameters.AddWithValue("@flowsheet_created_datetime", scenario.FlowSheet.FlowSheet_CreatedDateTime);
                    cmd.ExecuteNonQuery();
                    result = true;

                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenario", "InsertScenario Completed");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | InsertScenario", $"Insert scenario failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }
        public bool UpdateScenario(ScenarioDetails scenario)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenario", "UpdateScenario Started");
            bool result = false;
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("Update {0} Set model_id=@model_id,scenario_name=@scenario_name, scenario_description=@scenario_description," +
                        "parameter_details=@parameter_details,is_valid=@is_valid, optimization_time=@optimization_time,created_date_time=@created_date_time," +
                        "created_by=@created_by,modified_date_time=@modified_date_time,modified_by=@modified_by, ue_run_mode=@ue_run_mode,is_op_enabled=@is_op_enabled," +
                        "flowsheet_name=@flowsheet_name,flowsheet_created_datetime=@flowsheet_created_datetime,is_published=@is_published where scenario_id=@scenario_id", scenarioDetail);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenario_id", scenario.ScenarioId);
                    cmd.Parameters.AddWithValue("@model_id", scenario.ModelId);
                    cmd.Parameters.AddWithValue("@scenario_name", scenario.ScenarioName);
                    cmd.Parameters.AddWithValue("@scenario_description", scenario.ScenarioDescription);
                    cmd.Parameters.AddWithValue("@parameter_details", JsonConvert.SerializeObject(scenario.ParametersDetails));
                    cmd.Parameters.AddWithValue("@is_valid", true);
                    cmd.Parameters.AddWithValue("@optimization_time", scenario.OptimizationTime);
                    cmd.Parameters.AddWithValue("@created_date_time", scenario.CreatedDateTime);
                    cmd.Parameters.AddWithValue("@created_by", scenario.CreatedBy);
                    cmd.Parameters.AddWithValue("@modified_date_time", scenario.ModifiedDateTime);
                    cmd.Parameters.AddWithValue("@modified_by", scenario.ModifiedBy);
                    cmd.Parameters.AddWithValue("@ue_run_mode", scenario.UE_RunMode);
                    cmd.Parameters.AddWithValue("@is_op_enabled", scenario.IsOPEnabled);
                    cmd.Parameters.AddWithValue("@is_published", scenario.IsPublished);
                    cmd.Parameters.AddWithValue("@flowsheet_name", scenario.FlowSheet.Flowsheet_Name);
                    cmd.Parameters.AddWithValue("@flowsheet_created_datetime", scenario.FlowSheet.FlowSheet_CreatedDateTime);
                    cmd.ExecuteNonQuery();
                    result = true;
                    _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenario", "UpdateScenario Completed");
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenario", $"UpdateScenario scenario failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }
        public bool UpdateScenarioNameDesc(ScenarioDetails scenario)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioNameDesc", "UpdateScenarioNameDesc Started");
            bool result = false;
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("Update {0} Set scenario_name=@scenario_name," +
                        "scenario_description=@scenario_description," +
                        "modified_date_time=@modified_date_time,modified_by=@modified_by," +
                        "ue_run_mode=@ue_run_mode,is_op_enabled=@is_op_enabled" +
                        " where scenario_id=@scenario_id", scenarioDetail);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenario_id", scenario.ScenarioId);
                    cmd.Parameters.AddWithValue("@model_id", scenario.ModelId);
                    cmd.Parameters.AddWithValue("@scenario_name", scenario.ScenarioName);
                    cmd.Parameters.AddWithValue("@scenario_description", scenario.ScenarioDescription);
                    cmd.Parameters.AddWithValue("@modified_date_time", scenario.ModifiedDateTime);
                    cmd.Parameters.AddWithValue("@modified_by", scenario.ModifiedBy);
                    cmd.Parameters.AddWithValue("@ue_run_mode", scenario.UE_RunMode);
                    cmd.Parameters.AddWithValue("@is_op_enabled", scenario.IsOPEnabled);
                    cmd.ExecuteNonQuery();
                    result = true;
                    _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioNameDesc", "UpdateScenarioNameDesc Completed");
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenarioNameDesc", $"UpdateScenarioNameDesc scenario failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }
        public List<ScenarioNames> GetAllScenariosByModelId(string modelId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllScenariosByModelId", "GetAllScenariosByModelId Started");
            List<ScenarioNames> scenarios = new List<ScenarioNames>();
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("Select scenario_id,scenario_name from {0} where model_id=@model_id",scenarioDetail);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@model_id", modelId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        scenarios.Add(new ScenarioNames
                        {
                            ScenarioId = Guid.Parse(dataReader["scenario_id"].ToString()),
                            ScenarioName = dataReader["scenario_name"].ToString()
                        });
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllScenariosByModelId", "GetAllScenariosByModelId Completed");
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetAllScenariosByModelId", $"GetAllScenariosByModelId failed with message: {ex.Message}");
                throw ex;
            }
            return scenarios;
        }
        public bool DeleteScenario(string modelId, Guid scenarioId, Guid instanceId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenario", "DeleteScenario Started");
            bool result = false;
            using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
            {
                try
                {
                    mySqlonnection.Open();
                    string mySqlCommand = "usp_delete_scenario";
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@instance_id", modelId);
                    cmd.Parameters.AddWithValue("@scenario_id", scenarioId);
                    cmd.Parameters.AddWithValue("@instance_id", instanceId);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }
                    _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenario", "DeleteScenario Completed");
                }
                catch (MySqlException ex)
                {
                    _logHelper.LogMessage("ERROR", "MySqlDataClient | DeleteScenario", $"DeleteScenario failed with message: {ex.Message}");
                    throw ex;
                }
                finally
                {
                    mySqlonnection.Close();
                }
            }
            return result;
        }
        public DataTable GetAllScenarioDetailsById(string modelId, string solutionId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllScenarioDetailsById", "GetAllScenarioDetailsById Started");
            try
            {
                DataTable scenarios = new DataTable();

                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    string mySqlCommand = "usp_get_scenarios_by_modelId";
                    mySqlonnection.Open();
                    using (MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@modelId", modelId);
                        cmd.Parameters.AddWithValue("@solutionId", solutionId);
                        MySqlDataReader dataReader = cmd.ExecuteReader();
                        scenarios.Load(dataReader);
                    }
                    _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllScenarioDetailsById", "GetAllScenarioDetailsById Completed");
                    return scenarios;
                }

            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetAllScenarioDetailsById", $"GetAllScenarioDetailsById failed with message: {ex.Message}");
                throw ex;
            }

        }
        public DataTable GetScenarioDetailsByScenarioId(Guid scenarioId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetScenarioDetailsByScenarioId", "GetScenarioDetailsByScenarioId Started");
            try
            {
                DataTable scenarios = new DataTable();
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    string mySqlCommand = "usp_get_scenario_by_scenarioId";
                    mySqlonnection.Open();
                    using (MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@scenarioId", scenarioId.ToString());
                        MySqlDataReader dataReader = cmd.ExecuteReader();
                        scenarios.Load(dataReader);
                    }
                    _logHelper.LogMessage("INFO", "MySqlDataClient | GetScenarioDetailsByScenarioId", "GetScenarioDetailsByScenarioId Completed");
                    return scenarios;
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetScenarioDetailsByScenarioId", $"GetScenarioDetailsByScenarioId failed with message: {ex.Message}");
                throw ex;
            }
        }

        public DataTable GetInstanceDetailsByScenarioId(string scenarioId)
        {
            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetInstanceDetailsByScenarioId", "GetInstanceDetailsByScenarioId Started");
                DataTable scenarios = new DataTable();
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    string mySqlCommand = "select instance_id from scenarioruninstance where scenario_id = @scenarioId";
                    mySqlonnection.Open();
                    using (MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@scenarioId", scenarioId.ToString());
                        MySqlDataReader dataReader = cmd.ExecuteReader();
                        scenarios.Load(dataReader);
                    }
                    _logHelper.LogMessage("INFO", "MySqlDataClient | GetInstanceDetailsByScenarioId", "GetInstanceDetailsByScenarioId Completed");
                    return scenarios;
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetInstanceDetailsByScenarioId", $"GetInstanceDetailsByScenarioId failed with message: {ex.Message}");
                throw ex;
            }
        }

        public DataTable GetScenarioResultByInstanceId(string modelId, Guid scenarioId, Guid instanceId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetScenarioResultByInstanceId", "GetScenarioResultByInstanceId Started");
            using (MySqlConnection mySqlConnection = new MySqlConnection(connectionString))
            {
                try
                {
                    DataTable scenarioResults = new DataTable();
                    mySqlConnection.Open();
                    string mySqlCommand = String.Format("Select * from {0} where model_id=@model_id and scenario_id=@scenario_id and instance_id = @instance_id", scenarioResult);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlConnection);
                    cmd.Parameters.AddWithValue("@model_id", modelId);
                    cmd.Parameters.AddWithValue("@scenario_id", scenarioId);
                    cmd.Parameters.AddWithValue("@instance_id", instanceId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    scenarioResults.Load(dataReader);
                    _logHelper.LogMessage("INFO", "MySqlDataClient | GetScenarioResultByInstanceId", "GetScenarioResultByInstanceId Completed");
                    return scenarioResults;
                }
                catch (Exception ex)
                {
                    _logHelper.LogMessage("ERROR", "MySqlDataClient | GetScenarioResultByInstanceId", $"GetScenarioResultByInstanceId failed with message: {ex.Message}");
                    throw ex;
                }
                finally
                {
                    mySqlConnection.Close();
                }
            }
        }

        public bool InsertScenarioResult(string modelId, Guid scenarioId, Guid instanceId, ScenarioResultModel scenario)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioResult", "InsertScenarioResult Started");
            bool result = false;
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("Insert into {0} (instance_id,scenario_id,model_id,tag_name,val_in_uop_uom,base_value_uop_uom," +
                        "load_time_stamp,insert_time_stamp,uom,tag_type,run_mode,ue_run_mode) " + "values(@instance_id,@scenario_id,@model_id,@tag_name," +
                        "@val_in_uop_uom,@base_value_uop_uom,@load_time_stamp,@insert_time_stamp,@uom,@tag_type,@run_mode,@ue_run_mode)", scenarioResult);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenario_id", scenarioId);
                    cmd.Parameters.AddWithValue("@instance_id", instanceId);
                    cmd.Parameters.AddWithValue("@model_id", modelId);
                    cmd.Parameters.AddWithValue("@tag_name", scenario.TagName);
                    cmd.Parameters.AddWithValue("@val_in_uop_uom", scenario.Value);
                    cmd.Parameters.AddWithValue("@base_value_uop_uom", scenario.BaseValue);
                    cmd.Parameters.AddWithValue("@load_time_stamp", scenario.TimeStamp);
                    cmd.Parameters.AddWithValue("@insert_time_stamp", DateTime.Now);
                    cmd.Parameters.AddWithValue("@uom", scenario.Uom);
                    cmd.Parameters.AddWithValue("@tag_type", Constants.OutputTag.ToLower());
                    cmd.Parameters.AddWithValue("@run_mode", Constants.Calculation_RunMode.ToLower());
                    cmd.Parameters.AddWithValue("@ue_run_mode", Constants.Calculation_RunMode.ToLower());
                    cmd.ExecuteNonQuery();
                    _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioResult", "InsertScenarioResult Completed");
                    result = true;
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | InsertScenarioResult", $"InsertScenarioResult failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }

        public bool DeleteScenarioResult(string modelId, Guid scenarioId, Guid instanceId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenarioResult", $"DeleteScenarioResult Started");
            bool result = false;
            using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
            {
                try
                {
                    mySqlonnection.Open();
                    string mySqlCommand = "usp_delete_scenario_result";
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@scenarioId", scenarioId);
                    cmd.Parameters.AddWithValue("@instanceId", instanceId);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }
                }
                catch (MySqlException ex)
                {
                    _logHelper.LogMessage("ERROR", "MySqlDataClient | DeleteScenarioResult", $"DeleteScenarioResult failed with message: {ex.Message}");
                    throw ex;
                }
                finally
                {
                    mySqlonnection.Close();
                }
            }
            _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenarioResult", $"DeleteScenarioResult Completed");
            return result;
        }
        public void UpdateScenarioInstanceStatus(string scenarioId, string flowsheetName, string scenarioStatus)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioInstanceStatus", $"UpdateScenarioInstanceStatus Started");
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (MySqlTransaction tran = connection.BeginTransaction(IsolationLevel.Serializable))
                    {

                        using (MySqlCommand cmd = new MySqlCommand())
                        {
                            cmd.Connection = connection;
                            cmd.Transaction = tran;
                            cmd.CommandText = String.Format("Insert into {0} (instance_id,scenario_id,scenario_status,flowsheet_name)" +
                                "Values(@instance_id, @scenario_id, @scenario_status, @flowsheet_name)", scenarioRunInstance);
                            cmd.CommandType = CommandType.Text;
                            cmd.Parameters.Add("@scenario_status", MySqlDbType.VarChar).Value = scenarioStatus;
                            cmd.Parameters.Add("@scenario_id", MySqlDbType.VarChar).Value = scenarioId;
                            cmd.Parameters.Add("@instance_id", MySqlDbType.VarChar).Value = Guid.NewGuid().ToString();
                            cmd.Parameters.Add("@flowsheet_name", MySqlDbType.VarChar).Value = flowsheetName;
                            try
                            {
                                cmd.ExecuteNonQuery();
                                tran.Commit();
                                _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioInstanceStatus", $"UpdateScenarioInstanceStatus Completed");
                            }
                            catch (Exception ex)
                            {
                                _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenarioInstanceStatus", $"UpdateScenarioInstanceStatus failed with message: {ex.Message}");
                                tran.Rollback();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenarioInstanceStatus", $"UpdateScenarioInstanceStatus failed with message: {ex.Message}");
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }

        }

        public bool UpdateScenarioStatus(Guid scenarioId, Guid instanceId, string scenarioStatus,string message = "")
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioStatus", "UpdateScenarioStatus Started");
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    bool result = false;
                    using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                    {
                        mySqlonnection.Open();
                        string mySqlCommand = String.Format("UPDATE {0} SET scenario_status = @scenario_status,start_datetime=@start_datetime," +
                            "error_detail=@error_detail WHERE instance_id = @instance_id", scenarioRunInstance);
                        MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@scenario_status", scenarioStatus);
                        cmd.Parameters.AddWithValue("@instance_id", instanceId);
                        cmd.Parameters.AddWithValue("@start_datetime", DateTime.Now);
                        cmd.Parameters.AddWithValue("@error_detail", message);
                        int data = cmd.ExecuteNonQuery();
                        result = true;
                    }
                    _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioStatus", "UpdateScenarioStatus Completed");
                    return result;
                }
                catch (Exception ex)
                {
                    _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenarioStatus", $"UpdateScenarioStatus failed with message: {ex.Message}");
                    throw;
                }
            }
        }
        public DataTable IsScenarioAllowedToRun(int freq, string tenantCode)
        {
            try
            {
                DataTable scenarios = new DataTable();

                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    string mySqlCommand = "Get_NoOfSuccessfulScenarios";
                    mySqlonnection.Open();
                    using (MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@p_ScenarioRunsFrequency", freq);
                        cmd.Parameters.AddWithValue("@model_id", tenantCode);
                        MySqlDataReader dataReader = cmd.ExecuteReader();
                        scenarios.Load(dataReader);
                    }
                    return scenarios;
                }

            }
            catch (MySqlException ex)
            {

                throw ex;
            }

        }

        public bool DeleteScenarios(string tenantCode, string[] scenarioId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenarios", "DeleteScenarios Started");
            bool result = false;
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();

                    if (scenarioId.Length == 0)
                    {
                        string tenantlevelQry = String.Format("Delete FROM {0} where scenario_id in (select scenario_id from {1} where " +
                            "model_id = @model_id)", scenarioRunInstance, scenarioDetail);
                        MySqlCommand Tcmd = new MySqlCommand(tenantlevelQry, mySqlonnection);
                        Tcmd.Parameters.AddWithValue("@model_id", tenantCode);
                        Tcmd.ExecuteNonQuery();

                        tenantlevelQry = String.Format("Delete from {0} where model_id = @model_id", scenarioDetail);
                        Tcmd = new MySqlCommand(tenantlevelQry, mySqlonnection);
                        Tcmd.Parameters.AddWithValue("@model_id", tenantCode);
                        Tcmd.ExecuteNonQuery();
                    }
                    else
                    {
                        foreach (string str in scenarioId)
                        {
                            string scenariolevelQry = String.Format("Delete FROM {0} where scenario_id = @scenario_id", scenarioRunInstance);
                            MySqlCommand Tcmd = new MySqlCommand(scenariolevelQry, mySqlonnection);
                            Tcmd.Parameters.AddWithValue("@scenario_id", str);
                            Tcmd.ExecuteNonQuery();

                            scenariolevelQry = String.Format("Delete from {0} where scenario_id = @scenario_id", scenarioDetail);
                            Tcmd = new MySqlCommand(scenariolevelQry, mySqlonnection);
                            Tcmd.Parameters.AddWithValue("@scenario_id", str);
                            Tcmd.ExecuteNonQuery();
                        }

                    }

                    result = true;
                    _logHelper.LogMessage("INFO", "MySqlDataClient | DeleteScenarios", "DeleteScenarios Completed");
                }
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | DeleteScenarios", $"DeleteScenarios scenario failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }

        #region comments
        public List<ScenarioComment> GetAllComments(string scenarioId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllComments", "GetAllComments Started");
            List<ScenarioComment> comments = new List<ScenarioComment>();
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("SELECT comment_id, comment, scenario_id, created_by, created_date_time, updated_by, " +
                        "updated_date_time FROM {0} where scenario_id=@scenarioid", scenarioComments);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenarioid", scenarioId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        comments.Add(new ScenarioComment
                        {
                            CommentId = dataReader["comment_id"].ToString(),
                            Comment = dataReader["comment"].ToString(),
                            ScenarioId = dataReader["scenario_id"].ToString(),
                            CreatedBy = dataReader["created_by"].ToString(),
                            CreatedDateTime = dataReader["created_date_time"].ToString(),
                            UpdatedBy = dataReader["updated_by"].ToString(),
                            UpdatedDateTime = dataReader["updated_date_time"].ToString()
                        });
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllComments", "GetAllComments Completed");
                return comments;
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetAllComments", $"GetAllComments failed with message: {ex.Message}");
                throw ex;
            }
        }

        public ScenarioComment GetComment(string scenarioId, string commentId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetCommentById", "GetCommentById Started");
            ScenarioComment comments = new ScenarioComment();
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("SELECT comment_id, comment, scenario_id, created_by, created_date_time, updated_by, " +
                        "updated_date_time FROM {0} where scenario_id=@scenarioid and comment_id=@comment_id", scenarioComments);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenarioid", scenarioId);
                    cmd.Parameters.AddWithValue("@comment_id", commentId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        comments = new ScenarioComment
                        {
                            CommentId = dataReader["comment_id"].ToString(),
                            Comment = dataReader["comment"].ToString(),
                            ScenarioId = dataReader["scenario_id"].ToString(),
                            CreatedBy = dataReader["created_by"].ToString(),
                            CreatedDateTime = dataReader["created_date_time"].ToString(),
                            UpdatedBy = dataReader["updated_by"].ToString().ToString(),
                            UpdatedDateTime = dataReader["updated_date_time"].ToString()
                        };
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetCommentById", "GetCommentById Completed");
                return comments;
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetCommentById", $"GetCommentById failed with message: {ex.Message}");
                throw ex;
            }
        }

        public bool InsertScenarioComment(ScenarioComment comment)
        {
            bool result = false;
            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioComment", "InsertScenarioComment Started");
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("INSERT INTO {0} (comment_id, comment,scenario_id,created_by,created_date_time)" +
                        "VALUES(@comment_id,@comment,@scenario_id,@created_by,@created_date_time)", scenarioComments);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@comment_id", comment.CommentId);
                    cmd.Parameters.AddWithValue("@comment", comment.Comment);
                    cmd.Parameters.AddWithValue("@scenario_id", comment.ScenarioId);
                    cmd.Parameters.AddWithValue("@created_by", comment.CreatedBy);
                    cmd.Parameters.AddWithValue("@created_date_time", comment.CreatedDateTime);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioComment", "InsertScenarioComment Completed");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | InsertScenarioComment", $"InsertScenarioComment failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }

        public bool UpdateScenarioComment(ScenarioComment comment)
        {
            bool result = false;
            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | UpdateScenarioComment", "UpdateScenarioComment Started");

                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("update {0} set comment=coalesce(@comment, scenariocomments.comment)," +
                        "updated_by=coalesce(@updated_by,scenariocomments.updated_by),updated_date_time=coalesce(@updated_date_time,scenariocomments.updated_date_time)"
                        + " where comment_id=@comment_id and scenario_id=@scenario_id;", scenarioComments);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@comment_id", comment.CommentId);
                    cmd.Parameters.AddWithValue("@scenario_id", comment.ScenarioId);
                    cmd.Parameters.AddWithValue("@comment", comment.Comment);
                    cmd.Parameters.AddWithValue("@updated_by", comment.UpdatedBy);
                    cmd.Parameters.AddWithValue("@updated_date_time", comment.UpdatedDateTime);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | UpdateScenarioComment", $"UpdateScenarioComment failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }

        public bool DeletScenarioComment(string scenarioId, string commentId)
        {
            bool result = false;
            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | DeletScenarioComment", "DeletScenarioComment Started");

                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("delete from {0} where comment_id=@comment_id and scenario_id=@scenario_id", scenarioComments);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@comment_id", commentId);
                    cmd.Parameters.AddWithValue("@scenario_id", scenarioId);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }

                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | DeletScenarioComment", "DeletScenarioComment Completed");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | DeletScenarioComment", $"DeletScenarioComment failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }
        #endregion

        #region notes
        public List<ScenarioNote> GetAllNotes(string scenarioId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllNotes", "GetAllNotes Started");
            List<ScenarioNote> notes = new List<ScenarioNote>();
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("SELECT notes_id, notes, scenario_id, created_by, created_date_time FROM {0} where " +
                        "scenario_id=@scenarioid", scenarioNotes);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenarioid", scenarioId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        notes.Add(new ScenarioNote
                        {
                            NotesId = dataReader["notes_id"].ToString(),
                            Notes = dataReader["notes"].ToString(),
                            ScenarioId = dataReader["scenario_id"].ToString(),
                            CreatedBy = dataReader["created_by"].ToString(),
                            CreatedDateTime = dataReader["created_date_time"].ToString()
                        });
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetAllNotes", "GetAllNotes Completed");
                return notes;
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetAllNotes", $"GetAllNotes failed with message: {ex.Message}");
                throw ex;
            }
        }

        public ScenarioNote GetLatestNote(string scenarioId)
        {
            _logHelper.LogMessage("INFO", "MySqlDataClient | GetLatestNote", "GetLatestNote Started");
            ScenarioNote notes = null;
            try
            {
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("SELECT notes_id, notes, scenario_id, created_by, created_date_time FROM {0} where " +
                        "scenario_id=@scenarioid order by created_date_time desc limit 1", scenarioNotes);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@scenarioid", scenarioId);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        notes = new ScenarioNote
                        {
                            NotesId = dataReader["notes_id"].ToString(),
                            Notes = dataReader["notes"].ToString(),
                            ScenarioId = dataReader["scenario_id"].ToString(),
                            CreatedBy = dataReader["created_by"].ToString(),
                            CreatedDateTime = dataReader["created_date_time"].ToString()
                        };
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | GetLatestNote", "GetLatestNote Completed");
                return notes;
            }
            catch (MySqlException ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | GetLatestNote", $"GetLatestNote failed with message: {ex.Message}");
                throw ex;
            }
        }

        public bool InsertScenarioNote(ScenarioNote note)
        {
            bool result = false;
            try
            {
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioNote", "InsertScenarioNote Started");
                using (MySqlConnection mySqlonnection = new MySqlConnection(connectionString))
                {
                    mySqlonnection.Open();
                    string mySqlCommand = String.Format("INSERT INTO {0} (notes_id, notes,scenario_id,created_by,created_date_time)" +
                        "VALUES(@notes_id,@notes,@scenario_id,@created_by,@created_date_time)", scenarioNotes);
                    MySqlCommand cmd = new MySqlCommand(mySqlCommand, mySqlonnection);
                    cmd.Parameters.AddWithValue("@notes_id", note.NotesId);
                    cmd.Parameters.AddWithValue("@notes", note.Notes);
                    cmd.Parameters.AddWithValue("@scenario_id", note.ScenarioId);
                    cmd.Parameters.AddWithValue("@created_by", note.CreatedBy);
                    cmd.Parameters.AddWithValue("@created_date_time", note.CreatedDateTime);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        result = true;
                    }
                }
                _logHelper.LogMessage("INFO", "MySqlDataClient | InsertScenarioNote", "InsertScenarioNote Completed");
            }
            catch (Exception ex)
            {
                _logHelper.LogMessage("ERROR", "MySqlDataClient | InsertScenarioNote", $"InsertScenarioNote failed with message: {ex.Message}");
                throw ex;
            }
            return result;
        }
        #endregion
    }
}
