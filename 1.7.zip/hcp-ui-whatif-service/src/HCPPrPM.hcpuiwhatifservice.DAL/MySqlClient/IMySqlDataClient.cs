﻿using HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.DAL.MySqlClient
{
    public interface IMySqlDataClient
    {
        bool InsertScenario(ScenarioDetails scenario);
        List<ScenarioNames> GetAllScenariosByModelId(string modelId);
        bool DeleteScenario(string modelId, Guid scenarioId, Guid instanceId);
        DataTable GetAllScenarioDetailsById(string modelId,string solutionId);
        DataTable GetScenarioDetailsByScenarioId(Guid scenarioId);
        DataTable GetInstanceDetailsByScenarioId(string scenarioId);
        bool UpdateScenario(ScenarioDetails scenario);
        bool UpdateScenarioNameDesc(ScenarioDetails scenario);
        DataTable GetScenarioResultByInstanceId(string modelId, Guid scenarioId, Guid instanceId);
        bool InsertScenarioResult(string modelId, Guid scenarioId, Guid instanceId, ScenarioResultModel scenario);
        bool DeleteScenarioResult(string modelId, Guid scenarioId, Guid instanceId);
        void UpdateScenarioInstanceStatus(string scenarioId, string flowsheetName, string scenarioStatus);
        bool UpdateScenarioStatus(Guid scenarioId, Guid instanceId, string scenarioStatus, string message = "");
        DataTable IsScenarioAllowedToRun(int freq, string tenantCode);
        bool DeleteScenarios(string tenantCode, string[] scenarioId);

        #region comments
        List<ScenarioComment> GetAllComments(string scenarioId);
        ScenarioComment GetComment(string scenarioId, string commentId);

        bool InsertScenarioComment(ScenarioComment comment);
        bool UpdateScenarioComment(ScenarioComment comment);
        bool DeletScenarioComment(string scenarioId, string commentId);

        #endregion

        #region notes
        List<ScenarioNote> GetAllNotes(string scenarioId);
        ScenarioNote GetLatestNote(string scenarioId);
        bool InsertScenarioNote(ScenarioNote comment);
        #endregion
    }
}
