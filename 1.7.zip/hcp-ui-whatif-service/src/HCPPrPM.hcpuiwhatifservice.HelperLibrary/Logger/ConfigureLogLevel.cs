﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureLogLevel
    {
        public static string GetMinLevelFromEnvironmentVar()
        {

            string logLevel = System.Environment.GetEnvironmentVariable("LOG_LEVEL");

            Console.WriteLine("logLevel in appsetting is :" + logLevel);

            if (!string.IsNullOrWhiteSpace(logLevel) && logLevel.Equals(LogLevelConstants.ALL, StringComparison.InvariantCultureIgnoreCase))
            {
                return LogLevelConstants.ALL;
            }
            else if (!string.IsNullOrWhiteSpace(logLevel) && logLevel.Equals(LogLevelConstants.DEBUG, StringComparison.InvariantCultureIgnoreCase))
            {
                return LogLevelConstants.DEBUG;
            }
            else if (!string.IsNullOrWhiteSpace(logLevel) && logLevel.Equals(LogLevelConstants.INFO, StringComparison.InvariantCultureIgnoreCase))
            {
                return LogLevelConstants.INFO;
            }
            else if (!string.IsNullOrWhiteSpace(logLevel) && logLevel.Equals(LogLevelConstants.WARN, StringComparison.InvariantCultureIgnoreCase))
            {
                return LogLevelConstants.WARN;
            }
            else if (!string.IsNullOrWhiteSpace(logLevel) && logLevel.Equals(LogLevelConstants.ERROR, StringComparison.InvariantCultureIgnoreCase))
            {
                return LogLevelConstants.ERROR;
            }
            else
            {
                return LogLevelConstants.INFO;
            }
        }

        public static void SetLogLevel()
        {
            var logLevel = GetMinLevelFromEnvironmentVar();

            Console.WriteLine("Configured logLevel is :" + logLevel);

            log4net.Repository.ILoggerRepository[] repositories = log4net.LogManager.GetAllRepositories();

            //Configure all loggers to be at the debug level.
            foreach (log4net.Repository.ILoggerRepository repository in repositories)
            {
                repository.Threshold = repository.LevelMap[logLevel];
                log4net.Repository.Hierarchy.Hierarchy hier = (log4net.Repository.Hierarchy.Hierarchy)repository;
                log4net.Core.ILogger[] loggers = hier.GetCurrentLoggers();
                foreach (log4net.Core.ILogger logger in loggers)
                {
                    ((log4net.Repository.Hierarchy.Logger)logger).Level = hier.LevelMap[logLevel];
                }
            }

            //Configure the root logger.
            log4net.Repository.Hierarchy.Hierarchy h = (log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository();
            log4net.Repository.Hierarchy.Logger rootLogger = h.Root;
            rootLogger.Level = h.LevelMap[logLevel];

        }
    }
}
