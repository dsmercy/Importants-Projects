﻿using log4net;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger
{
    [ExcludeFromCodeCoverage]
    public class LogHelper : ILogHelper
    {
        readonly ILog _log = log4net.LogManager.GetLogger(typeof(LogHelper));
        public void LogMessage(string type, string serviceName, string message)
        {
            string logMessage = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ") + type.ToUpper() + "::ServiceName=" + "HCP-UI-WHATIF-SERVICE" + "::Description=" + message;

            switch (type.ToLower())
            {
                case "all":
                    _log.Debug(logMessage);
                    break;
                case "debug":
                    _log.Debug(logMessage);
                    break;
                case "info":
                    _log.Info(logMessage);
                    break;
                case "warn":
                    _log.Warn(logMessage);
                    break;
                case "error":
                    _log.Error(logMessage);
                    break;
                case "fatal":
                    _log.Fatal(logMessage);
                    break;
                default:
                    _log.Info(logMessage);
                    break;
            }
        }
    }
}
