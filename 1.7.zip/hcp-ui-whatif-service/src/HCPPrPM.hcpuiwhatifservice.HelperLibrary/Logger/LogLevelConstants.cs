﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger
{
    [ExcludeFromCodeCoverage]
    public class LogLevelConstants
    {
        public readonly static string ALL = "ALL";
        public readonly static string DEBUG = "DEBUG";
        public readonly static string INFO = "INFO";
        public readonly static string WARN = "WARN";
        public readonly static string ERROR = "ERROR";
    }
}
