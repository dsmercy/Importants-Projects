﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.HelperLibrary.Logger
{
    public interface ILogHelper
    {
        void LogMessage(string type, string serviceName, string message);
    }
}
