﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants
{
    public enum NumberConstants
    {
        One = 1,
        two = 2,    
        three = 3,
        four = 4,   
    }
}
