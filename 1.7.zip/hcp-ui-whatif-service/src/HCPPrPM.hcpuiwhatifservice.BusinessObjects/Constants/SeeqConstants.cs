﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config
{
    [ExcludeFromCodeCoverage]
    public class SeeqConstants
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string datasourceClass { get; set; }
        public string calcEngine { get; set; }
        public string datasourceId { get; set; }
    }
}
