﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants
{
    [ExcludeFromCodeCoverage]
    public static class Constants
    {
        public readonly static string InputTag = "input";
        public readonly static string OutputTag = "output";

        public readonly static string Calculation_RunMode = "Calculation";
        public readonly static string Optimization_RunMode = "Optimization";
    }
}
