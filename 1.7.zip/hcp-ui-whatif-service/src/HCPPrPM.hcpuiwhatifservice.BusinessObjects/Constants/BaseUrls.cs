﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Config
{
    [ExcludeFromCodeCoverage]
    public class BaseUrls
    {
        public string WhatifCalcProcessorApi { get; set; }
        public string SeeqAPI { get; set; }
    }
}
