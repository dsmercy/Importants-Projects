﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants
{
    [ExcludeFromCodeCoverage]
    public class WhatIfTables
    {
        public string ScenarioResult { get; set; }
        public string ScenarioDetails { get; set; }
        public string ScenarioRunInstance { get; set; }
        public string ScenarioComments { get; set; }
        public string ScenarioNotes { get; set; }
    }
}
