﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Constants
{
    [ExcludeFromCodeCoverage]
    public static class Arguments
    {
        public readonly static string MINIO_CLIENT = "MinioClient";
        public readonly static string DB_CONFIG = "DbConfig";
        public readonly static string TABLE_NAMES_CONFIG = "TableNames";
        public readonly static string SCENARIO_RESULT_DATA = "ScenarioResultData";
        public readonly static string OUTPUT_TAG_DATA = "OutputTagData";
        public readonly static string BASE_URLS = "BaseUrls";
        public readonly static string FILE_CONFIG = "FileConfig";
        public readonly static string CONFIG = "Config";
        public readonly static string SCENARIO = "Scenario";
        public readonly static string MODEL_ID = "ModelId";
        public readonly static string SCENARIO_ID = "ScenarioId";
        public readonly static string INSTANCE_ID = "InstanceId";
        public readonly static string SEEQ_CONSTANTS = "seeqconstants";
        public readonly static string SEEQ = "seeq";

    }
}
