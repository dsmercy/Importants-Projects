﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class ScenarioDetails
    {
        public string ModelId { get; set; }
        public string SolutionId { get; set; }

        public Guid ScenarioId { get; set; }

        public string ScenarioName { get; set; }

        public string ScenarioDescription { get; set; }

        public List<ParameterDetails> ParametersDetails { get; set; }

        public bool? IsValid { get; set; }

        public DateTime? OptimizationTime { get; set; }

        public DateTime? CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? ModifiedDateTime { get; set; }

        public string ModifiedBy { get; set; }

        public string UE_RunMode { get; set; }

        public bool IsOPEnabled { get; set; }
        public bool IsPublished { get; set; }

        public List<ScenarioInstance> Instances { get; set; }
        public FlowSheet FlowSheet { get; set; }

        
    }
    [ExcludeFromCodeCoverage]
    public class ParameterDetails
    {
        public string SectionID { get; set; }

        public List<ListSection> ListSections { get; set; }

        public List<GridSection> GridSections { get; set; }
        public List<InputSection> InputSections { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class GridSection
    {
        public string GridId { get; set; }

        public List<GridCell> Cells { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class GridCell
    {
        public string TagName { get; set; }
        public string NewTagName { get; set; }
        public string RowID { get; set; }

        public string ColumnID { get; set; }

        public double? BaseValue { get; set; }

        public double? NewValue { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ListSection
    {
        public string ListID { get; set; }

        public List<ListSectionParameter> Parameters { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ListSectionParameter
    {
        public string TagName { get; set; }

        public string ID { get; set; }

        public string CustUomDescription { get; set; }
        public string NewTagName { get; set; }

        public double? BaseValue { get; set; }

        public double? NewValue { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ScenarioInstance
    {

        public Guid InstanceId { get; set; }

        public string RunBy { get; set; }

        public DateTime? StartDateTime { get; set; }

        public string ScenarioStatus { get; set; }

        public string StatusCode { get; set; }

        public string StatusDescription { get; set; }

        public DateTime? CompletedDateTime { get; set; }

        public string ErrorDetail { get; set; }

        public string UnisimModelName { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class JobInfo
    {
        public string JobType { get; set; }

        public string JobId { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class FlowSheet
    {
        public string Flowsheet_Name { get; set; } = String.Empty;

        public DateTime? FlowSheet_CreatedDateTime { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class InputSection
    {
        public string sectionId { get; set; }
        public string label { get; set; }
        public string layout { get; set; }
        public List<Parameter> parameters { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Parameter
    {
        public string inputId { get; set; }
        public string sectionId { get; set; }
        public string label { get; set; }
        public string inputType { get; set; }
        public string inputGroup { get; set; }
        public string disabled { get; set; }
        public string visualMetricId { get; set; }
        public string tagName { get; set; }
        public string subscribeTo { get; set; }
        public string layout { get; set; }
        public string BaseValue { get; set; }
        public int DecimalValue { get; set; }
        public string NewValue { get; set; }
        public bool isChecked { get; set; }
        public List<ChildSection> childSection { get; set; }
        public string newTagName { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ErrorRule
    {
        public string ID { get; set; }
        public string TargetID { get; set; }
        public List<string> RequiredIDs { get; set; }
        public string Expression { get; set; }
        public string Message { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ChildSection
    {
        public string inputId { get; set; }
        public string inputType { get; set; }
        public string label { get; set; }
        public bool disabled { get; set; }
        public string layout { get; set; }
        public string uom { get; set; }
        public string tagName { get; set; }
        public string newTagName { get; set; }
        public string value { get; set; }
        public bool isChanged { get; set; }
        public bool isDate { get; set; }
        public string CustUomDescription { get; set; }
        public List<object> errorRules { get; set; }
        public List<object> warningRules { get; set; }
        public int? DecimalValue { get; set; }
        public string BaseValue { get; set; }
        public string NewValue { get; set; }
    }
}
