﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models
{
    [ExcludeFromCodeCoverage]
    public class ScenarioResult
    {
        public string ModelId { get; set; }
        public Guid InstanceId { get; set; }
        public Guid ScenarioId { get; set; }
        public List<InputTagDataItem> InputTagDetails { get; set; } = new List<InputTagDataItem>();
        public List<OutputTagDataItem> OutputTagDetails { get; set; } = new List<OutputTagDataItem>();
        public List<OP_OutputTagDataItem> Op_OutputTagDetails { get; set; } = new List<OP_OutputTagDataItem>();
        
        public string RunMode { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class OutputTagDataItem : DataItem { }
    [ExcludeFromCodeCoverage]
    public class OP_OutputTagDataItem : DataItem { }
    [ExcludeFromCodeCoverage]
    public class InputTagDataItem : DataItem
    {
        public double? BaseValueUopUom { get; set; }
        public double? BaseValueCusUom { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class DataItem
    {
        public string TagName { get; set; }
        public string UnisimMapTagName { get; set; } = "";
        public long TimeStamp { get; set; }
        public double? ValueUopUom { get; set; }
        public double? ValueCusUom { get; set; }
        public int Quality { get; set; } = 1;
        public string Uom { get; set; } = "";
        public bool IsUserInput { get; set; }
        public string TagType { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ScenarioResultModel
    {
        public string TagName { get; set; }
        public string TagType { get; set; }
        public string RunMode { get; set; }
        public DateTime TimeStamp { get; set; }
        public double Value { get; set; }
        public double BaseValue { get; set; }
        public int Quality { get; set; }
        public string Uom { get; set; } = string.Empty;
    }
    [ExcludeFromCodeCoverage]
    public class ScenarioResultStatus
    {
        public string Message { get; set; }
        public string Status { get; set; }
    }
}