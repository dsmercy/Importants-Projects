﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models
{
    [ExcludeFromCodeCoverage]
    public class ScenarioRunPayload
    {
        /// <summary>
        /// Unisim Model Name
        /// </summary>
        public string UnisimModelName { get; set; }

        /// <summary>
        /// Scenario is Being Run By
        /// </summary>
        public string RunBy { get; set; }

        /// <summary>
        /// Unisim Run Mode: Calculation/Optimization
        /// </summary>
        public bool IsOpRun { get; set; }
    }
}
