﻿using System.Diagnostics.CodeAnalysis;

namespace HCPPrPM.hcpuiwhatifservice.Web.Controllers
{
    [ExcludeFromCodeCoverage]
    public class RunScenarioCheck
    {
        /// <summary>
        /// Check whether the scenario allowed to run or not
        /// </summary>
        public bool AllowToRun { get; set; }

        /// <summary>
        /// No of scenarios allowed
        /// </summary>
        public int NoOfAllowedRuns { get; set; }

        /// <summary>
        /// No of succesful scenarios
        /// </summary>
        public int NoOfSuccessfulScenarios { get; set; }

        /// <summary>
        /// No of Scenario Runs Frequency
        /// </summary>
        public int ScenarioRunsFrequency { get; set; }
    }
}