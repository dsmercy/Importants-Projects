﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.BusinessObjects.Models
{
    [ExcludeFromCodeCoverage]
    public class ScenarioNote
    {
        public string NotesId { get; set; }
        public string Notes { get; set; }
        public string ScenarioId { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDateTime { get; set; }
    }
}
