﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Models
{
    public class ScenarioDetails
    {
        public string ModelId { get; set; }

        public Guid ScenarioId { get; set; }

        public string ScenarioName { get; set; }

        public string ScenarioDescription { get; set; }

        public List<ParameterDetails> ParametersDetails { get; set; }

        public bool? IsValid { get; set; }

        public DateTime? OptimizationTime { get; set; }

        public DateTime? CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? ModifiedDateTime { get; set; }

        public string ModifiedBy { get; set; }

        public string UE_RunMode { get; set; }

        public bool IsOPEnabled { get; set; }

        public List<ScenarioInstance> Instances { get; set; }
    }
    public class ParameterDetails
    {
        public string SectionID { get; set; }

        public List<ListSection> ListSections { get; set; }

        public List<GridSection> GridSections { get; set; }
    }

    public class GridSection
    {
        public string GridId { get; set; }

        public List<GridCell> Cells { get; set; }
    }

    public class GridCell
    {
        public string TagName { get; set; }

        public string RowID { get; set; }

        public string ColumnID { get; set; }

        public double? BaseValue { get; set; }

        public double? NewValue { get; set; }
    }

    public class ListSection
    {
        public string ListID { get; set; }

        public List<ListSectionParameter> Parameters { get; set; }
    }

    public class ListSectionParameter
    {
        public string TagName { get; set; }

        public string ID { get; set; }

        public string CustUomDescription { get; set; }

        public double? BaseValue { get; set; }

        public double? NewValue { get; set; }
    }

    public class ScenarioInstance
    {

        public Guid InstanceId { get; set; }

        public string RunBy { get; set; }

        public DateTime? StartDateTime { get; set; }

        public int ScenarioStatus { get; set; }

        public string StatusCode { get; set; }

        public string StatusDescription { get; set; }

        public DateTime? CompletedDateTime { get; set; }

        public string ErrorDetail { get; set; }

        public string UnisimModelName { get; set; }

        public string JobId { get; set; }

        public List<JobInfo> JobInfoList { get; set; }
    }

    public class JobInfo
    {
        public string JobType { get; set; }

        public string JobId { get; set; }
    }
}
