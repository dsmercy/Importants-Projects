﻿using HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenariosService
    {
        public ScenariosService()
        {

        }
        public async Task<Guid> InsertScenario(string modelId, ScenarioDetails scenario)
        {
            try
            {
                try
                {
                    logger.LogMessage("INFO", "ScenariosService | InsertScenario", "Insert Scenario started");
                    if (scenario == null)
                    {
                        string errorMessage = $"{Arguments.SCENARIO} is null for insertion";
                        logger.LogMessage("ERROR", "ScenariosService | InsertScenario", errorMessage);
                        throw new ArgumentNullException(Arguments.SCENARIO, errorMessage);
                    }
                    scenario.ModelId = modelId;
                    scenario.CreatedBy = scenario.CreatedBy ?? "";
                    scenario.ModifiedBy = scenario.CreatedBy ?? "";
                    scenario.CreatedDateTime = DateTime.UtcNow;
                    scenario.ModifiedDateTime = DateTime.UtcNow;
                    scenario.OptimizationTime = DateTime.UtcNow;
                    if (scenario.Instances != null && scenario.Instances.Count > 0)
                    {
                        ScenarioStatus status = this.scenarioStatusService.GetStatusById(scenario.Instances[0].ScenarioStatus);
                        if (status != null)
                        {
                            scenario.Instances[0].StatusCode = status.Code;
                            scenario.Instances[0].StatusDescription = status.Description;
                        }
                        scenario.Instances[0].InstanceId = Guid.NewGuid();
                        scenario.Instances = new List<ScenarioInstance> { scenario.Instances[0] };
                    }
                    else
                    {
                        ScenarioStatus status = this.scenarioStatusService.GetStatusById((int)ScenarioStatusTypes.NOT_RUN);
                        scenario.Instances = new List<ScenarioInstance>{
                        new ScenarioInstance
                        {
                            InstanceId = Guid.NewGuid(),
                            ScenarioStatus = status.Id,
                            StatusCode = status.Code,
                            StatusDescription = status.Description
                        }
                    };
                    }

                    if (scenario.IsOPEnabled)
                    {
                        scenario.UE_RunMode = "Optimization";
                    }
                    else
                    {
                        scenario.UE_RunMode = "Calculation";
                    }
                    string key = PrepareKey(modelId, scenario.ScenarioId);
                    string body = JsonConvert.SerializeObject(scenario);
                    await this.fileOperations.PutObject(bucketName, key, body).ConfigureAwait(false);
                    logger.LogMessage("INFO", "ScenariosService | InsertScenario", "Insert Scenario success");
                    return scenario.ScenarioId;
                }
                catch (Exception ex)
                {
                    logger.LogMessage("ERROR", "ScenariosService | InsertScenario", $"Insert scenario failed with message: {ex.Message}");
                    throw;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
