﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Services
{
    public class ScenarioStatusService
    {
    }
}
