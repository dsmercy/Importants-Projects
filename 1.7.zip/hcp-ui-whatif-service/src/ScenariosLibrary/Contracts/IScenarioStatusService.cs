﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HCPPrPM.hcpuiwhatifservice.ScenariosLibrary.Contracts
{
    public interface IScenarioStatusService
    {
        ScenarioStatus GetStatusById(int id);
        ScenarioStatus GetStatusForUI(int id);
    }
}
