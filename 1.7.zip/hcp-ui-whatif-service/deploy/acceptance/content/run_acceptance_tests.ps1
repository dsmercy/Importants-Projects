# Write-Host "#########################################################"
# Write-Host "               Automated Acceptance tests                "
# Write-Host "#########################################################"

# ############# Functions ##############
# Function IsStringPresentInFile {
#     Param 
#     (
#         [Parameter(Mandatory = $true, Position = 0)]
#         [string] $file1,
#         [Parameter(Mandatory = $true, Position = 1)]
#         [string] $stringToLocate1
#     )

#     $fileContent = Get-Content $file1
#     $results = $fileContent | % { $_ -match $stringToLocate1 }
#     if ($results -contains $true) {
#         Write-Host "The string '$($stringToLocate1)' was located in file '$($file1)'. Returning true"
#         return $true
#     } 
    
#     Write-Host "The string '$($stringToLocate1)' was not located in file '$($file1)'. Returning false"
#     foreach ($result in $results) {
#         Write-Host $($result)
#     }
#     Write-Host $($fileContent)
#     return $false
# }

# Function Upload-ArtifactsFromFolder {
#     Param 
#     (
#         [Parameter(Mandatory = $true, Position = 0)]
#         [string] $folderDir,
#         [Parameter(Mandatory = $true, Position = 1)]
#         [string] $filter
#     )
#     $files = Get-ChildItem $folderDir -Filter $filter
#     foreach ($file in $files) {
#         $fileName = $file
#         Write-Host "Found Report file: $($fileName)"
#         Get-ChildItem -Path $fileName | New-OctopusArtifact
#         Write-Host "Artifact $($folderDir)/$($fileName) has been uploaded"
#     }
   
# }

# Function Remove-ArtifactsFromHostFolder {
#     Param 
#     (
#         [Parameter(Mandatory = $true, Position = 0)]
#         [string] $folderDir,
#         [Parameter(Mandatory = $true, Position = 1)]
#         [string] $filter
#     )
#     $files = Get-ChildItem $folderDir -Filter $filter
#     foreach ($file in $files) {
#         $fileName = $file
#         Write-Host "Found Report file: $($fileName)"
#         Remove-Item ($($folderDir) + '/' + $($fileName))
#     }
# }

# Function Ensure-ApplicationIsReadyToAcceptRequest {
#     $count = 0
#     $retryDurationMax = 300
#     $retryDurationStepSize = 10
#     $applicationUrl = $openShiftAppUrl + "/swagger"
#     Write-Host "Ensure pod is ready to accept request(s)..."
#     Write-Host "Invoke-WebRequest $($applicationUrl)" 
#     Do
#     {
#         try{
#             $res = Invoke-WebRequest $applicationUrl
#         } catch {
#             $res = $_.Exception.Response
#         }
#         Write-Host "Response: $($res.StatusCode) and count: $($count)"
#         if($res.StatusCode -eq 200){
#                 Write-host "Pod is ready to accept requests"
#             break
#         }
#         if($count -eq $testDuration){
#             Write-Error "Pod is NOT ready to accept requests"
#             Write-host "May be the pod deployment is taking longer,\
#                         please verify the deployement log on OpenShift"
#             Write-Host "Please refer here for more debugging instruction https://confluence.honeywell.com/x/Tpv0EQ"
#             exit 1
#         }
#         $count += $retryDurationStepSize
#         Start-Sleep -s $retryDurationStepSize
#     }while ($count -le $retryDurationMax)
# }

# ########### Main ###############
# $containerName 				= 'acceptance'
# $dockerImage 				= $artifactoryDeployServer + '/' + $deployImageName + '-acceptance' + ':' + $acceptanceTestImageVersion
# $currentPath 				= $((Get-Location).path)
# $acceptanceTestLogsFileName = 'AcceptanceTestLog_' + $(get-date -f dd-MM-yyyy_HH_mm_ss) + '.log'
# $successResultString 		= 'Test Run Successful'

# Write-Host "Powershell version: $($PSVersionTable.PSVersion)"

# Ensure-ApplicationIsReadyToAcceptRequest

# try {
#     Write-Host "Starting acceptance test execution......." 
#     Invoke-Expression -Command "docker run -t -v $($currentPath):/app/TestResults/ --env WebService__Host=$openShiftAppUrl --name $($containerName) $($dockerImage)" | Tee-Object $acceptanceTestLogsFileName
#     Write-Host "$($acceptanceTestLogsFileName)"
#     $result = IsStringPresentInFile $acceptanceTestLogsFileName $successResultString
# }
# Catch {
#     $ErrorMessage = $_.Exception.Message
#     $FailedItem = $_.Exception.ItemName
#     Write-Error "An error occurred during acceptance test execution. $ErrorMessage. $FailedItem"
#     Throw $_.Exception
# } 
# Finally {
#     Write-Host "Getting container ID for container with name: $($containerName)"
#     Write-Host "docker ps -aqf 'name=$($containerName)'"
#     $containerId = docker ps -aqf "name=$containerName"
#     Write-Host "Deleting acceptance test container: $($containerId)"
#     docker rm $containerId
# }

# try {
#     Write-Host "Uploading acceptance test log file to Ocotopus: $acceptanceTestLogsFileName"
#     Get-ChildItem -Path $acceptanceTestLogsFileName | New-OctopusArtifact
#     Write-Host "Artifact uploaded"

#     Write-Host "Uploading acceptance test report file to Ocotopus"
#     Upload-ArtifactsFromFolder $($currentPath) ('*.trx')
# } 
# Catch {
#     $ErrorMessage = $_.Exception.Message
#     $FailedItem = $_.Exception.ItemName
#     Write-Error "An error occurred during report upload. $ErrorMessage. $FailedItem"
#     Throw $_.Exception
# } 

# If($result -eq $false)
# {
# 	Write-Host "The Acceptance Tests have failed, Expected successString '$($successResultString)' to be found in test log '$acceptanceTestLogsFileName'."
# 	Write-Host "Is Acceptance Tests Successfull?: $($result)"
# 	throw [System.ApplicationException] "There were test failures whilst running acceptance tests, reveiw log and reports"
# }
# Write-Host "Acceptance tests successfully passed"