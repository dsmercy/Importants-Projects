<#
.SYNOPSIS
Openshift deployment script  

.DESCRIPTION
This script invokes oc command to create openshift objects. It verifies the created object based template type
It also uses docker image ebits/openshift-client to execute oc   

.EXAMPLE
./openshift.ps1 

.PARAMETER -templateType
Decideds whether the template is library template or webapi
.PARAMETER -deploymentKind
Decides whether the Deployment Kind is Deployment or DeploymentConfig

#>

param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("app","webapi","lib")]   
    [string]$templateType = "webapi",
    [Parameter(Mandatory = $false)]
    [string]$deploymentKind = "dc"
)


$ErrorActionPreference  = "Continue"
$currentPath            = $((Get-Location).path)
$status                 = $True
$sdkkey                 = ""
$occlient               = "#{DEPLOYMENT_CONTAINER_IMAGE_REPOSITORY}:#{DEPLOYMENT_CONTAINER_IMAGE_TAG}"

try {
    Write-Host "Creating docker container for helm3 client"
    Write-Host "docker run --rm -v $($currentPath):/deploy -td $occlient"
    $containerId = Invoke-Expression -Command "docker run --rm -v $($currentPath):/deploy -td $occlient"

    Write-Host "working directory: "$currentPath
    
    Write-Host "Run #{DEPLOYMENT_SCRIPT_FILENAME}"
    docker exec $containerId bash /deploy/#{DEPLOYMENT_SCRIPT_FILENAME}

		
    if($LASTEXITCODE -eq 1){
        Write-Error "Error occured while executing the command #{DEPLOYMENT_SCRIPT_FILENAME}"
        Start-Sleep -s 1
        exit $LASTEXITCODE
    }

} Catch {
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Fail-Step "An error occurred. $ErrorMessage. $FailedItem"
} Finally {
	  Write-Host "Removing container $containerId"
	  docker stop $containerId
}
