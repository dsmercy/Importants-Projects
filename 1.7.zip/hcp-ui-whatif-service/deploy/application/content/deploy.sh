#!/bin/sh

set -euo pipefail

BITBUCKET_REPO_NAME="hcp-ui-whatif-service"

# Azure Login
AZURE_SP_ID='#{AZURE_SP_ID}'
AZURE_SP_PASSWORD='#{AZURE_SP_PASSWORD}'
AZURE_TENANT_ID='#{AZURE_TENANT_ID}'

# Kube Context and Namespace
CONTEXT='#{CONTEXT}'
NAMESPACE='#{NAMESPACE}'
AKS_RG='#{AKS_RG}'

# Data Access Vars
MYSQLCONNECTIONSTRING='#{MYSQLCONNECTIONSTRING}'

#k8s resources
K8S_RESOURCES_BLOCK_ENABLED='#{K8S_RESOURCES_BLOCK_ENABLED}'
K8S_RESOURCES_REQUESTS_CPU='#{K8S_RESOURCES_REQUESTS_CPU}'
K8S_RESOURCES_LIMITS_CPU='#{K8S_RESOURCES_LIMITS_CPU}'
K8S_RESOURCES_REQUESTS_MEMORY='#{K8S_RESOURCES_REQUESTS_MEMORY}'
K8S_RESOURCES_LIMITS_MEMORY='#{K8S_RESOURCES_LIMITS_MEMORY}'


# Model API Vars
# STUB! add here when necessary

# Shared Vars
APPINSIGHTS_INSTRUMENTATIONKEY='#{APPINSIGHTS_INSTRUMENTATIONKEY}'
ASPNETCORE_ENVIRONMENT='#{ASPNETCORE_ENVIRONMENT}'
DEPENDENCYBASEURLS_SERVICE1='#{DEPENDENCYBASEURLS_SERVICE1}'
DEPENDENCYBASEURLS_COMMENT='#{DEPENDENCYBASEURLS_COMMENT}'
WHATIFTABLES_SCENARIORESULT='#{WHATIFTABLES_SCENARIORESULT}'
WHATIFTABLES_SCENARIODETAILS='#{WHATIFTABLES_SCENARIODETAILS}'
WHATIFTABLES_SCENARIORUNINSTANCE='#{WHATIFTABLES_SCENARIORUNINSTANCE}'
WHATIFTABLES_SCENARIOCOMMENTS='#{WHATIFTABLES_SCENARIOCOMMENTS}'
WHATIFTABLES_SCENARIONOTES='#{WHATIFTABLES_SCENARIONOTES}'
BASEURLS_WHATIFCALCPROCESSORAPI='#{BASEURLS_WHATIFCALCPROCESSORAPI}'
BASEURLS_SEEQAPI='#{BASEURLS_SEEQAPI}'
TOKEN_VALIDATOR='#{TOKEN_VALIDATOR}'
FORGE_SSO_URL='#{FORGE_SSO_URL}'
ISSUER_WELLKNOWNEND_POINT='#{ISSUER_WELLKNOWNEND_POINT}'
USERACCOUNT_CLAIM_NAME='#{USERACCOUNT_CLAIM_NAME}'
PREFIX_NAME='#{PREFIX_NAME}'
INGRESS_ENABLE='#{INGRESS_ENABLE}'
INGRESS_HOST='#{INGRESS_HOST}'
SCENARIORUNS_ALLOWED='#{SCENARIORUNS_ALLOWED}'
SCENARIORUNS_FREQUENCY='#{SCENARIORUNS_FREQUENCY}'
LOG_LEVEL='#{LOG_LEVEL}'

# Set Version
IMAGE_REPOSITORY='#{artifactoryDeployServer}/#{deployImageName}'
VERSION='#{deployImageTag}'

# Get current working directory for pathing
CWD=$(dirname $(realpath $0))


echo "Begin Deploy"

echo "Logging in to Azure"
az login \
    --service-principal \
    --username ${AZURE_SP_ID}  \
    --password ${AZURE_SP_PASSWORD} \
    --tenant ${AZURE_TENANT_ID}

echo "Getting AKS Credentials"
az aks get-credentials -g ${AKS_RG} --name ${CONTEXT}

# Deploy hcp-ui-whatif api
echo "Creating secrets for hcp-ui-whatif api"

kubectl --context ${CONTEXT} \
    --namespace ${NAMESPACE} \
    create secret generic hcp-ui-whatif-service-secrets \
   --from-literal app_insights_key="${APPINSIGHTS_INSTRUMENTATIONKEY}" \
   --from-literal DependencyBaseUrls__Service1="${DEPENDENCYBASEURLS_SERVICE1}" \
   --from-literal DependencyBaseUrls__Comment="${DEPENDENCYBASEURLS_COMMENT}" \
   --from-literal mysqlconnectionstring="${MYSQLCONNECTIONSTRING}" \
   --from-literal WhatIfTables__ScenarioResult="${WHATIFTABLES_SCENARIORESULT}" \
   --from-literal WhatIfTables__ScenarioDetails="${WHATIFTABLES_SCENARIODETAILS}" \
   --from-literal WhatIfTables__ScenarioRunInstance="${WHATIFTABLES_SCENARIORUNINSTANCE}" \
   --from-literal WhatIfTables__ScenarioComments="${WHATIFTABLES_SCENARIOCOMMENTS}" \
   --from-literal WhatIfTables__ScenarioNotes="${WHATIFTABLES_SCENARIONOTES}" \
   --from-literal BaseUrls__WhatifCalcProcessorApi="${BASEURLS_WHATIFCALCPROCESSORAPI}" \
   --from-literal BaseUrls__SeeqAPI="${BASEURLS_SEEQAPI}" --dry-run=client -o yaml | kubectl apply -f -

echo "helm upgrade for hcp-ui-whatif api"
#helm uninstall "hcp-ui-whatif-service-${NAMESPACE}" --namespace "${NAMESPACE}"

helm upgrade --debug --install \
    --kube-context ${CONTEXT} \
    hcp-ui-whatif-service-${NAMESPACE} \
    ${CWD}/hcp-ui-whatif-service/. \
    --namespace ${NAMESPACE} \
    --set nameOverride=${BITBUCKET_REPO_NAME}-${NAMESPACE} \
    --set namespace="${NAMESPACE}" \
    --set image.tag="${VERSION}" \
    --set image.repository="${IMAGE_REPOSITORY}" \
    --set ingress.enabled="${INGRESS_ENABLE}" \
    --set ingress.host="${INGRESS_HOST}" \
    --set ingress.class=nginx-${NAMESPACE}-internal \
    --set ingress.path="/${BITBUCKET_REPO_NAME}" \
    --set version="${VERSION}" \
    --set aspnetcore_environment="${ASPNETCORE_ENVIRONMENT}" \
    --set hcp_ui_whatif_service=${BITBUCKET_REPO_NAME} \
    --set k8s.resources.enabled="${K8S_RESOURCES_BLOCK_ENABLED}" \
	--set k8s.resources.cpu.requests="${K8S_RESOURCES_REQUESTS_CPU}" \
	--set k8s.resources.cpu.limits="${K8S_RESOURCES_LIMITS_CPU}" \
	--set k8s.resources.memory.requests="${K8S_RESOURCES_REQUESTS_MEMORY}" \
    --set token_validator="${TOKEN_VALIDATOR}" \
    --set useraccount_claim_name="${USERACCOUNT_CLAIM_NAME}" \
    --set forge_sso_url="${FORGE_SSO_URL}" \
    --set issuer_wellknown_endpoint="${ISSUER_WELLKNOWNEND_POINT}" \
    --set scenarioruns_allowed="${SCENARIORUNS_ALLOWED}" \
    --set scenarioruns_frequency="${SCENARIORUNS_FREQUENCY}" \
    --set log_level="${LOG_LEVEL}" \
	--set k8s.resources.memory.limits="${K8S_RESOURCES_LIMITS_MEMORY}"
