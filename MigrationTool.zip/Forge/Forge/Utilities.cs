﻿using ExcelDataReader;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace Forge
{
    public class Utilities
    {
        public DataSet GetDataTableWithData(string filePath)
        {
			try
			{
                DataSet excelDS;
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        excelDS = reader.AsDataSet(new ExcelDataSetConfiguration()
                        {
                            // Gets or sets a value indicating whether to set the DataColumn.DataType 
                            // property in a second pass.
                            UseColumnDataType = true,

                            // Gets or sets a callback to obtain configuration options for a DataTable. 
                            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                            {

                                // Gets or sets a value indicating the prefix of generated column names.
                                EmptyColumnNamePrefix = "Column",

                                // Gets or sets a value indicating whether to use a row from the 
                                // data as column names.
                                UseHeaderRow = true,

                                // Gets or sets a callback to determine which row is the header row. 
                                // Only called when UseHeaderRow = true.
                                ReadHeaderRow = (rowReader) =>
                                {
                                    // F.ex skip the first row and use the 2nd row as column headers:
                                    //rowReader.Read();
                                }
                            }
                        });

                    }
                }

                return excelDS;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        public string encodeTagCloudHistorianStyle(string tagName)
        {
            var encodedTag = tagName;
            if (!string.IsNullOrEmpty(tagName))
            {
                encodedTag = encodeSpecialCharsXML(encodedTag);
                encodedTag = Regex.Replace(encodedTag, @"_x00([0-9a-fA-F]{2})_", match => TokenReplacement(match.Groups[1].Value));
                encodedTag = HttpUtility.UrlEncode(encodedTag);
                encodedTag = Regex.Replace(encodedTag, @"\%([0-9a-fA-F]{2})", match => TokenReplacement(match.Groups[1].Value));
                encodedTag = encodedTag.ToLower();
            }
            return encodedTag;
        }

        private static string TokenReplacement(string token)
        {
            return $"_x00{token}_";
        }
        private static string TokenReplacementDecode(string token)
        {
            return $"%{token}";
        }

        public static string decodeTagCloudHistorianStyle(string tagName)
        {
            var decodedTag = tagName;
            if (!string.IsNullOrEmpty(tagName))
            {
                if (tagName.Contains("_x005f_x003a_"))
                {
                    decodedTag = decodedTag.Replace("_x005f", "");
                    decodedTag = Regex.Replace(decodedTag, @"_x00([0-9a-fA-F]{2})_", match => TokenReplacementDecode(match.Groups[1].Value));
                }
                else
                {
                    decodedTag = Regex.Replace(decodedTag, @"_x00([0-9a-fA-F]{2})_", match => TokenReplacementDecode(match.Groups[1].Value));
                }
                decodedTag = HttpUtility.UrlDecode(decodedTag);
                decodedTag = decodeSpecialCharsXML(decodedTag);
            }
            return decodedTag;
        }

        private static string encodeSpecialCharsXML(string tagToEncode)
        {
            var encodings = getSpecialCharsEncodings();
            var tempTag = tagToEncode;

            foreach (var specialChar in encodings)
            {
                var str = Convert.ToChar(specialChar.code).ToString();
                tempTag = tempTag.Replace(str, specialChar.encoding);
            }
            return tempTag;
        }

        private static string decodeSpecialCharsXML(string decodedTag)
        {
            var encodings = getSpecialCharsEncodings();
            var tempTag = decodedTag;

            foreach (var specialChar in encodings)
            {
                var str = Convert.ToChar(specialChar.code).ToString();
                tempTag = tempTag.Replace(specialChar.encoding, str);
            }
            return tempTag;
        }

        private static List<SpecialCharsEncoding> getSpecialCharsEncodings()
        {
            return new List<SpecialCharsEncoding>
            {
                new SpecialCharsEncoding { code= 43, encoding= "_x002b_"},
                new SpecialCharsEncoding{ code= 33, encoding= "_x0021_"},
                new SpecialCharsEncoding{ code= 64, encoding= "_x0040_"},
                new SpecialCharsEncoding{ code= 35, encoding= "_x0023_"},
                new SpecialCharsEncoding{ code= 36, encoding= "_x0024_"},
                new SpecialCharsEncoding{ code= 37, encoding= "_x0025_"},
                new SpecialCharsEncoding{ code= 38, encoding= "_x0026_"},
                new SpecialCharsEncoding{ code= 40, encoding= "_x0028_"},
                new SpecialCharsEncoding{ code= 41, encoding= "_x0029_"},
                new SpecialCharsEncoding{ code= 60, encoding= "_x003c_"},
                new SpecialCharsEncoding{ code= 62, encoding= "_x003e_"},
                new SpecialCharsEncoding{ code= 123, encoding= "_x007b_"},
                new SpecialCharsEncoding{ code= 125, encoding= "_x007d_"},
                new SpecialCharsEncoding{ code= 91, encoding= "_x005b_"},
                new SpecialCharsEncoding{ code= 93, encoding= "_x005d_"},
                new SpecialCharsEncoding{ code= 44, encoding= "_x002c_"},
                // new SpecialCharsEncoding{ code= 46, encoding= "_x002e_"}, // TODO should we encode . ?
                new SpecialCharsEncoding{ code= 47, encoding= "_x002f_"},
                new SpecialCharsEncoding{ code= 92, encoding= "_x005c_"},
                new SpecialCharsEncoding{ code= 58, encoding= "_x005f_x003a_"},
                new SpecialCharsEncoding{ code= 59, encoding= "_x003b_"},
                new SpecialCharsEncoding{ code= 34, encoding= "_x0022_"},
                new SpecialCharsEncoding{ code= 39, encoding= "_x0027_"},
                new SpecialCharsEncoding{ code= 32, encoding= "_x0020_"}
            };
        }
    }

    public class SpecialCharsEncoding
    {
        public Int32 code { get; set; }
        public string encoding { get; set; }

    }
}
