﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Forge.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OfficeOpenXml;
using System.ComponentModel;
using System.Data;
using System.Net.Http.Headers;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using LicenseContext = OfficeOpenXml.LicenseContext;

namespace Forge
{
    public class TimeSeries
    {
        public TimeSeries(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        private static Func<HttpClient> _clientFactory = () => new HttpClient();
        private readonly IConfiguration configuration;

        public async Task<string> GetToken()
        {
            try
            {
                using (var client = _clientFactory())
                {
                    client.BaseAddress = new Uri(configuration["Settings:TokenURL"]);
                    var content = new FormUrlEncodedContent(new[]
                    {
                new KeyValuePair<string, string>("resource", configuration["Settings:resource"]),
                new KeyValuePair<string, string>("client_id", configuration["Settings:client_id"]),
                new KeyValuePair<string, string>("client_secret", configuration["Settings:client_secret"]),
                new KeyValuePair<string, string>("grant_type", configuration["Settings:grant_type"])
            });
                    var result = await client.PostAsync("", content);
                    var resultContent = await result.Content.ReadAsStringAsync();
                    //loghelper.LogMessage(LoggerConstants.info, MethodBase.GetCurrentMethod().DeclaringType.FullName, $"EventID: {LogEvent}; Getting Access Token...");
                    var response = JsonConvert.DeserializeObject<dynamic>(resultContent);
                    var _accessToken = response.access_token;
                    var expireInSeconds = Convert.ToInt32(response.expires_in);
                    var _tokenExpiresOn = expireInSeconds > 0 ?
                        DateTime.Now.AddSeconds(expireInSeconds) :
                        DateTime.MaxValue;
                    return _accessToken;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        public async Task<TOut> PostRequest<TIn, TOut>(string uri, TIn content, string accessToken)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);

                    var serialized = new StringContent(JsonConvert.SerializeObject(content), Encoding.UTF8, "application/json");

                    using (HttpResponseMessage response = await client.PostAsync(uri, serialized))
                    {
                        string responseBody = await response.Content.ReadAsStringAsync();

                        return JsonConvert.DeserializeObject<TOut>(responseBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        public async Task<int> WriteUpdatedTags(string uri, TimeSeriesWriteModel content, string accessToken)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);

                    var serialized = new StringContent(JsonConvert.SerializeObject(content), Encoding.UTF8, "application/json");

                    using (HttpResponseMessage response = await client.PostAsync(uri, serialized))
                    {
                        string responseBody = await response.Content.ReadAsStringAsync();

                        return (int)response.StatusCode;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        public DateTime UnixTimeStampToDateTime(long unixTimeStamp)
        {
            try
            {
                DateTime epochTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
                DateTime result = epochTime.AddTicks(unixTimeStamp / 100);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        public List<FileModel> GetTags(DataSet dtFileRecords)
        {
            try
            {
                List<FileModel> tags = new List<FileModel>();
                DataTable dt = dtFileRecords.Tables[0];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    FileModel fileModel = new FileModel();
                    fileModel.OldSourceTag = dt.Columns.Contains("Old Source Tag") ? Convert.ToString(dt.Rows[i]["Old Source Tag"]) : "";
                    fileModel.NewSourceTag = dt.Columns.Contains("New Source Tag") ? Convert.ToString(dt.Rows[i]["New Source Tag"]) : "";
                    fileModel.Aggregation = dt.Columns.Contains("Aggregation") ? Convert.ToString(dt.Rows[i]["Aggregation"]) : "";
                    fileModel.StandardTagName = dt.Columns.Contains("Standard Tag Name") ? Convert.ToString(dt.Rows[i]["Standard Tag Name"]) : "";
                    tags.Add(fileModel);
                }
                return tags;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
            
        }
        public void UpdateExcel(string filePath, string fileName, int rowCount, string newSourceTag)
        {
            try
            {
                ExcelPackage.LicenseContext = LicenseContext.Commercial;
                ExcelPackage pck = new ExcelPackage(filePath + fileName);
                var wsContent = pck.Workbook.Worksheets[0];

                wsContent.Cells[rowCount + 1, 5].Value = "Success";


                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }

                pck.SaveAs(new FileInfo(filePath + fileName)); ;

                //Console.WriteLine($"status updated in file for tag: {newSourceTag} sucess");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }
    }
}
