﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Forge.Models
{
    public class FileModel
    {
        //[XmlElement("Old Source Tag")]
        public string? OldSourceTag { get; set; }
        //[XmlElement("New Source Tag")]
        public string? NewSourceTag { get; set; }
        //[XmlElement("Aggregation")]
        public string? Aggregation { get; set; }
        //[XmlElement("Standard Tag Name")]
        public string? StandardTagName { get; set; }    
    }
}
