﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forge.Models
{
    public class IntervalModel
    {
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set; }
        public List<Query>? queries { get; set; }
        public object? source { get; set; }
    }

    public class Query
    {
        public string? pointId { get; set; }
        public string? systemGuid { get; set; }
        public object? aggregator { get; set; }
        public object? downsample { get; set; }
        public object? pointAttributes { get; set; }
    }
}
