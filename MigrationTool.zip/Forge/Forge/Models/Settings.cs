﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forge.Models
{
    public class Settings
    {
        public string StartTime { get; set; } = "2021-01-01T17:00:00Z";
        public string EndTime { get; set; } = "2022-04-03T16:59:59Z";
        public string SystemGuid { get; set; } = "856648d1-375d-4347-96ff-7a596391eb3f"; 
        public string FilePath { get; set; } = @"C:\\Users\\H504704\\Documents\\files\\"; 
        public string FileName { get; set; } = "HMCSourceTags.xlsx"; 
        public string WriteTagsURL { get; set; } = "https://t01atqacloudapp.testqa-cbp.honeywell.com/api/timeseries/v2/"; 
        public string TagsDetailsURL { get; set; } = "https://t01atqacloudapp.testqa-cbp.honeywell.com/api/timeseries/values/intervals"; 
    }
}
