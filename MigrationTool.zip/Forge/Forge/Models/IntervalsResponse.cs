﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forge.Models
{
    public class IntervalsResponse
    {
        public string? pointId { get; set; }
        public Dictionary<string, double?>? pointValues { get; set; }
        public PointAttributes? pointAttributes { get; set; }
    }

    public class PointAttributes
    {
        public string? SystemGuid { get; set; }
        public string? Quality { get; set; }
        public string? DerivedQuality { get; set; }
    }
}
