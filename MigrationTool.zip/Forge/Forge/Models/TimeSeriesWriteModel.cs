﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Forge.Models
{
    public class TimeSeriesWriteModel
    {
        public List<SystemTimeSeries>? SystemTimeSeries { get; set; }
    }
    public class Sample
    {
        public string? ItemName { get; set; }
        public string? Quality { get; set; }
        public DateTime Time { get; set; }
        public double Value { get; set; }
    }

    public class SystemTimeSeries
    {
        public string? SystemGuid { get; set; }
        public List<Sample>? Samples { get; set; }
    }
}
