﻿using DocumentFormat.OpenXml.Drawing;
using Forge.Models;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace Forge
{
    internal class Migration
    {
        private readonly IConfiguration configuration;

        public Migration(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public async void DoWork()
        {
            try
            {
                TimeSeries timeSeries = new TimeSeries(configuration);
                List<Query> queries = new List<Query>();
                List<SystemTimeSeries> systemTimeSeries = new List<SystemTimeSeries>();
                Utilities utilities = new Utilities();


                ///Get data from excel file
                DataSet dtFileRecords = utilities.GetDataTableWithData(configuration["Settings:FilePath"] + configuration["Settings:FileName"]);

                List<FileModel> tagsList = timeSeries.GetTags(dtFileRecords);

                Console.WriteLine("Get data from excel success");

                ///Get token
                string tokenResponse = await timeSeries.GetToken();
                //Console.WriteLine("Get Token success");


                DateTime StartDate = Convert.ToDateTime(configuration["Settings:StartTime"]);
                DateTime EndDate = Convert.ToDateTime(configuration["Settings:EndTime"]);


                int yearsDiff = (int)((EndDate.Date - StartDate.Date).TotalDays) / 366;

                if (yearsDiff > 0) { EndDate = StartDate.AddYears(1); }

                for (int i = -1; i < yearsDiff; i++)
                {
                    int rowCount = 1;

                    foreach (var tag in tagsList)
                    {

                        ///Prepare payload to get intervals

                        IntervalModel intervalModel = new IntervalModel
                        {
                            startTime = StartDate,
                            endTime = EndDate,
                            queries = new List<Query>()
                        {
                            new Query
                             {
                                 pointId = utilities.encodeTagCloudHistorianStyle(tag.OldSourceTag),
                                 systemGuid = configuration["Settings:SystemGuid"]
                             }
                         }
                        };

                        ///Get intervals
                        List<IntervalsResponse> intervals = await timeSeries.PostRequest<IntervalModel, List<IntervalsResponse>>(
                            configuration["Settings:TagsDetailsURL"],
                            intervalModel, tokenResponse);

                        if (intervals == null)
                        {
                            tokenResponse = await timeSeries.GetToken();

                            intervals = await timeSeries.PostRequest<IntervalModel, List<IntervalsResponse>>(
                            configuration["Settings:TagsDetailsURL"],
                            intervalModel, tokenResponse);
                        }


                        //Console.WriteLine($"{tagsList.Count - rowCount} tags remain to be migrated");

                        if (intervals.Count > 0)
                        {
                            ///Prepare payload for write
                            //Console.WriteLine($"Write data for tag: {tag.NewSourceTag} started");
                            await WriteTagDetails(timeSeries, utilities, tokenResponse, rowCount, tag, intervals);

                            Console.WriteLine($"data migrated for tag: {tag.NewSourceTag} sucessfully");
                        }
                        Console.WriteLine($"Migrating data from date:{StartDate} to date:{EndDate} ...");
                        rowCount += 1;
                    }

                    Console.WriteLine($"Data migrated from date:{StartDate} to date:{EndDate} successfully");

                    if (DateTime.Parse(configuration["Settings:EndTime"]).Year == DateTime.Parse(EndDate.ToString()).Year)
                    {
                        StartDate = EndDate;
                        EndDate = Convert.ToDateTime(configuration["Settings:EndTime"]);
                    }
                    else
                    {
                        StartDate = EndDate;
                        EndDate = EndDate.AddYears(1);
                    }

                }

                Console.WriteLine($"Data migrated successfully");

                Console.Read();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }

        private async Task WriteTagDetails(TimeSeries timeSeries, Utilities utilities, string tokenResponse, int rowCount, FileModel tag, List<IntervalsResponse> intervals)
        {
            for (int i = 0; i < intervals.FirstOrDefault().pointValues.Count; i = i + 1000)
            {
                ///take 1000 pointValues only
                var pointValues = intervals.FirstOrDefault().pointValues.Skip(i).Take(1000);

                List<Sample> samples = new List<Sample>();
                foreach (var pointValue in pointValues)
                {
                    Sample sample = new Sample();
                    sample.ItemName = utilities.encodeTagCloudHistorianStyle(tag.NewSourceTag);
                    sample.Quality = intervals.FirstOrDefault().pointAttributes.Quality;
                    sample.Time = timeSeries.UnixTimeStampToDateTime(Convert.ToInt64(pointValue.Key));
                    sample.Value = Convert.ToDouble(pointValue.Value);
                    samples.Add(sample);
                }

                SystemTimeSeries systemTimeDynamic = new SystemTimeSeries
                {
                    SystemGuid = configuration["Settings:SystemGuid"],
                    Samples = samples
                };

                TimeSeriesWriteModel timeSeriesWriteModel = new TimeSeriesWriteModel();
                timeSeriesWriteModel.SystemTimeSeries = new List<SystemTimeSeries>();
                timeSeriesWriteModel.SystemTimeSeries.Add(systemTimeDynamic);



                ///Write tag details
                var responseStatus = await timeSeries.WriteUpdatedTags(
                    configuration["Settings:WriteTagsURL"],
                    timeSeriesWriteModel, tokenResponse);
                                

                if (responseStatus == 202)
                {
                    ///Update excel 
                    timeSeries.UpdateExcel(configuration["Settings:FilePath"], configuration["Settings:FileName"], rowCount, tag.NewSourceTag);

                }
            }
        }
    }
}
